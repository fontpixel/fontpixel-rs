# Source this from any directory for the restored external oracle environment.
# No compiler, registry or project mutation occurs.
_phase6_oracle_proof="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
export VIRTUAL_ENV="$(dirname -- "$_phase6_oracle_proof")/oracles"
export PATH="$VIRTUAL_ENV/bin:$PATH"
export PYTHONDONTWRITEBYTECODE=1
export TMPDIR="$_phase6_oracle_proof/tmp"
export PIP_CACHE_DIR="$_phase6_oracle_proof/pip-cache"
export npm_config_cache="$_phase6_oracle_proof/npm-cache"
unset _phase6_oracle_proof
