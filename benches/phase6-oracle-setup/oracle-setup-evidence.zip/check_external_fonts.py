"""External-only valid-font smoke; no native implementation or formal timing."""
from pathlib import Path
import io,json,hashlib,os,subprocess,sys
import fontTools, freetype, uharfbuzz as hb, ots, monobit
from fontTools.ttLib import TTFont
from fontTools.ttLib.woff2 import WOFF2FlavorData
proof=Path(__file__).resolve().parent;base=proof.parents[1];repo=base/'fontpixel-rs'
sys.dont_write_bytecode=True
sys.path.insert(0,str(base/'local-work/phase6-performance/reference/bdfparser/src'))
sys.path.insert(0,str(repo/'benches'))
from bdfparser import Font
from phase6_validate import glyph_raster,web_equivalent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=base/'samples/tong-pixel-sans/TongPixelSans14Large-SC.bdf';pcf=proof/'python-full38653/compat.pcf';ttf=proof/'python-full38653/compat.ttf'
faces=[freetype.Face(str(p)) for p in [source,pcf,ttf]]
coverage=[dict(face.get_chars()) for face in faces]
coverage=[{cp:gid for cp,gid in row.items() if gid} for row in coverage]
assert len(coverage[0])==38653
assert set(coverage[1])=={cp for cp in coverage[0] if cp<=0xffff}
assert set(coverage[2])==set(coverage[0])
counts=[]
for index in [1,2]:
 for cp,gid in coverage[index].items():
  assert glyph_raster(faces[0],coverage[0][cp])==glyph_raster(faces[index],gid),(index,hex(cp),'raster/advance')
 counts.append({'format':['bdf','pcf','ttf'][index],'glyphs':len(coverage[index]),'all_pixels_advances':True})
 print('freetype',counts[-1],flush=True)
f=TTFont(ttf,recalcTimestamp=False);f.ensureDecompiled();fonttools_glyphs=len(f.getGlyphOrder());f.close()
result=ots.sanitize(str(ttf),str(proof/'sanitized.ttf'),capture_output=True)
(proof/'ots.stdout').write_bytes(result.stdout);(proofof:=proof/'ots.stderr').write_bytes(result.stderr)
assert result.returncode==0,(result.returncode,result.stderr)
ft_clean=freetype.Face(str(proof/'sanitized.ttf'))
for cp,gid in coverage[2].items():assert glyph_raster(faces[2],gid)==glyph_raster(ft_clean,ft_clean.get_char_index(cp)),hex(cp)
print('OTS all full-font glyph rasters passed',flush=True)
small=base/'samples/fontpixel-catalogue/3x5/3x5-Regular-6px.bdf'
if not small.exists():small=next((base/'samples/fontpixel-catalogue/3x5').glob('*.bdf'))
mini=proof/'oracle-mini.ttf';mini.write_bytes(Font().load_file_path(str(small)).tottf())
f=TTFont(mini,recalcTimestamp=False);f.flavor='woff2';f.flavorData=WOFF2FlavorData(transformedTables={'glyf','loca','hmtx'});web=proof/'oracle-mini.woff2';f.save(web);f.close()
web_check=web_equivalent(mini,web,proof)
loaded=monobit.load(str(small));assert len(loaded)==1
result={'formal':False,'native_fontpixel_comparison':False,'full_input_sha256':sha(source),'independent_freetype':counts,'fonttools_all_tables':True,'sfnt_glyphs':fonttools_glyphs,'ots':{'exit':0,'full_pixels_advances_after_sanitize':True,'input_sha256':sha(ttf),'output_sha256':sha(proof/'sanitized.ttf')},'small_woff2':web_check,'monobit':{'input':str(small),'input_sha256':sha(small),'glyphs':len(loaded[0].glyphs)}}
(proof/'external-font-checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
