// fontpixel-recovery-baseline-20261004T1837/fontpixel-rs-phase6-handoff/local-work/phase6-performance/reference/bdfparser-js/src/constants.ts
var VERSION = "3.0.0";
var PATTERN_VVECTOR_DELIMITER = /[\s,]+/;
var EMPTY_GLYPH = {
  glyphname: ".notdef",
  codepoint: 0,
  bbw: 0,
  bbh: 0,
  bbxoff: 0,
  bbyoff: 0,
  swx0: 0,
  swy0: 0,
  dwx0: 0,
  dwy0: 0,
  swx1: 0,
  swy1: 0,
  dwx1: 0,
  dwy1: 0,
  vvectorx: 0,
  vvectory: 0,
  hexdata: []
};
var META_TITLES = [
  "glyphname",
  "codepoint",
  "bbw",
  "bbh",
  "bbxoff",
  "bbyoff",
  "swx0",
  "swy0",
  "dwx0",
  "dwy0",
  "swx1",
  "swy1",
  "dwx1",
  "dwy1",
  "vvectorx",
  "vvectory",
  "hexdata"
];
var DIRE_SHORTCUT_MAP = {
  lr: "lrtb",
  rl: "rltb",
  tb: "tbrl",
  bt: "btrl",
  lrtb: void 0,
  lrbt: void 0,
  rltb: void 0,
  rlbt: void 0,
  tbrl: void 0,
  tblr: void 0,
  btrl: void 0,
  btlr: void 0
};
var DIRE_MAP = { lr: 1, rl: 2, tb: 0, bt: -1 };

// fontpixel-recovery-baseline-20261004T1837/fontpixel-rs-phase6-handoff/local-work/phase6-performance/reference/bdfparser-js/src/fmt.ts
var PY_SPACE = "\\t\\n\\v\\f\\r\\x1c-\\x1f \\x85\\xa0\\u1680\\u2000-\\u200a\\u2028\\u2029\\u202f\\u205f\\u3000";
var RE_PY_STRIP = /* @__PURE__ */ new RegExp(
  `^[${PY_SPACE}]+|[${PY_SPACE}]+$`,
  "g"
);
var pyStrip = (s) => s.replace(RE_PY_STRIP, "");
var RE_PY_LEADING_INT = /* @__PURE__ */ new RegExp(
  `^[${PY_SPACE}]*([+-]?[0-9]+)`
);
var pyLeadingInt = (s) => {
  const m = RE_PY_LEADING_INT.exec(s);
  return m === null ? null : m[1];
};
var fmtnum = (n) => {
  if (typeof n === "bigint") {
    return n.toString();
  }
  if (Number.isInteger(n)) {
    return Number.isSafeInteger(n) ? String(n) : BigInt(n).toString();
  }
  if (!Number.isFinite(n)) {
    return Number.isNaN(n) ? "nan" : n > 0 ? "inf" : "-inf";
  }
  const [mant, exp] = n.toExponential().split("e");
  const e = parseInt(exp, 10);
  if (e < -4 || e >= 16) {
    return `${mant}e${e < 0 ? "-" : "+"}${String(Math.abs(e)).padStart(2, "0")}`;
  }
  return String(n);
};

// fontpixel-recovery-baseline-20261004T1837/fontpixel-rs-phase6-handoff/local-work/phase6-performance/reference/bdfparser-js/src/outline.ts
var rnd = (v) => Math.floor(v + 0.5);
var K = 1.082392200292394;
var D = 0.7071067811865476;
var CIRCLE_DIRS = [
  [0, 1],
  [D, D],
  [1, 0],
  [D, -D],
  [0, -1],
  [-D, -D],
  [-1, 0],
  [-D, D]
];
var bitmapContours = (bindata, options = {}) => {
  const shape = options.shape ?? "square";
  const dotsize = options.dotsize ?? 1;
  const ppu = options.ppu ?? 1;
  const xoff = options.xoff ?? 0;
  const yoff = options.yoff ?? 0;
  if (shape !== "square" && shape !== "circle") {
    throw new Error(
      `Invalid shape "${String(shape)}": must be "square" or "circle"`
    );
  }
  if (!(typeof dotsize === "number" && dotsize > 0 && dotsize <= 1.5)) {
    throw new RangeError(
      `Invalid dotsize ${String(dotsize)}: must be in (0, 1.5]`
    );
  }
  if (!Number.isInteger(ppu) || ppu < 1) {
    throw new RangeError(
      `Invalid ppu ${String(ppu)}: must be a positive integer`
    );
  }
  const h = bindata.length;
  let w = 0;
  const ink = [];
  for (let r = 0; r < h; r++) {
    const row = bindata[h - 1 - r];
    const a = new Array(row.length);
    for (let c = 0; c < row.length; c++) {
      a[c] = row[c] !== "0";
    }
    ink.push(a);
    w = Math.max(w, row.length);
  }
  if (w === 0) {
    return [];
  }
  if (shape === "square" && dotsize === 1) {
    return mergedContours(ink, w, h, ppu, xoff, yoff);
  }
  return dotContours(ink, h, shape, dotsize, ppu, xoff, yoff);
};
var dotContours = (ink, h, shape, dotsize, ppu, xoff, yoff) => {
  const contours = [];
  const s = dotsize * ppu / 2;
  const R = s * K;
  for (let r = 0; r < h; r++) {
    for (let c = 0; c < ink[r].length; c++) {
      if (!ink[r][c]) {
        continue;
      }
      const cx = (xoff + c + 0.5) * ppu;
      const cy = (yoff + r + 0.5) * ppu;
      if (shape === "square") {
        contours.push([
          [rnd(cx - s), rnd(cy - s), true],
          [rnd(cx - s), rnd(cy + s), true],
          [rnd(cx + s), rnd(cy + s), true],
          [rnd(cx + s), rnd(cy - s), true]
        ]);
      } else {
        contours.push(
          CIRCLE_DIRS.map(([dx, dy]) => [
            rnd(cx + R * dx),
            rnd(cy + R * dy),
            false
          ])
        );
      }
    }
  }
  return contours;
};
var mergedContours = (ink, w, h, ppu, xoff, yoff) => {
  const isInk = (c, r) => r >= 0 && r < h && c >= 0 && c < ink[r].length && ink[r][c];
  const vw = w + 1;
  const esx = [];
  const esy = [];
  const edx = [];
  const edy = [];
  const outgoing = /* @__PURE__ */ new Map();
  const addEdge = (sx, sy, dx, dy) => {
    const i = esx.length;
    esx.push(sx);
    esy.push(sy);
    edx.push(dx);
    edy.push(dy);
    const k = sy * vw + sx;
    const l = outgoing.get(k);
    if (l === void 0) {
      outgoing.set(k, [i]);
    } else {
      l.push(i);
    }
  };
  for (let r = 0; r < h; r++) {
    for (let c = 0; c < ink[r].length; c++) {
      if (!ink[r][c]) {
        continue;
      }
      if (!isInk(c, r - 1)) {
        addEdge(c + 1, r, -1, 0);
      }
      if (!isInk(c - 1, r)) {
        addEdge(c, r, 0, 1);
      }
      if (!isInk(c, r + 1)) {
        addEdge(c, r + 1, 1, 0);
      }
      if (!isInk(c + 1, r)) {
        addEdge(c + 1, r + 1, 0, -1);
      }
    }
  }
  const n = esx.length;
  const used = new Uint8Array(n);
  const contours = [];
  let first = 0;
  for (; ; ) {
    while (first < n && used[first]) {
      first++;
    }
    if (first >= n) {
      break;
    }
    const startx = esx[first];
    const starty = esy[first];
    const path = [];
    let e = first;
    for (; ; ) {
      used[e] = 1;
      path.push(e);
      const vx = esx[e] + edx[e];
      const vy = esy[e] + edy[e];
      if (vx === startx && vy === starty) {
        break;
      }
      const cands = outgoing.get(vy * vw + vx);
      const dx = edx[e];
      const dy = edy[e];
      let next = -1;
      let nextRank = 3;
      if (cands !== void 0) {
        for (const o of cands) {
          if (used[o]) {
            continue;
          }
          const odx = edx[o];
          const ody = edy[o];
          let rank;
          if (odx === dy && ody === -dx) {
            rank = 0;
          } else if (odx === dx && ody === dy) {
            rank = 1;
          } else if (odx === -dy && ody === dx) {
            rank = 2;
          } else {
            continue;
          }
          if (rank < nextRank) {
            nextRank = rank;
            next = o;
          }
        }
      }
      if (next < 0) {
        throw new Error("Internal error: open contour while tracing bitmap");
      }
      e = next;
    }
    const m = path.length;
    const pts = [];
    for (let i = 0; i < m; i++) {
      const cur = path[i];
      const prev = path[(i + m - 1) % m];
      if (edx[cur] === edx[prev] && edy[cur] === edy[prev]) {
        continue;
      }
      pts.push([esx[cur], esy[cur]]);
    }
    let best = 0;
    for (let i = 1; i < pts.length; i++) {
      const [bx, by] = pts[best];
      const [x, y] = pts[i];
      if (y < by || y === by && x < bx) {
        best = i;
      }
    }
    const contour = [];
    for (let i = 0; i < pts.length; i++) {
      const [x, y] = pts[(best + i) % pts.length];
      contour.push([(xoff + x) * ppu, (yoff + y) * ppu, true]);
    }
    contours.push(contour);
  }
  return contours;
};
var flattenInto = (contour, PX, PY, skipY) => {
  const n = contour.length;
  let len = 0;
  if (n === 0) {
    return 0;
  }
  let s = -1;
  for (let i = 0; i < n; i++) {
    if (contour[i][2]) {
      s = i;
      break;
    }
  }
  let x0;
  let y0;
  if (s < 0) {
    const a = contour[n - 1];
    const b = contour[0];
    x0 = (a[0] + b[0]) / 2;
    y0 = (a[1] + b[1]) / 2;
    s = 0;
  } else {
    x0 = contour[s][0];
    y0 = contour[s][1];
    s += 1;
  }
  const sx = x0;
  const sy = y0;
  PX[len] = x0;
  PY[len++] = y0;
  let cx = 0;
  let cy = 0;
  let ctrl = false;
  const quad = (x2, y2) => {
    if (skipY !== void 0 && skipY(Math.min(y0, cy, y2), Math.max(y0, cy, y2))) {
      PX[len] = x2;
      PY[len++] = y2;
      x0 = x2;
      y0 = y2;
      return;
    }
    for (let k = 1; k < 16; k++) {
      const t = k / 16;
      const mt = 1 - t;
      const a = mt * mt;
      const b = 2 * mt * t;
      const c = t * t;
      PX[len] = a * x0 + b * cx + c * x2;
      PY[len++] = a * y0 + b * cy + c * y2;
    }
    PX[len] = x2;
    PY[len++] = y2;
    x0 = x2;
    y0 = y2;
  };
  const total = n - (s === 0 && !contour[0][2] ? 0 : 1);
  for (let j = 0; j <= total; j++) {
    let px;
    let py;
    let on;
    if (j === total) {
      px = sx;
      py = sy;
      on = true;
    } else {
      const p = contour[(s + j) % n];
      px = p[0];
      py = p[1];
      on = p[2];
    }
    if (on) {
      if (ctrl) {
        quad(px, py);
        ctrl = false;
      } else {
        x0 = px;
        y0 = py;
        PX[len] = px;
        PY[len++] = py;
      }
    } else {
      if (ctrl) {
        quad((cx + px) / 2, (cy + py) / 2);
      }
      cx = px;
      cy = py;
      ctrl = true;
    }
  }
  return len;
};
var rasterize = (contours, ppu, xminPx, yminPx, wPx, hPx) => {
  if (wPx <= 0 || hPx <= 0) {
    return hPx > 0 ? new Array(hPx).fill("") : [];
  }
  const ys = [];
  for (let r = 0; r < hPx; r++) ys.push((yminPx + r + 0.5) * ppu);
  const xs = [];
  for (let c = 0; c < wPx; c++) xs.push((xminPx + c + 0.5) * ppu);
  const cx = [];
  const cd = [];
  for (let r = 0; r < hPx; r++) {
    cx.push([]);
    cd.push([]);
  }
  const firstRow = (lo) => {
    let r = Math.ceil(lo / ppu - yminPx - 0.5);
    if (r < 0) r = 0;
    if (r > hPx) r = hPx;
    while (r > 0 && ys[r - 1] >= lo) r--;
    while (r < hPx && ys[r] < lo) r++;
    return r;
  };
  const skipY = (lo, hi) => {
    const eps = 1e-9 * (Math.abs(lo) + Math.abs(hi) + 1);
    const r = firstRow(lo - eps);
    return r >= hPx || ys[r] > hi + eps;
  };
  const PX = [];
  const PY = [];
  for (const contour of contours) {
    if (contour.length < 2) {
      continue;
    }
    const len = flattenInto(contour, PX, PY, skipY);
    for (let i = 0; i + 1 < len; i++) {
      const x0 = PX[i];
      const y0 = PY[i];
      const x1 = PX[i + 1];
      const y1 = PY[i + 1];
      if (y0 === y1) {
        continue;
      }
      const up = y0 < y1;
      const lo = up ? y0 : y1;
      const hi = up ? y1 : y0;
      for (let r = firstRow(lo); r < hPx; r++) {
        const Y = ys[r];
        if (!(Y < hi)) break;
        cx[r].push(x0 + (Y - y0) * (x1 - x0) / (y1 - y0));
        cd[r].push(up ? 1 : -1);
      }
    }
  }
  const rows = [];
  for (let r = hPx - 1; r >= 0; r--) {
    const X = cx[r];
    const Dd = cd[r];
    const nc = X.length;
    if (nc === 0) {
      rows.push("0".repeat(wPx));
      continue;
    }
    for (let i = 1; i < nc; i++) {
      const vx = X[i];
      const vd = Dd[i];
      let j = i - 1;
      while (j >= 0 && X[j] > vx) {
        X[j + 1] = X[j];
        Dd[j + 1] = Dd[j];
        j--;
      }
      X[j + 1] = vx;
      Dd[j + 1] = vd;
    }
    let acc = 0;
    for (let i = 0; i < nc; i++) acc += Dd[i];
    let k = 0;
    let row = "";
    for (let c = 0; c < wPx; c++) {
      const xc = xs[c];
      while (k < nc && X[k] <= xc) {
        acc -= Dd[k];
        k++;
      }
      row += acc !== 0 ? "1" : "0";
    }
    rows.push(row);
  }
  return rows;
};

// fontpixel-recovery-baseline-20261004T1837/fontpixel-rs-phase6-handoff/local-work/phase6-performance/reference/bdfparser-js/src/warn.ts
var defaultWarningHandler = (message) => {
  console.warn("[bdfparser] " + message);
};
var currentHandler = defaultWarningHandler;
var warn = (message) => {
  if (currentHandler !== null) {
    currentHandler(message);
  }
};
var setWarningHandler = (handler) => {
  const previous = currentHandler;
  currentHandler = handler === void 0 ? defaultWarningHandler : handler;
  return previous;
};

// fontpixel-recovery-baseline-20261004T1837/fontpixel-rs-phase6-handoff/local-work/phase6-performance/reference/bdfparser-js/src/Bitmap.ts
var DEFAULT_PIXELCOLORS = { "0": null, "1": "black", "2": "red" };
var FROMSTRING_MAP = {
  "#": "1",
  ".": "0",
  "&": "2",
  "0": "0",
  "1": "1",
  "2": "2"
};
var ORed = (a, b) => b !== void 0 && b !== "0" ? b : a;
var cropString = (s, start, length) => {
  let stemp = s;
  const l = s.length;
  let left = 0;
  if (start < 0) {
    left = 0 - start;
    stemp = stemp.padStart(left + l, "0");
  }
  if (start + length > l) {
    stemp = stemp.padEnd(start + length - l + stemp.length, "0");
  }
  const newstart = start + left;
  return stemp.slice(newstart, newstart + length);
};
var stringOffsetConcat = (s1, s2, offset) => {
  const _offset = offset ?? 0;
  if (_offset === 0) {
    return s1 + s2;
  }
  const len1 = s1.length;
  const len2 = s2.length;
  const s2start = len1 + _offset;
  const s2end = s2start + len2;
  const finalstart = Math.min(0, s2start);
  const finalend = Math.max(len1, s2end);
  const news1 = cropString(s1, finalstart, finalend - finalstart);
  const news2 = cropString(s2, finalstart - s2start, finalend - finalstart);
  let ret = "";
  for (let i = 0; i < news1.length; i++) {
    ret += ORed(news1[i], news2[i]);
  }
  return ret;
};
var listofstrOffsetConcat = (list1, list2, offset) => {
  const _offset = offset ?? 0;
  let s1, s2;
  if (_offset === 0) {
    return list1.concat(list2);
  }
  const width = list1.length > 0 ? list1[0].length : list2[0]?.length ?? 0;
  const len1 = list1.length;
  const len2 = list2.length;
  const s2start = len1 + _offset;
  const s2end = s2start + len2;
  const finalstart = Math.min(0, s2start);
  const finalend = Math.max(len1, s2end);
  const retlist = [];
  for (let i = finalstart; i < finalend; i++) {
    if (i < 0 || i >= len1) {
      s1 = "0".repeat(width);
    } else {
      s1 = list1[i];
    }
    if (i < s2start || i >= s2end) {
      s2 = "0".repeat(width);
    } else {
      s2 = list2[i - s2start];
    }
    let row = "";
    for (let j = 0; j < s1.length; j++) {
      row += ORed(s1[j], s2[j]);
    }
    retlist.push(row);
  }
  return retlist;
};
var cropBitmap = (bitmap, w, h, xoff, yoff) => {
  let bn;
  const retlist = [];
  const l = bitmap.length;
  for (let n = 0; n < h; n++) {
    bn = l - yoff - h + n;
    if (bn < 0 || bn >= l) {
      retlist.push("0".repeat(w));
    } else {
      retlist.push(cropString(bitmap[bn], xoff, w));
    }
  }
  return retlist;
};
var enlargeBindata = (bindata, x, y) => {
  const _x = x ?? 1;
  const _y = y ?? 1;
  let ret = [...bindata];
  if (_x > 1) {
    ret = ret.map(
      (v) => v.split("").map((c) => c.repeat(_x)).join("")
    );
  }
  if (_y > 1) {
    ret = ret.flatMap((row) => Array(_y).fill(row));
  }
  return ret;
};
var Bitmap = class {
  bindata;
  /**
   * Initialize a `Bitmap` object. Load binary bitmap data (`array` of `string`s).
   *
   * @param bin_bitmap_list - Binary bitmap data
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/bitmap}
   */
  constructor(bin_bitmap_list) {
    this.bindata = bin_bitmap_list;
  }
  /**
   * Create a `Bitmap` from its `toString()` representation (`#` = 1, `.` = 0,
   * `&` = 2; the digits `0`, `1`, `2` are also accepted). Rows are separated by
   * newlines (`\r` is ignored); blank lines at the start and the end are
   * ignored.
   *
   * @param text - Text representation
   *
   * @returns New `Bitmap` object
   *
   * @throws Error on an invalid character or rows of different lengths
   *
   * @example
   * Bitmap.fromstring('.#.\n###\n.#.')
   */
  static fromstring(text) {
    const lines = text.replace(/\r/g, "").split("\n");
    while (lines.length > 0 && pyStrip(lines[0]) === "") {
      lines.shift();
    }
    while (lines.length > 0 && pyStrip(lines[lines.length - 1]) === "") {
      lines.pop();
    }
    const rows = lines.map((line, i) => {
      let row = "";
      for (const c of line) {
        const v = FROMSTRING_MAP[c];
        if (v === void 0) {
          throw new Error(
            `Invalid character ${JSON.stringify(c)} in bitmap row ${i}`
          );
        }
        row += v;
      }
      return row;
    });
    if (rows.some((r) => r.length !== rows[0].length)) {
      throw new Error("Bitmap rows have different lengths");
    }
    return newBitmap(rows);
  }
  /**
   * Create an empty (all `'0'`) bitmap.
   *
   * @param w - Width
   * @param h - Height
   *
   * @returns New `Bitmap` object
   */
  static blank(w, h) {
    if (w < 0 || h < 0) {
      throw new RangeError("Bitmap size must not be negative");
    }
    return newBitmap(Array.from({ length: h }, () => "0".repeat(w)));
  }
  /**
   * Gets a human-readable (multi-line) `string` representation of the `Bitmap` object.
   *
   * @returns String representation
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/bitmap#tostring}
   */
  toString() {
    return this.bindata.join("\n").replace(/0/g, ".").replace(/1/g, "#").replace(/2/g, "&");
  }
  /**
   * Gets a programmer-readable (multi-line) `string` representation of the `Bitmap` object.
   *
   * @returns String representation
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/bitmap#repr}
   */
  repr() {
    return `Bitmap(${JSON.stringify(this.bindata, null, 2)})`;
  }
  /**
   * Whether two bitmaps have the same `bindata`.
   *
   * @param other - Other bitmap
   *
   * @returns `true` if equal
   */
  equals(other) {
    const a = this.bindata;
    const b = other.bindata;
    return a.length === b.length && a.every((row, i) => row === b[i]);
  }
  /**
   * Get the width of the bitmap (`0` for an empty bitmap).
   *
   * @returns Width of the bitmap
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/bitmap#width}
   */
  width() {
    return this.bindata.length > 0 ? this.bindata[0].length : 0;
  }
  /**
   * Get the height of the bitmap.
   *
   * @returns Height of the bitmap
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/bitmap#height}
   */
  height() {
    return this.bindata.length;
  }
  /**
   * Get a deep copy / clone of the `Bitmap` object.
   *
   * @returns A deep copy of the original `Bitmap` object
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/bitmap#clone}
   */
  clone() {
    return newBitmap([...this.bindata]);
  }
  /**
   * Crop and/or extend the bitmap.
   *
   * @param w - Width
   * @param h - Height
   * @param xoff - X offset (from the left)
   * @param yoff - Y offset (from the bottom, y up)
   *
   * @returns The `Bitmap` object itself, which now has only the specified area as its `.bindata`
   *
   * @throws RangeError if `w` or `h` is negative
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/bitmap#crop}
   */
  crop(w, h, xoff, yoff) {
    if (w < 0 || h < 0) {
      throw new RangeError(
        `Bitmap.crop: negative width or height (${String(w)}, ${String(h)})`
      );
    }
    const _xoff = xoff ?? 0;
    const _yoff = yoff ?? 0;
    this.bindata = cropBitmap(this.bindata, w, h, _xoff, _yoff);
    return this;
  }
  /**
   * Overlay another bitmap over the current one.
   *
   * @param bitmap - The incoming bitmap to overlay over the current one
   *
   * @returns The `Bitmap` object itself, which now has the combined bitmap as its `.bindata`
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/bitmap#overlay}
   */
  overlay(bitmap) {
    const bindata_a = this.bindata;
    const bindata_b = bitmap.bindata;
    if (bindata_a.length !== bindata_b.length) {
      warn("the bitmaps to overlay have different height");
    }
    if (this.width() !== bitmap.width()) {
      warn("the bitmaps to overlay have different width");
    }
    this.bindata = bindata_a.map((la, li) => {
      const lb = bindata_b[li] ?? "";
      let row = "";
      for (let i = 0; i < la.length; i++) {
        row += ORed(la[i], lb[i]);
      }
      return row;
    });
    return this;
  }
  /**
   * Concatenate all `Bitmap` objects in an `array`.
   *
   * @param bitmaplist - List of bitmaps to concatenate
   * @param options.direction - Direction
   * @param options.align - Align
   * @param options.offsetlist - List of spacing offsets between every two bitmaps
   *
   * @returns `Bitmap` object
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/bitmap#bitmapconcatall}
   */
  static concatall(bitmaplist, options = {}) {
    const _direction = options.direction ?? 1;
    const _align = options.align ?? 1;
    const _offsetlist = options.offsetlist ?? null;
    if (bitmaplist.length === 0) {
      return newBitmap([]);
    }
    let bd, ireal, maxsize, offset, ret, w, xoff;
    if (_direction > 0) {
      maxsize = Math.max(...bitmaplist.map((val) => val.height()));
      ret = Array(maxsize).fill("");
      const stroffconcat = (s1, s2, offset2) => {
        if (_direction === 1) {
          return stringOffsetConcat(s1, s2, offset2);
        } else {
          return stringOffsetConcat(s2, s1, offset2);
        }
      };
      for (let i = 0; i < maxsize; i++) {
        if (_align) {
          ireal = -i - 1;
        } else {
          ireal = i;
        }
        offset = 0;
        const bl = bitmaplist.length;
        for (let bi = 0; bi < bl; bi++) {
          const bitmap = bitmaplist[bi];
          if (_offsetlist && bi !== 0) {
            offset = _offsetlist[bi - 1];
          }
          if (i < bitmap.height()) {
            if (ireal >= 0) {
              ret[ireal] = stroffconcat(
                ret[ireal],
                bitmap.bindata[ireal],
                offset
              );
            } else {
              ret[maxsize + ireal] = stroffconcat(
                ret[maxsize + ireal],
                bitmap.bindata[bitmap.height() + ireal],
                offset
              );
            }
          } else {
            if (ireal >= 0) {
              ret[ireal] = stroffconcat(
                ret[ireal],
                "0".repeat(bitmap.width()),
                offset
              );
            } else {
              ret[maxsize + ireal] = stroffconcat(
                ret[maxsize + ireal],
                "0".repeat(bitmap.width()),
                offset
              );
            }
          }
        }
      }
    } else {
      const kept = [];
      bitmaplist.forEach((bitmap, bi) => {
        if (bitmap.height() > 0 && bitmap.width() > 0) {
          const off = _offsetlist && bi !== 0 ? _offsetlist[bi - 1] : 0;
          kept.push([bitmap, kept.length > 0 ? off : 0]);
        }
      });
      if (kept.length === 0) {
        return new this([]);
      }
      maxsize = Math.max(...kept.map(([val]) => val.width()));
      ret = [];
      for (const [bitmap, off] of kept) {
        offset = off;
        bd = bitmap.bindata;
        w = bitmap.width();
        if (w !== maxsize) {
          if (_align) {
            xoff = 0;
          } else {
            xoff = w - maxsize;
          }
          bd = cropBitmap(bd, maxsize, bitmap.height(), xoff, 0);
        }
        if (_direction === 0) {
          ret = listofstrOffsetConcat(ret, bd, offset);
        } else {
          ret = listofstrOffsetConcat(bd, ret, offset);
        }
      }
    }
    return new this(ret);
  }
  /**
   * Concatenate another `Bitmap` objects to the current one.
   *
   * @param bitmap - Bitmap to concatenate
   * @param options.direction - Direction
   * @param options.align - Align
   * @param options.offset - Spacing offset between the bitmaps
   *
   * @returns The `Bitmap` object itself, which now has the combined bitmap as its `.bindata`
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/bitmap#concat}
   */
  concat(bitmap, options = {}) {
    const { direction, align, offset } = options;
    const _offset = offset ?? 0;
    this.bindata = concatallBitmaps([this, bitmap], {
      direction,
      align,
      offsetlist: [_offset]
    }).bindata;
    return this;
  }
  /**
   * Enlarge a `Bitmap` object, by multiplying every pixel in x (right) direction and in y (top) direction.
   *
   * @param x - Multiplier in x (right) direction
   * @param y - Multiplier in y (top) direction
   *
   * @returns The `Bitmap` object itself, which now has the enlarged bitmap as its `.bindata`
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/bitmap#enlarge}
   */
  enlarge(x, y) {
    this.bindata = enlargeBindata(this.bindata, x, y);
    return this;
  }
  /**
   * Replace a string by another in the bitmap.
   *
   * @param substr - Substring to be replaced
   * @param newsubstr - New substring as the replacement
   *
   * @returns The `Bitmap` object itself, which now has the altered bitmap as its `.bindata`
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/bitmap#replace}
   */
  replace(substr, newsubstr) {
    const _substr = String(substr);
    const _newsubstr = String(newsubstr);
    this.bindata = this.bindata.map(
      (val) => val.split(_substr).join(_newsubstr)
    );
    return this;
  }
  /**
   * Add shadow to the shape in the bitmap.
   *
   * The shadow will be filled by `'2'`s.
   *
   * @param xoff - Shadow's offset in x (right) direction
   * @param yoff - Shadow's offset in y (top) direction
   *
   * @returns The `Bitmap` object itself, which now has a bitmap of the original shape with its shadow as the `Bitmap` object's `.bindata`
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/bitmap#shadow}
   */
  shadow(xoff, yoff) {
    const _xoff = xoff ?? 1;
    const _yoff = yoff ?? -1;
    let resized_xoff, resized_yoff, shadow_xoff, shadow_yoff;
    const bitmap_shadow = this.clone();
    const w = this.width() + Math.abs(_xoff);
    const h = this.height() + Math.abs(_yoff);
    bitmap_shadow.bindata = bitmap_shadow.bindata.map(
      (val) => val.replace(/1/g, "2")
    );
    if (_xoff > 0) {
      resized_xoff = 0;
      shadow_xoff = -_xoff;
    } else {
      resized_xoff = _xoff;
      shadow_xoff = 0;
    }
    if (_yoff > 0) {
      resized_yoff = 0;
      shadow_yoff = -_yoff;
    } else {
      resized_yoff = _yoff;
      shadow_yoff = 0;
    }
    this.crop(w, h, resized_xoff, resized_yoff);
    bitmap_shadow.crop(w, h, shadow_xoff, shadow_yoff);
    bitmap_shadow.overlay(this);
    this.bindata = bitmap_shadow.bindata;
    return this;
  }
  /**
   * Add glow effect to the shape in the bitmap.
   *
   * The glowing area is one pixel up, right, bottom and left to the original pixels (corners will not be filled in default mode 0 but will in mode 1), and will be filled by `'2'`s.
   *
   * @param mode - Mode
   *
   * @returns The `Bitmap` object itself, which now has a bitmap of the original shape with glow effect as the `Bitmap` object's `.bindata`
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/bitmap#glow}
   */
  glow(mode) {
    const _mode = mode ?? 0;
    this.crop(this.width() + 2, this.height() + 2, -1, -1);
    const b = this.todata(2);
    const bl = b.length;
    for (let i_line = 0; i_line < bl; i_line++) {
      const line = b[i_line];
      const ll = line.length;
      for (let i_pixel = 0; i_pixel < ll; i_pixel++) {
        if (line[i_pixel] === 1) {
          b[i_line][i_pixel - 1] ||= 2;
          b[i_line][i_pixel + 1] ||= 2;
          b[i_line - 1][i_pixel] ||= 2;
          b[i_line + 1][i_pixel] ||= 2;
          if (_mode === 1) {
            b[i_line - 1][i_pixel - 1] ||= 2;
            b[i_line - 1][i_pixel + 1] ||= 2;
            b[i_line + 1][i_pixel - 1] ||= 2;
            b[i_line + 1][i_pixel + 1] ||= 2;
          }
        }
      }
    }
    this.bindata = b.map((l) => l.join(""));
    return this;
  }
  /**
   * Pad each line (row) to multiple of 8 (or other numbers) bits/pixels, with `'0'`s.
   *
   * Do this before using the bitmap for a glyph in a BDF font.
   *
   * @param bits - Each line should be padded to multiple of how many bits/pixels
   *
   * @returns The `Bitmap` object itself, which now has the altered bitmap as its `.bindata`
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/bitmap#bytepad}
   */
  bytepad(bits) {
    const _bits = bits ?? 8;
    const w = this.width();
    const h = this.height();
    const mod = w % _bits;
    if (mod === 0) {
      return this;
    }
    return this.crop(w + _bits - mod, h);
  }
  /**
   * Get the bitmap's data in the specified type and format.
   *
   * @param datatype - Output data type
   *
   * @returns Bitmap data in the specified type (list or string) and format
   *
   * @throws RangeError for `datatype` 5 if a row is wider than 53 pixels (not exactly representable as a `number`)
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/bitmap#todata}
   */
  todata(datatype) {
    const _datatype = datatype ?? 1;
    let ret;
    const checkBinary = (s) => {
      if (!/^[01]*$/.test(s)) {
        throw new Error(`Invalid binary string: ${s}`);
      }
    };
    switch (_datatype) {
      case 0:
        ret = this.bindata.join("\n");
        break;
      case 1:
        ret = this.bindata;
        break;
      case 2:
        ret = this.bindata.map((l) => l.split("").map((s) => parseInt(s, 10)));
        break;
      case 3:
        ret = [].concat(...this.todata(2));
        break;
      case 4: {
        const ndigits = Math.ceil(this.width() / 4);
        ret = this.bindata.map((s) => {
          checkBinary(s);
          return s === "" ? "" : BigInt("0b" + s).toString(16).padStart(ndigits, "0");
        });
        break;
      }
      case 5:
        ret = this.bindata.map((s) => {
          checkBinary(s);
          if (s.length > 53) {
            throw new RangeError(
              `todata(5): rows wider than 53 pixels cannot be represented exactly as numbers (row width ${s.length})`
            );
          }
          return s === "" ? 0 : parseInt(s, 2);
        });
        break;
    }
    return ret;
  }
  __checkxy(x, y) {
    if (!Number.isInteger(x) || !Number.isInteger(y) || y < 0 || y >= this.height() || x < 0 || x >= this.width()) {
      throw new RangeError(
        `Pixel (${x}, ${y}) is out of range of the ${this.width()}x${this.height()} bitmap`
      );
    }
  }
  /**
   * Get the value (0, 1 or 2) of the pixel at `(x, y)` (top-left origin, y down).
   *
   * @param x - Column (0 = left)
   * @param y - Row (0 = top)
   *
   * @returns Pixel value
   *
   * @throws RangeError if out of range
   */
  getpixel(x, y) {
    this.__checkxy(x, y);
    return parseInt(this.bindata[y][x], 10);
  }
  /**
   * Set the pixel at `(x, y)` (top-left origin, y down).
   *
   * @param x - Column (0 = left)
   * @param y - Row (0 = top)
   * @param value - 0, 1 (default) or 2
   *
   * @returns The `Bitmap` object itself
   *
   * @throws RangeError if out of range or `value` is not 0, 1 or 2
   */
  setpixel(x, y, value = 1) {
    if (value !== 0 && value !== 1 && value !== 2) {
      throw new RangeError(
        `Pixel value must be 0, 1 or 2, not ${String(value)}`
      );
    }
    this.__checkxy(x, y);
    const row = this.bindata[y];
    this.bindata = [...this.bindata];
    this.bindata[y] = row.slice(0, x) + String(value) + row.slice(x + 1);
    return this;
  }
  /**
   * Mirror the bitmap left ↔ right.
   *
   * @returns The `Bitmap` object itself
   */
  fliph() {
    this.bindata = this.bindata.map((row) => row.split("").reverse().join(""));
    return this;
  }
  /**
   * Mirror the bitmap top ↔ bottom.
   *
   * @returns The `Bitmap` object itself
   */
  flipv() {
    this.bindata = [...this.bindata].reverse();
    return this;
  }
  /**
   * Rotate the bitmap clockwise.
   *
   * @param angle - Angle in degrees, a multiple of 90 (negative = counter-clockwise), default 90
   *
   * @returns The `Bitmap` object itself
   *
   * @throws Error if `angle` is not a multiple of 90
   */
  rotate(angle = 90) {
    if (!Number.isInteger(angle) || angle % 90 !== 0) {
      throw new Error(
        `Rotation angle must be a multiple of 90, not ${String(angle)}`
      );
    }
    const turns = (angle / 90 % 4 + 4) % 4;
    for (let t = 0; t < turns; t++) {
      const src = this.bindata;
      const h = src.length;
      const w = this.width();
      const out = [];
      for (let c = 0; c < w; c++) {
        let row = "";
        for (let r = h - 1; r >= 0; r--) {
          row += src[r][c];
        }
        out.push(row);
      }
      this.bindata = out;
    }
    return this;
  }
  /**
   * Invert the bitmap: `'0'` becomes `'1'`, every other pixel becomes `'0'`.
   *
   * @returns The `Bitmap` object itself
   */
  invert() {
    this.bindata = this.bindata.map(
      (row) => row.replace(/./g, (p) => p === "0" ? "1" : "0")
    );
    return this;
  }
  /**
   * Move the content by `dx` pixels to the right and `dy` pixels up, keeping
   * the size; vacated pixels become `'0'`.
   *
   * @param dx - Pixels to the right
   * @param dy - Pixels up
   *
   * @returns The `Bitmap` object itself
   */
  shift(dx = 0, dy = 0) {
    return this.crop(this.width(), this.height(), -dx, -dy);
  }
  /**
   * Ink bounding box `[w, h, xoff, yoff]` in `crop()` convention (offsets from
   * the bottom-left), so `bitmap.crop(...bitmap.bbox())` trims the bitmap.
   * `[0, 0, 0, 0]` if there is no ink.
   *
   * @returns Bounding box
   */
  bbox() {
    const rows = [];
    this.bindata.forEach((row, i) => {
      if (/[^0]/.test(row)) {
        rows.push(i);
      }
    });
    if (rows.length === 0) {
      return [0, 0, 0, 0];
    }
    let left = Infinity;
    let right = -Infinity;
    for (const i of rows) {
      const row = this.bindata[i];
      left = Math.min(left, row.search(/[^0]/));
      right = Math.max(right, row.replace(/0+$/, "").length);
    }
    const top = rows[0];
    const bottom = rows[rows.length - 1];
    return [right - left, bottom - top + 1, left, this.height() - 1 - bottom];
  }
  /**
   * Remove empty rows and columns on all four sides (`crop(...bbox())`). A
   * bitmap without ink becomes empty (`bindata` is `[]`).
   *
   * @returns The `Bitmap` object itself
   */
  trim() {
    const bb = this.bbox();
    if (bb[0] === 0) {
      this.bindata = [];
      return this;
    }
    return this.crop(...bb);
  }
  /**
   * Embolden: the width grows by `n` and the result is the overlay of the
   * bitmap shifted right by 0 … `n` pixels.
   *
   * @param n - Pixels, default 1
   *
   * @returns The `Bitmap` object itself
   */
  bold(n = 1) {
    if (n < 0) {
      throw new RangeError("n must not be negative");
    }
    this.bindata = this.bindata.map((row) => {
      const cur = (row + "0".repeat(n)).split("");
      for (let k = 1; k <= n; k++) {
        for (let x = k; x < cur.length; x++) {
          const b = x - k < row.length ? row[x - k] : "0";
          if (b !== "0") {
            cur[x] = b;
          }
        }
      }
      return cur.join("");
    });
    return this;
  }
  /**
   * Slant the bitmap: the row at index `r` counted from the bottom (0 = bottom
   * row) is shifted right by `floor((r - base) / step)` pixels; the bitmap is
   * widened as needed.
   *
   * @param step - Rows per one pixel of shift (positive), default 2
   * @param base - Row (from the bottom) that is not shifted, default 0
   *
   * @returns The `Bitmap` object itself
   */
  italic(step = 2, base = 0) {
    if (!(step > 0)) {
      throw new RangeError("step must be a positive integer");
    }
    const h = this.height();
    if (h === 0) {
      return this;
    }
    const w = this.width();
    const shifts = Array.from(
      { length: h },
      (_, r) => Math.floor((r - base) / step)
    );
    const lo = Math.min(...shifts);
    const hi = Math.max(...shifts);
    const nw = w + hi - lo;
    this.bindata = this.bindata.map((row, i) => {
      const s = shifts[h - 1 - i] - lo;
      return "0".repeat(s) + row + "0".repeat(nw - s - w);
    });
    return this;
  }
  /**
   * Draw `bitmap` over this one with its top-left corner at `(x, y)` (top-left
   * origin, y down). Pixels outside are clipped; non-`'0'` source pixels win.
   * The size is unchanged.
   *
   * @param bitmap - Bitmap to paste
   * @param x - Column of its top-left corner
   * @param y - Row of its top-left corner
   *
   * @returns The `Bitmap` object itself
   */
  paste(bitmap, x = 0, y = 0) {
    const w = this.width();
    const out = [...this.bindata];
    bitmap.bindata.forEach((srow, j) => {
      const ty = y + j;
      if (ty < 0 || ty >= out.length) {
        return;
      }
      const row = out[ty].split("");
      for (let i = 0; i < srow.length; i++) {
        const tx = x + i;
        if (tx >= 0 && tx < w && srow[i] !== "0") {
          row[tx] = srow[i];
        }
      }
      out[ty] = row.join("");
    });
    this.bindata = out;
    return this;
  }
  /**
   * Draw the bitmap to an HTML canvas (or any object with `fillStyle` and
   * `fillRect`), one `fillRect(x + col * pixelsize, y + row * pixelsize,
   * pixelsize, pixelsize)` per non-transparent pixel.
   *
   * @param context - Canvas 2D context (`canvas.getContext('2d')`)
   * @param options.x - x of the bitmap's top-left corner, default 0
   * @param options.y - y of the bitmap's top-left corner, default 0
   * @param options.pixelsize - size of one pixel, default 1
   * @param options.pixelcolors - `{'0': color | null, '1': ..., '2': ...}`, default `{'0': null, '1': 'black', '2': 'red'}`
   *
   * Backward compatible with the v2 signature
   * `draw2canvas(context, pixelcolors?, xoff?, yoff?)`: if the 2nd argument
   * has any of the keys `'0'`, `'1'`, `'2'`, it is treated as `pixelcolors`.
   *
   * @returns The `Bitmap` object itself
   *
   * @example
   * bitmap.draw2canvas(ctx, { x: 10, y: 20, pixelsize: 4, pixelcolors: { '1': '#f00' } })
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/bitmap#draw2canvas}
   */
  draw2canvas(context, options, xoff, yoff) {
    let opts;
    if (options !== null && options !== void 0 && ("0" in options || "1" in options || "2" in options)) {
      opts = { pixelcolors: options, x: xoff, y: yoff };
    } else {
      opts = options ?? {
        x: xoff,
        y: yoff
      };
    }
    const colors = opts.pixelcolors ?? DEFAULT_PIXELCOLORS;
    const x0 = opts.x ?? 0;
    const y0 = opts.y ?? 0;
    const ps = opts.pixelsize ?? 1;
    let current = void 0;
    this.bindata.forEach((line, row) => {
      for (let col = 0; col < line.length; col++) {
        const s = line[col];
        if (s === "0" || s === "1" || s === "2") {
          const color = colors[s];
          if (color !== null && color !== void 0) {
            if (color !== current) {
              context.fillStyle = color;
              current = color;
            }
            context.fillRect(x0 + col * ps, y0 + row * ps, ps, ps);
          }
        }
      }
    });
    return this;
  }
  /**
   * Convert the bitmap to SVG.
   *
   * - `'path'`: a complete `<svg>` with one `<path>` (all square pixels merged
   *   into one outline, holes included);
   * - `'pathOnly'`: only the path data (`d` attribute);
   * - `'rect'`: a complete `<svg>` with one `<rect>` per greedy rectangle
   *   (square only).
   *
   * @param pixelsize - Nominal pixel size in the SVG, default 1
   * @param format - `'path'` (default), `'pathOnly'` or `'rect'`
   * @param inverted - y-up coordinates (for SVG fonts), default `false`
   * @param offsets - Offsets `{x, y}` added to every coordinate, default `{x: 0, y: 0}`
   * @param shape - `'square'` (default) or `'circle'` (round dots)
   *
   * @returns SVG string (or path data, depending on `format`)
   */
  tosvg(pixelsize = 1, format = "path", inverted = false, offsets = {}, shape = "square") {
    if (format !== "path" && format !== "pathOnly" && format !== "rect") {
      throw new Error(`Unknown SVG format ${JSON.stringify(format)}`);
    }
    if (shape !== "square" && shape !== "circle") {
      throw new Error(`Unknown shape ${JSON.stringify(shape)}`);
    }
    const xoff = offsets.x ?? 0;
    const yoff = offsets.y ?? 0;
    const bindata = this.bindata;
    const h = this.height();
    const w = this.width();
    const head = `<svg xmlns="http://www.w3.org/2000/svg" width="${fmtnum(
      w * pixelsize
    )}" height="${fmtnum(h * pixelsize)}">`;
    if (format === "rect") {
      if (shape !== "square") {
        throw new Error("format 'rect' only supports shape 'square'");
      }
      return head + this.__svgrects(pixelsize, inverted, xoff, yoff) + "</svg>";
    }
    const parts = [];
    if (shape === "circle") {
      const r = pixelsize / 2;
      const arc = `a${fmtnum(r)} ${fmtnum(r)} 0 1 0 `;
      for (let rb = 0; rb < h; rb++) {
        const row = bindata[h - 1 - rb];
        for (let c = 0; c < w; c++) {
          if (row[c] === "0") {
            continue;
          }
          const cx = (c + 0.5) * pixelsize + xoff;
          const cy = (inverted ? rb + 0.5 : h - rb - 0.5) * pixelsize + yoff;
          parts.push(
            `M${fmtnum(cx - r)} ${fmtnum(cy)}${arc}${fmtnum(
              2 * r
            )} 0${arc}${fmtnum(-2 * r)} 0Z`
          );
        }
      }
    } else if (h > 0 && w > 0) {
      for (const contour of bitmapContours(bindata, {
        shape: "square",
        dotsize: 1,
        ppu: 1
      })) {
        const pts = contour.map(([x, y]) => [
          x * pixelsize + xoff,
          (inverted ? y : h - y) * pixelsize + yoff
        ]);
        let seg = `M${fmtnum(pts[0][0])} ${fmtnum(pts[0][1])}`;
        let prevY = pts[0][1];
        for (let i = 1; i < pts.length; i++) {
          const [px, py] = pts[i];
          seg += py === prevY ? `H${fmtnum(px)}` : `V${fmtnum(py)}`;
          prevY = py;
        }
        parts.push(seg + "Z");
      }
    }
    const d = parts.join("");
    if (format === "pathOnly") {
      return d;
    }
    if (d === "") {
      return head + "</svg>";
    }
    return `${head}<path d="${d}" fill="#000000" /></svg>`;
  }
  __svgrects(pixelsize, inverted, xoff, yoff) {
    const bitmap = this.bindata;
    const height = this.height();
    const width = this.width();
    const visited = Array.from(
      { length: height },
      () => Array(width).fill(false)
    );
    const svgHeight = height * pixelsize;
    let out = "";
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        if (visited[y][x]) {
          continue;
        }
        const v = bitmap[y][x];
        let mw = 1;
        while (x + mw < width && bitmap[y][x + mw] === v && !visited[y][x + mw]) {
          mw++;
        }
        let mh = 1;
        outer: while (y + mh < height) {
          for (let dx = 0; dx < mw; dx++) {
            if (bitmap[y + mh][x + dx] !== v || visited[y + mh][x + dx]) {
              break outer;
            }
          }
          mh++;
        }
        for (let dy = 0; dy < mh; dy++) {
          for (let dx = 0; dx < mw; dx++) {
            visited[y + dy][x + dx] = true;
          }
        }
        if (v !== "0") {
          const rx = x * pixelsize + xoff;
          const ry = (inverted ? svgHeight - y * pixelsize - mh * pixelsize : y * pixelsize) + yoff;
          out += `<rect x="${fmtnum(rx)}" y="${fmtnum(ry)}" width="${fmtnum(
            mw * pixelsize
          )}" height="${fmtnum(mh * pixelsize)}" fill="#000000" />`;
        }
      }
    }
    return out;
  }
};
var newBitmap = (bindata) => new Bitmap(bindata);
var concatallBitmaps = (bitmaplist, options) => Bitmap.concatall(bitmaplist, options);

// fontpixel-recovery-baseline-20261004T1837/fontpixel-rs-phase6-handoff/local-work/phase6-performance/reference/bdfparser-js/src/Glyph.ts
var defaultglyphname = (cp, charsetIsUnicode = true) => {
  if (!charsetIsUnicode) {
    return `char${cp}`;
  }
  const hex = cp.toString(16).toUpperCase();
  return cp <= 65535 ? `uni${hex.padStart(4, "0")}` : `u${hex.padStart(5, "0")}`;
};
var HEX2BIN = /* @__PURE__ */ Object.create(null);
for (let i = 0; i < 16; i++) {
  const b = i.toString(2).padStart(4, "0");
  HEX2BIN[i.toString(16)] = b;
  HEX2BIN[i.toString(16).toUpperCase()] = b;
}
var hex2bin = (h) => {
  let s = "";
  for (const c of h) {
    const b = HEX2BIN[c];
    if (b === void 0) {
      return null;
    }
    s += b;
  }
  return s;
};
var hexRowError = (name, cp, row, hex) => new Error(
  `Glyph "${String(name)}" (codepoint ${String(cp)}): bitmap row ${row} ${JSON.stringify(hex)} contains a non-hex character`
);
var bin2hex = (row, ndigits) => {
  const bits = row.padEnd(ndigits * 4, "0");
  let s = "";
  for (let i = 0; i < ndigits * 4; i += 4) {
    s += parseInt(bits.slice(i, i + 4), 2).toString(16).toUpperCase();
  }
  return s;
};
var snapshot = (list) => {
  const l = [...list];
  if (Array.isArray(l[16])) {
    l[16] = [...l[16]];
  }
  return l;
};
var slotEquals = (a, b) => {
  if (Array.isArray(a) && Array.isArray(b)) {
    return a.length === b.length && a.every((v, i) => v === b[i]);
  }
  return a === b;
};
var warnedRows = /* @__PURE__ */ new WeakSet();
var metaToList = (meta) => META_TITLES.map((k) => meta[k]);
var listToMeta = (list) => {
  const d = {};
  META_TITLES.forEach((k, i) => {
    d[k] = list[i];
  });
  return d;
};
var Glyph = class {
  meta;
  font;
  __attached = false;
  __store = null;
  /** copy of the store as last seen by this object (see `Font._writeback`) */
  __synced = null;
  /**
   * `Glyph` object constructor
   *
   * @param meta_obj - Meta information (copied)
   * @param font - The font the glyph belongs to
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/glyph}
   */
  constructor(meta_obj, font) {
    this.meta = { ...meta_obj };
    this.font = font;
  }
  /**
   * @internal Attach the glyph to the 17-slot list stored in its font.
   */
  _attach(store) {
    this.__attached = true;
    this.__store = store;
    this.__synced = snapshot(store);
  }
  /**
   * @internal Copy of the font's 17-slot list as last seen by this object
   * (`null` if detached), to detect changes made to the font meanwhile.
   */
  get _synced() {
    return this.__attached ? this.__synced : null;
  }
  /** @internal Record the font's current 17-slot list as seen. */
  _setsynced(store) {
    this.__synced = snapshot(store);
  }
  /**
   * @internal Detach the glyph from its font.
   */
  _detach() {
    this.__attached = false;
  }
  /**
   * @internal The 17-slot list stored in the font (`null` if detached).
   */
  get _store() {
    return this.__attached ? this.__store : null;
  }
  /**
   * @internal The 17-slot list this glyph was last attached to, even if it
   * has been detached since (`null` if it was never attached).
   */
  get _slot() {
    return this.__store;
  }
  __sync() {
    if (this.__attached) {
      this.font._writeback(this);
    }
  }
  /**
   * Gets a human-readable (multi-line) `string` representation of the `Glyph` object.
   *
   * @returns String representation
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/glyph#tostring}
   */
  toString() {
    return this.draw().toString();
  }
  /**
   * Gets a programmer-readable `string` representation of the `Glyph` object.
   *
   * @returns String representation
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/glyph#repr}
   */
  repr() {
    return "Glyph(" + JSON.stringify(this.meta, null, 2) + ", Font(<" + String(this.font.headers?.fontname) + ">)";
  }
  /**
   * Get the codepoint of the glyph.
   *
   * @returns Codepoint of the glyph
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/glyph#cp}
   */
  cp() {
    return this.meta["codepoint"];
  }
  /**
   * Get the character of the glyph (converted with the font's charset).
   *
   * @returns Character (one character string) of the glyph, or `null` if the codepoint is not representable (e.g. unencoded glyphs)
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/glyph#chr}
   */
  chr() {
    return this.font.cp2char(this.cp());
  }
  /**
   * Draw the glyph to a `Bitmap` object.
   *
   * - `mode=0`: in the font's bounding box (FONTBOUNDINGBOX);
   * - `mode=1`: in the glyph's own bounding box (BBX);
   * - `mode=2`: the original hex data, including the padding bits;
   * - `mode=-1`: in the user specified bounding box `bb` (`[w, h, xoff, yoff]`).
   *
   * @param mode - Mode
   * @param bb - Bounding box
   *
   * @returns `Bitmap` object
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/glyph#draw}
   */
  draw(mode, bb) {
    const _mode = mode ?? 0;
    switch (_mode) {
      case 0:
        return this.__draw_fbb();
      case 1:
        return this.__draw_bb();
      case 2:
        return this.__draw_original();
      case -1:
        if (bb === null || bb === void 0) {
          throw new Error(
            "Parameter bb in draw() method must be set when mode=-1"
          );
        }
        return this.__draw_user_specified(bb);
      default:
        throw new Error(`Unknown draw mode ${String(_mode)}`);
    }
  }
  __draw_user_specified(fbb) {
    const bbxoff = this.meta["bbxoff"] || 0;
    const bbyoff = this.meta["bbyoff"] || 0;
    const [fbbx, fbby, fbbxoff, fbbyoff] = fbb;
    const bitmap = this.__draw_bb();
    return bitmap.crop(fbbx, fbby, -bbxoff + fbbxoff, -bbyoff + fbbyoff);
  }
  __draw_original() {
    return new Bitmap(
      (this.meta["hexdata"] ?? []).map((h, i) => {
        const b = hex2bin(h);
        if (b === null) {
          throw hexRowError(
            this.meta["glyphname"],
            this.meta["codepoint"],
            i,
            h
          );
        }
        return b;
      })
    );
  }
  __draw_bb() {
    const bbw = this.meta["bbw"] || 0;
    const bbh = this.meta["bbh"] || 0;
    const hexdata = this.meta["hexdata"] ?? [];
    let bindata = this.__draw_original().bindata;
    const n = bindata.length;
    if (n < bbh) {
      if (!warnedRows.has(hexdata)) {
        warnedRows.add(hexdata);
        warn(
          `Glyph "${String(this.meta["glyphname"])}" (codepoint ${String(
            this.meta["codepoint"]
          )}) has ${n} bitmap rows but its BBX height is ${bbh}; padded with empty rows`
        );
      }
      bindata = bindata.concat(Array(bbh - n).fill(""));
    }
    return new Bitmap(
      bindata.slice(0, bbh).map((b) => b.slice(0, bbw).padEnd(bbw, "0"))
    );
  }
  __draw_fbb() {
    const fh = this.font.headers;
    return this.__draw_user_specified([
      fh.fbbx ?? 0,
      fh.fbby ?? 0,
      fh.fbbxoff ?? 0,
      fh.fbbyoff ?? 0
    ]);
  }
  /**
   * Get the relative position (displacement) of the origin from the left bottom corner of the bitmap drawn by the method `.draw()`, or vice versa.
   *
   * @param options.mode - Mode
   * @param options.fromorigin - From or to the origin
   * @param options.xoff - X offset
   * @param options.yoff - Y offset
   *
   * @returns The relative position (displacement) represented by `[x, y]` array / tuple (where right and top directions are positive)
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/glyph#origin}
   */
  origin(options = {}) {
    const _mode = options.mode ?? 0;
    const _fromorigin = options.fromorigin ?? false;
    const _xoff = options.xoff ?? null;
    const _yoff = options.yoff ?? null;
    let ret;
    const bbxoff = this.meta["bbxoff"];
    const bbyoff = this.meta["bbyoff"];
    switch (_mode) {
      case 0: {
        const fh = this.font.headers;
        ret = [fh["fbbxoff"], fh["fbbyoff"]];
        break;
      }
      case 1:
      case 2:
        ret = [bbxoff, bbyoff];
        break;
      case -1:
        if (_xoff !== null && _yoff !== null) {
          ret = [_xoff, _yoff];
        } else {
          throw new Error(
            "Parameter xoff and yoff in origin() method must be all set when mode=-1"
          );
        }
        break;
      default:
        throw new Error(`Unknown origin mode ${String(_mode)}`);
    }
    return _fromorigin ? ret : [0 - ret[0], 0 - ret[1]];
  }
  /**
   * Set the glyph's bitmap (inverse of `draw()`).
   *
   * The bitmap's bottom-left corner is placed, relative to the glyph origin,
   * at: mode 0 → the font's `(fbbxoff, fbbyoff)`; mode 1 or 2 → the glyph's
   * current `(bbxoff, bbyoff)`; mode -1 → `(bb[2], bb[3])`. With `trim`
   * (default), empty rows and columns are removed on all four sides
   * (adjusting the offsets; a bitmap without ink gives an empty glyph). Any
   * non-`'0'` pixel is ink. `hexdata` rows are upper-case hex, bits
   * left-aligned. DWIDTH / SWIDTH are not changed.
   *
   * @param bitmap - `Bitmap` (or bindata array)
   * @param mode - Placement mode (0, 1, 2 or -1), default 0, or an options object `{mode, bb, trim}`
   * @param bb - `[w, h, xoff, yoff]`, required for mode -1
   * @param trim - Remove empty rows/columns, default `true`
   *
   * @returns The `Glyph` object itself
   *
   * @example
   * glyph.setbitmap(Bitmap.fromstring('.#.\n###\n.#.'), 1)
   */
  setbitmap(bitmap, mode, bb, trim) {
    let _mode;
    let _bb;
    let _trim;
    if (mode !== null && typeof mode === "object") {
      _mode = mode.mode ?? 0;
      _bb = mode.bb ?? null;
      _trim = mode.trim ?? true;
    } else {
      _mode = mode ?? 0;
      _bb = bb ?? null;
      _trim = trim ?? true;
    }
    const bindata = Array.isArray(bitmap) ? [...bitmap] : bitmap.bindata;
    let xoff, yoff;
    switch (_mode) {
      case 0: {
        const fh = this.font.headers;
        xoff = fh.fbbxoff ?? 0;
        yoff = fh.fbbyoff ?? 0;
        break;
      }
      case 1:
      case 2:
        xoff = this.meta.bbxoff || 0;
        yoff = this.meta.bbyoff || 0;
        break;
      case -1:
        if (_bb === null) {
          throw new Error(
            "Parameter bb in setbitmap() method must be set when mode=-1"
          );
        }
        xoff = _bb[2];
        yoff = _bb[3];
        break;
      default:
        throw new Error(`Unknown setbitmap mode ${String(_mode)}`);
    }
    let rows = bindata.map((row) => row.replace(/[^0]/g, "1"));
    const h = rows.length;
    let w = h > 0 ? rows[0].length : 0;
    if (rows.some((r) => r.length !== w)) {
      throw new Error("Bitmap rows have different lengths");
    }
    if (_trim) {
      const ink = [];
      rows.forEach((r, i) => {
        if (r.includes("1")) {
          ink.push(i);
        }
      });
      if (ink.length === 0) {
        rows = [];
        w = 0;
        xoff = 0;
        yoff = 0;
      } else {
        const top = ink[0];
        const bottom = ink[ink.length - 1];
        const kept = rows.slice(top, bottom + 1);
        let left = Infinity;
        let right = -Infinity;
        for (const r of kept) {
          if (r.includes("1")) {
            left = Math.min(left, r.indexOf("1"));
            right = Math.max(right, r.lastIndexOf("1") + 1);
          }
        }
        rows = kept.map((r) => r.slice(left, right));
        xoff += left;
        yoff += h - 1 - bottom;
        w = right - left;
      }
    }
    const ndigits = Math.ceil(w / 8) * 2;
    this.meta.bbw = w;
    this.meta.bbh = rows.length;
    this.meta.bbxoff = xoff;
    this.meta.bbyoff = yoff;
    this.meta.hexdata = w > 0 ? rows.map((r) => bin2hex(r, ndigits)) : [];
    this.__sync();
    return this;
  }
  /**
   * Set any of the 17 meta keys, e.g. `glyph.setmeta({ dwx0: 8, glyphname: 'A' })`.
   * Changing the codepoint of an attached glyph moves it in the font
   * (overwriting a glyph already at the destination); codepoint `-1` moves it
   * to `font.unencoded`.
   *
   * @param obj - Keys and values to set
   *
   * @returns The `Glyph` object itself
   *
   * @throws Error on an unknown key
   */
  setmeta(obj) {
    for (const k of Object.keys(obj)) {
      if (!META_TITLES.includes(k)) {
        throw new Error(`Unknown glyph meta key "${k}"`);
      }
    }
    for (const [k, v] of Object.entries(obj)) {
      ;
      this.meta[k] = k === "hexdata" && Array.isArray(v) ? [...v] : v;
    }
    this.__sync();
    return this;
  }
  /**
   * Move the glyph's bitmap relative to the origin: `bbxoff += dx`,
   * `bbyoff += dy` (y up).
   *
   * @param dx - Pixels to the right
   * @param dy - Pixels up
   *
   * @returns The `Glyph` object itself
   */
  shift(dx = 0, dy = 0) {
    this.meta.bbxoff = (this.meta.bbxoff || 0) + dx;
    this.meta.bbyoff = (this.meta.bbyoff || 0) + dy;
    this.__sync();
    return this;
  }
  /**
   * Draw the glyph (`draw(mode)`), pass the bitmap to `fn` and set the result
   * (or the bitmap itself if `fn` returns nothing, i.e. mutated it in place)
   * back with `setbitmap(..., mode)`.
   *
   * @param fn - Bitmap transformation, e.g. `(b) => b.bold()`
   * @param mode - Draw / placement mode, default 0
   *
   * @returns The `Glyph` object itself
   *
   * @example
   * font.glyph('A')?.transform((b) => b.italic())
   */
  transform(fn, mode = 0) {
    const bm = this.draw(mode);
    const res = fn(bm);
    return this.setbitmap(
      res !== null && typeof res === "object" && Array.isArray(res.bindata) ? res : bm,
      mode
    );
  }
  /**
   * Get a deep copy of the glyph (same font, detached).
   *
   * @returns New `Glyph` object
   */
  clone() {
    const meta = { ...this.meta };
    if (Array.isArray(meta.hexdata)) {
      meta.hexdata = [...meta.hexdata];
    }
    return newGlyph(meta, this.font);
  }
  /**
   * Change the bitmap of the glyph (keeping its offsets, no trimming).
   *
   * @deprecated Use {@link Glyph.setbitmap} (`setbitmap(bitmap, 1, null, false)`).
   *
   * @param bitmap - Bitmap object to change to
   *
   * @returns The `Glyph` object itself
   */
  changebitmap(bitmap) {
    return this.setbitmap(bitmap, 1, null, false);
  }
};
var newGlyph = (meta, font) => new Glyph(meta, font);

// fontpixel-recovery-baseline-20261004T1837/fontpixel-rs-phase6-handoff/local-work/phase6-performance/reference/bdfparser-js/src/charsets/sbcs.ts
var SBCS_TABLES = {
  ascii: {
    d: "A#je!jf"
  },
  latin_1: {
    d: "A#ne"
  },
  iso8859_2: {
    d: "A#kfmI9I5NpZpSharFCrQDMhKsXtADsVlK9M5RoboUha2YhgdqSDMhK2G1dDiPpFCkAjbnKjFjdkKkFkekZkekZCkAEjGInHCnYnTCoChMpHpMpHCoKoFnMnHCiChdlMjFhfiMiHjAibjAibCiCEjGIlJClalVCmEhMnJnOnJCmM3M"
  },
  iso8859_3: {
    d: "A#kfoM7EhjJC!AoAnZCoQicjfhMoN!AscsVnOnJ#CnAmbCnSicjfhMnP!ArerX#B!AEkMDkB#H!AE#CkYkTCkKkF#CpAfnZ#C!AEiODiD#H!AE#CiaiVCiMiH#CnCf3Y"
  },
  iso8859_4: {
    d: "A#kfmIjIhcrDoIhGpHCrQkbhAkIrRtAsbClK9M4HqFnKhG4WhgdqSkbhAkIhZjIjFkVjd#EmQiDkFkekZkWkRClYhTjKOhLmD#DpUpP#BoYEoViEhf#EkSiDiHjAibiYiTCjahTjKOhLkF#DnWnR#BmaE2c"
  },
  iso8859_5: {
    d: "A#kfh2C#Kh1dh2C#iAusOusJ#Kh7Jh7OC"
  },
  iso8859_6: {
    d: "A#kf!CI!Gi2Qi1d!Mi2c!CI!AE#Y!EM#R!M"
  },
  iso8859_7: {
    d: "A#kfv3QCv3LwgSGwgR#ChtChsd#B!Av2Qv2J#ChtC#BhsdhtC#BhsdhtChsdhtC#S!AE#hK!A"
  },
  iso8859_8: {
    d: "A#kf!AE#GiciX#NjcjX#C!fv1StkN#Z!BtiIC!A"
  },
  iso8859_9: {
    d: "A#mOkekZ#KlIicnd#PjAib#KjKiclf"
  },
  iso8859_10: {
    d: "A#kfmIchAQDcodpIiVlAMhOsfrahfpTlKchAQDcnfoKiVlAMhOvpOvqThfkVjd#EmQiDkFkekZkWkR#CnKOnR#CpEofpUpP#EiEhf#EkSiDiHjAibiYiT#ClMOlT#CnGnBnWnR#DjU"
  },
  iso8859_11: {
    d: "A#kfm2C#hY!DK#b!D"
  },
  iso8859_13: {
    d: "A#kfv3av3V#Bv3Uv3PCjCidqaqV#ChQhL#Cv2Sv2N#BkCjdpcpX#CiQhciUibMkDClGLLkFrAmFYhIXhCiKhZEnDnSnN#BpWjBhShAobpeEpbiMiUibMiFCjILLiHpCmFYhIXhCiKhZElFlUlP#BnYjBhShAmdoAEvpW"
  },
  iso8859_14: {
    d: "A#kfu2ECu1fmOCuveu2Fu9Su9Nu9SnNuOvkJCsUuqMCuvdCuxeCu4Vu6AiWiTiYiFpGmdCiHu6B#OqKqF#Eu5Iu5D#EpSpN#PoMoH#Eu3Ku3F#EnUnP"
  },
  iso8859_15: {
    d: "A#lCwgSwgNrWrRrUrP#JsUsP#BsOsJ#BpOCiKrR#hf"
  },
  iso8859_16: {
    d: "A#kfmICjYv2WobvrbrRrUrP2e2ZscsXsaCsVClWjMjWvqAv2NCsOnBwY1bpOCiKIrX#BkAjbkEjf#IkCjGnB#BnYnToIhMpN#CjYwEzV#CiChdiGiB#IiEjGlD#BlalVmKhMnP#ChawExX"
  },
  koi8_r: {
    d: "A#jeyoCEUIIIIQQQQkIIIII#ChnFhoAh4NCichYCw8JxoCxnBEKkAylS#BwwBwwE#Nw1fw2C#JysFh6KhbChKhDCehBhEZ#GhAd#CZHhUBhHhCKHDGhXhbChKhDCehBhEZ#GhAd#CZHhUBhHhCKHDG"
  },
  koi8_u: {
    d: "A#jeyoCEUIIIIQQQQkIIIII#ChnFhoAh4NCichYCw8JxoCxnBEKkAylS#BwwBGwwAwvbCwwA#DwsTwsY#Dw1fGw1ew1ZCw1e#DwtTwtYysFh6KhbChKhDCehBhEZ#GhAd#CZHhUBhHhCKHDGhXhbChKhDCehBhEZ#GhAd#CZHhUBhHhCKHDG"
  },
  cp1250: {
    d: "A#jewia!ApD!AIQLC!AevsfvtSvtdUhSH!AvpeCGCKdC!Awcv8BvtSvtdUhSHtThiOhC5NpZmAlb#CrKrF#CsasVChiU5Rob#DkalUqHoE6A5djciPpFCkAjbnKjFjdkKkFkekZkekZCkAEjGInHCnYnTCoChMpHpMpHCoKoFnMnHCiChdlMjFhfiMiHjAibjAibCiCEjGIlJClalVCmEhMnJnOnJCmM3M"
  },
  cp1251: {
    d: "A#jeh4GCuhOt8Nt8WQLCoWnXuiNujAuidEBIkGt8MCGCKdC!AwcusRt+Ct9fEBIh7dh2clAlLh2Hh+Yh+TCh1Uh1Ph1Wh1R#Ch1Sh1NCh1KlAjWh9X#Bh5UusKusDh5Rh5alFlAEkN#he"
  },
  cp1252: {
    d: "A#jewia!ApDvoPvoYQLCu1Vu2UvsfvtSvuN!AiW!BvpWCGCKdCuzPvkMv8BvtSvuN!AiWLtP#ie"
  },
  cp1253: {
    d: "A#jewia!ApDvoPvoYQLC!Ae!AS!EiBCGCKdC!Awc!AuP!Dv5ThuKChuF#F!AE#Cv2Ov2J#ChtChsd#BhtC#BhsdhtChsdhtC#S!AE#hK!A"
  },
  cp1254: {
    d: "A#jewia!ApDvoPvoYQLCu1Vu2UvsfvtSvuN!DvsMCGCKdCuzPvkMv8BvtSvuN!BiKtP#hOkekZ#KlIicnd#PjAib#KjKiclf"
  },
  cp1255: {
    d: "A#jewia!ApDvoPvoYQLCu1Vu2U!AS!EiBCGCKdCuzPvkM!AuP!Dv5T#CwgOwgJ#DiciX#NjcjX#DivC#I!AE#Hia#D!GiH#Z!BtiIC!A"
  },
  cp1256: {
    d: "A#jewiatibs5YvoPvoYQLCu1Vu2Us7Ns8AvuNizIhEfiOs2SCGCKdCs2VtnStpBs6SvuNvrSCs1FjhTi2Yi2T#GjhKjhF#Ni2Ei1f#Ci2CqEpf#Ui1di2A#CM#Ci2Fi2Ii2Di2G#Ci2B#Di1cCi1XCi1Y#Ci1Ti1WCi1Ri1Ui1Pi1Si1NCvxECszZ"
  },
  cp1257: {
    d: "A#jewia!ApD!AIQLC!Ae!AS!Av5Bhhehgd!Av2ACGCKdC!Awc!AuP!Av4VhiY!AhjV!AE#B!AECjCidqaqV#ChQhL#GkCjdpcpX#CiQhciUibMkDClGLLkFrAmFYhIXhCiKhZEnDnSnN#BpWjBhShAobpeEpbiMiUibMiFCjILLiHpCmFYhIXhCiKhZElFlUlP#BnYjBhShAmdoAE1W"
  },
  cp1258: {
    d: "A#jewia!ApDvoPvoYQLCu1Vu2U!ASvuN!DvsMCGCKdCuzPvkM!AuPvuN!BiKtP#hBkAjb#GhjKhjF#BkCjdhjQhjLCsYsT#FtG1IhiH#CiChd#GhhMhhH#BiEhfhjEhifCqaqV#FrIvvWv6X"
  },
  cp437: {
    d: "A#jekQjKhFNEHKEGCFOBDiPCIhahficEHSDMiRMjTCEwgEvxJrBYMORhfiNhAKxlCxmHhCBhVUhAytM#BpBiEjaCXBchDMMBBkVIiAPfhXjYiECJLhKFLfhYJCHCXBLChQBlDXnYHQIfw8dhtDhrIiahZiAhwbhwehbbhCWvmUvlPhBvnIjQw6fw7IBrYCxiTw1Cw5Pw2Sw2Dw2G5Vv8Zyucyvf"
  },
  cp850: {
    d: "A#jekQjKhFNEHKEGCFOBDiPCIhahficEHSDMiRMhYlJjKBrWrBYMORhfiNhAKhBDhCBhVUhAytM#BpBiEymFCDhNyrUhDMMyrVGymWIiAPfhXjYylRhfypOLhKFLfhYysPkYhfLCFmSmH#BykSXnYHytbiMyrIyqZYVDiGhfhfkShfHCDiIhfibKNIv2Mv1RPdlAjdPPeELByucyvf"
  },
  cp852: {
    d: "A#jekQjKhFNEoWmPhflWlNmKCmFoWrJkEjZnACkLEkOChYCoJMoQCiHmTjMiXYMOUCnQCmLCmZscmblGrHhAytM#BpBiEymFClQkIygKhDMMx+DCx5IIiAPfhXjYyjTCylOLhKFLfhYysPmaBDkFkIjQnTCkax/aXnYHyiDYyhEyqZYVmeCIhQCZnTnWhWnFhfoMqdNhjADhHhChjBlAjdPPhjC2PhRCykOyvf"
  },
  cp866: {
    d: "A#jeh5C#hOw1E#BpBiEjaCXBchDMMBBkVIiAPfhXjYiECJLhKFLfhYJCHCXBLChQBlDXnYHQIfwzf#OkblAkZlAkZlAkRlAh6bw2Sw2Dw2GwHwnDyvYyvf"
  },
  cp874: {
    d: "A#jewia!DoL!KbCGCKdC!Hv3Hm2C#hY!DK#b!D"
  },
  tis_620: {
    d: "A#ke!Am2E#hY!DK#b!D"
  },
  mac_roman: {
    d: "A#jekKCEEQKMKBEEBEEEBECEBECEEBEEBKBECvyIv2fbCIv3Wv2XiSjBJwnSwmbXw7Qw5ThEw0Mw2Zw7GCw7fhAw0aeDvkdvmWw4BhAhuehsFhEjRhbWw2cwoPwrMkDw1VhAv2Wv4LiAGhEnaCvsACQCJCvyDytGysVnSvsYmQnFCjtsOCjtuBv2Tv2GIhEv2bQRUFK#BFOCj8iWj8iZQCDlQ5KhMhiZhiS#BhiDhiKDhH"
  }
};

// fontpixel-recovery-baseline-20261004T1837/fontpixel-rs-phase6-handoff/local-work/phase6-performance/reference/bdfparser-js/src/charsets/registry.ts
var FINAL = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdef";
var CONT = "ghijklmnopqrstuvwxyz0123456789+/";
var DIGITS = /* @__PURE__ */ (() => {
  const d = new Int8Array(128).fill(-1);
  for (let i = 0; i < 32; i++) {
    d[FINAL.charCodeAt(i)] = i;
    d[CONT.charCodeAt(i)] = 32 + i;
  }
  return d;
})();
var NumReader = class {
  constructor(s) {
    this.s = s;
  }
  s;
  i = 0;
  get done() {
    return this.i >= this.s.length;
  }
  num() {
    let v = 0;
    for (; ; ) {
      const c = this.s.charCodeAt(this.i++);
      const d = c < 128 ? DIGITS[c] : -1;
      if (d < 0) {
        throw new Error(`Corrupt charset table data at ${this.i - 1}`);
      }
      if (d < 32) {
        return v * 32 + d;
      }
      v = v * 32 + d - 32;
    }
  }
};
var unzigzag = (z) => z % 2 === 0 ? z / 2 : -(z + 1) / 2;
var sjis2euc = (code) => {
  if (code < 256) {
    return code >= 161 && code <= 223 ? 36352 | code : code;
  }
  const s1 = code >> 8;
  const s2 = code & 255;
  let j1 = (s1 - (s1 <= 159 ? 112 : 176)) * 2;
  let j2;
  if (s2 < 159) {
    j1 -= 1;
    j2 = s2 - 31 - (s2 >= 127 ? 1 : 0);
  } else {
    j2 = s2 - 126;
  }
  return ((j1 | 128) & 255) << 8 | (j2 | 128) & 255;
};
var registered = /* @__PURE__ */ new Map();
var forwardCache = /* @__PURE__ */ new Map();
var reverseCache = /* @__PURE__ */ new Map();
var gb18030Source = null;
var gb18030Runs = null;
var registerCharsetTables = (tables) => {
  if (typeof tables !== "object" || tables === null || typeof tables.tables !== "object") {
    throw new TypeError("registerCharsetTables(): expected charset tables");
  }
  for (const codec of Object.keys(tables.tables)) {
    registered.set(codec, tables.tables[codec]);
    forwardCache.delete(codec);
    reverseCache.delete(codec);
  }
  if (typeof tables.gb18030 === "string") {
    gb18030Source = tables.gb18030;
    gb18030Runs = null;
  }
};
var specOf = (codec) => registered.get(codec) ?? (Object.prototype.hasOwnProperty.call(SBCS_TABLES, codec) ? SBCS_TABLES[codec] : void 0);
var forwardTable = (codec) => {
  let fwd = forwardCache.get(codec);
  if (fwd !== void 0) {
    return fwd;
  }
  const spec = specOf(codec);
  if (spec === void 0) {
    return null;
  }
  const mbcs = spec.l !== void 0 && spec.t !== void 0;
  fwd = new Int32Array(mbcs ? 65536 : 256).fill(-1);
  const [l0, l1] = mbcs ? spec.l : [0, -1];
  const [t0, t1] = mbcs ? spec.t : [0, -1];
  const tw = t1 - t0 + 1;
  const npos = 256 + (l1 - l0 + 1) * Math.max(tw, 0);
  const codeAt = (p2) => p2 < 256 ? p2 : l0 + Math.floor((p2 - 256) / tw) << 8 | t0 + (p2 - 256) % tw;
  let base = null;
  if (spec.b !== void 0) {
    base = forwardTable(spec.b);
    if (base === null) {
      throw new Error(
        `Charset table '${codec}' needs the table '${spec.b}', which is not registered`
      );
    }
  }
  const xf = spec.x === "sjis" ? sjis2euc : (c) => c;
  const r = new NumReader(spec.d);
  let p = 0;
  let prev = 0;
  while (!r.done) {
    const c = spec.d[r.i];
    if (c === "!" || c === "#" || c === "$") {
      r.i++;
      const n = r.num() + 1;
      for (let k = 0; k < n; k++, p++) {
        if (c === "#") {
          fwd[codeAt(p)] = ++prev;
        } else if (c === "$") {
          const v = base[xf(codeAt(p))] ?? -1;
          fwd[codeAt(p)] = v;
          if (v >= 0) {
            prev = v;
          }
        }
      }
    } else {
      prev += unzigzag(r.num());
      fwd[codeAt(p++)] = prev;
    }
  }
  if (p !== npos) {
    throw new Error(`Corrupt charset table '${codec}'`);
  }
  forwardCache.set(codec, fwd);
  return fwd;
};
var reverseTable = (codec) => {
  let rev = reverseCache.get(codec);
  if (rev !== void 0) {
    return rev;
  }
  const fwd = forwardTable(codec);
  if (fwd === null) {
    return null;
  }
  rev = /* @__PURE__ */ new Map();
  for (let code = 0; code < fwd.length; code++) {
    const u = fwd[code];
    if (u >= 0 && !rev.has(u)) {
      rev.set(u, code);
    }
  }
  const e = specOf(codec).e;
  if (e !== void 0) {
    const r = new NumReader(e);
    while (!r.done) {
      const u = r.num();
      rev.set(u, r.num() - 1);
    }
  }
  reverseCache.set(codec, rev);
  return rev;
};
var gbRuns = () => {
  if (gb18030Runs === null && gb18030Source !== null) {
    const r = new NumReader(gb18030Source);
    const idx = [];
    const cps = [];
    const lens = [];
    let endIdx = 0;
    let endCp = 0;
    while (!r.done) {
      const i = endIdx + r.num();
      const c = endCp + unzigzag(r.num());
      const n = r.num() + 1;
      idx.push(i);
      cps.push(c);
      lens.push(n);
      endIdx = i + n;
      endCp = c + n;
    }
    gb18030Runs = [
      Int32Array.from(idx),
      Int32Array.from(cps),
      Int32Array.from(lens)
    ];
  }
  return gb18030Runs;
};
var findRun = (starts, v) => {
  let lo = 0;
  let hi = starts.length - 1;
  let found = -1;
  while (lo <= hi) {
    const mid = lo + hi >> 1;
    if (starts[mid] <= v) {
      found = mid;
      lo = mid + 1;
    } else {
      hi = mid - 1;
    }
  }
  return found;
};
var gb18030Decode4 = (code) => {
  const runs = gbRuns();
  if (runs === null) {
    return null;
  }
  const b0 = Math.floor(code / 16777216) & 255;
  const b1 = code >> 16 & 255;
  const b2 = code >> 8 & 255;
  const b3 = code & 255;
  if (b0 < 129 || b0 > 254 || b1 < 48 || b1 > 57 || b2 < 129 || b2 > 254 || b3 < 48 || b3 > 57) {
    return -1;
  }
  const index = (((b0 - 129) * 10 + (b1 - 48)) * 126 + (b2 - 129)) * 10 + (b3 - 48);
  const k = findRun(runs[0], index);
  if (k < 0 || index >= runs[0][k] + runs[2][k]) {
    return -1;
  }
  return runs[1][k] + index - runs[0][k];
};
var gb18030Encode4 = (u) => {
  const runs = gbRuns();
  if (runs === null) {
    return null;
  }
  const k = findRun(runs[1], u);
  if (k < 0 || u >= runs[1][k] + runs[2][k]) {
    return -1;
  }
  let index = runs[0][k] + u - runs[1][k];
  const b3 = index % 10;
  index = Math.floor(index / 10);
  const b2 = index % 126;
  index = Math.floor(index / 126);
  const b1 = index % 10;
  const b0 = Math.floor(index / 10);
  return (129 + b0) * 16777216 + (48 + b1 << 16) + (129 + b2 << 8) + 48 + b3;
};

// fontpixel-recovery-baseline-20261004T1837/fontpixel-rs-phase6-handoff/local-work/phase6-performance/reference/bdfparser-js/src/charsets/table.ts
var UNICODE_KEYS = ["iso10646", "unicode", "utf8", "utf7", "ucs2", "ucs4", "ucs", "utf16", "utf32"];
var UNICODE_PREFIXES = ["utf16", "utf32", "ucs2", "ucs4"];
var CHARSETS = {
  ascii: ["ascii", "sbcs", 0, "ISO646.1991", "IRV"],
  iso646: ["ascii", "sbcs", 0, "ISO646.1991", "IRV"],
  iso88591: ["latin_1", "sbcs", 0, "ISO8859", "1"],
  iso88592: ["iso8859_2", "sbcs", 0, "ISO8859", "2"],
  iso88593: ["iso8859_3", "sbcs", 0, "ISO8859", "3"],
  iso88594: ["iso8859_4", "sbcs", 0, "ISO8859", "4"],
  iso88595: ["iso8859_5", "sbcs", 0, "ISO8859", "5"],
  iso88596: ["iso8859_6", "sbcs", 0, "ISO8859", "6"],
  iso88597: ["iso8859_7", "sbcs", 0, "ISO8859", "7"],
  iso88598: ["iso8859_8", "sbcs", 0, "ISO8859", "8"],
  iso88599: ["iso8859_9", "sbcs", 0, "ISO8859", "9"],
  iso885910: ["iso8859_10", "sbcs", 0, "ISO8859", "10"],
  iso885911: ["iso8859_11", "sbcs", 0, "ISO8859", "11"],
  iso885913: ["iso8859_13", "sbcs", 0, "ISO8859", "13"],
  iso885914: ["iso8859_14", "sbcs", 0, "ISO8859", "14"],
  iso885915: ["iso8859_15", "sbcs", 0, "ISO8859", "15"],
  iso885916: ["iso8859_16", "sbcs", 0, "ISO8859", "16"],
  koi8r: ["koi8_r", "sbcs", 0, "KOI8", "R"],
  koi8u: ["koi8_u", "sbcs", 0, "KOI8", "U"],
  cp1250: ["cp1250", "sbcs", 0, "MICROSOFT", "CP1250"],
  cp1251: ["cp1251", "sbcs", 0, "MICROSOFT", "CP1251"],
  cp1252: ["cp1252", "sbcs", 0, "MICROSOFT", "CP1252"],
  cp1253: ["cp1253", "sbcs", 0, "MICROSOFT", "CP1253"],
  cp1254: ["cp1254", "sbcs", 0, "MICROSOFT", "CP1254"],
  cp1255: ["cp1255", "sbcs", 0, "MICROSOFT", "CP1255"],
  cp1256: ["cp1256", "sbcs", 0, "MICROSOFT", "CP1256"],
  cp1257: ["cp1257", "sbcs", 0, "MICROSOFT", "CP1257"],
  cp1258: ["cp1258", "sbcs", 0, "MICROSOFT", "CP1258"],
  cp437: ["cp437", "sbcs", 0, "IBM", "CP437"],
  cp850: ["cp850", "sbcs", 0, "IBM", "CP850"],
  cp852: ["cp852", "sbcs", 0, "IBM", "CP852"],
  cp866: ["cp866", "sbcs", 0, "IBM", "CP866"],
  cp874: ["cp874", "sbcs", 0, "MICROSOFT", "CP874"],
  tis620: ["tis_620", "sbcs", 0, "TIS620", "0"],
  macroman: ["mac_roman", "sbcs", 0, "MACROMAN", "0"],
  jisx0201: ["shift_jis", "sbcs", 0, "JISX0201.1976", "0"],
  gb2312: ["gb2312", "dbcs", 1, "GB2312.1980", "0"],
  euccn: ["gb2312", "dbcs", 0, "EUCCN", "0"],
  iso2022cn: ["gb2312", "dbcs", 2, "GB2312.1980", "0"],
  gbk: ["gbk", "dbcs", 0, "GBK", "0"],
  cp936: ["cp936", "dbcs", 0, "MICROSOFT", "CP936"],
  gb18030: ["gb18030", "gb18030", 0, "GB18030", "0"],
  jisx0208: ["euc_jp", "dbcs", 1, "JISX0208.1983", "0"],
  eucjp: ["euc_jp", "dbcs", 0, "EUCJP", "0"],
  shiftjis: ["shift_jis", "dbcs", 0, "SHIFTJIS", "0"],
  cp932: ["cp932", "dbcs", 0, "MICROSOFT", "CP932"],
  ksc5601: ["euc_kr", "dbcs", 1, "KSC5601.1987", "0"],
  euckr: ["euc_kr", "dbcs", 0, "EUCKR", "0"],
  cp949: ["cp949", "dbcs", 0, "MICROSOFT", "CP949"],
  johab: ["johab", "dbcs", 0, "JOHAB", "0"],
  big5: ["big5", "dbcs", 0, "BIG5", "0"],
  big5hkscs: ["big5hkscs", "dbcs", 0, "BIG5HKSCS", "0"],
  cp950: ["cp950", "dbcs", 0, "MICROSOFT", "CP950"]
};
var ALIASES = { "sjis": "shiftjis", "ksx1001": "ksc5601" };
var MBCS_RANGES = {
  gb2312: ["gbk", [0, 127], [161, 169, 176, 247], [161, 254]],
  gbk: ["gbk", [0, 127], [129, 254], [64, 126, 128, 254]],
  cp936: ["gbk", [0, 127], [129, 254], [64, 126, 128, 254]],
  gb18030: ["gb18030", [0, 127], [129, 254], [64, 126, 128, 254]],
  euc_jp: ["euc-jp", [0, 127], [142, 142, 161, 168, 176, 244], [161, 254]],
  shift_jis: ["shift_jis", [0, 127, 161, 223], [129, 132, 136, 159, 224, 234], [64, 126, 128, 252]],
  cp932: ["shift_jis", [0, 128, 160, 223, 253, 255], [129, 132, 135, 159, 224, 234, 237, 238, 240, 252], [64, 126, 128, 252]],
  euc_kr: ["euc-kr", [0, 127], [161, 172, 176, 200, 202, 253], [161, 254]],
  cp949: ["euc-kr", [0, 127], [129, 200, 202, 253], [65, 90, 97, 122, 129, 254]],
  johab: ["", [0, 127], [132, 211, 217, 222, 224, 249], [49, 126, 129, 254]],
  big5: ["big5", [0, 127], [161, 199, 201, 249], [64, 126, 161, 254]],
  big5hkscs: ["big5", [0, 127], [135, 254], [64, 126, 161, 254]],
  cp950: ["big5", [0, 127], [161, 199, 201, 249], [64, 126, 161, 254]]
};

// fontpixel-recovery-baseline-20261004T1837/fontpixel-rs-phase6-handoff/local-work/phase6-performance/reference/bdfparser-js/src/encoding.ts
var RE_TRIM_WS = /^[ \t\n\v\f\r]+|[ \t\n\v\f\r]+$/g;
var RE_STRIP = /[-_ \t\n\v\f\r]/g;
var RE_ISO8859 = /^iso8859([0-9]+)$/;
var RE_CP = /^(?:cp|windows|win|ms|ibm)?([0-9]+)$/;
var RE_CPKEY = /^cp[0-9]+$/;
var RE_DIGITS = /^[0-9]+$/;
var CP_REGISTRIES = ["microsoft", "windows", "ms", "ibm"];
var hasOwn = (o, k) => Object.prototype.hasOwnProperty.call(o, k);
var stripWs = (s) => s.replace(RE_TRIM_WS, "");
var intStr = (digits) => BigInt(digits).toString();
var cleanName = (name) => {
  let s = stripWs(String(name));
  if (s.startsWith("-")) {
    s = s.slice(1);
  }
  const dot = s.indexOf(".");
  if (dot !== -1) {
    s = s.slice(0, dot);
  }
  return s.replace(RE_STRIP, "").toLowerCase();
};
var cpKey = (s) => {
  const m = RE_CP.exec(s);
  if (m === null) {
    return null;
  }
  const key = "cp" + intStr(m[1]);
  return hasOwn(CHARSETS, key) ? key : null;
};
var resolveAlias = (key) => hasOwn(ALIASES, key) ? ALIASES[key] : key;
var sanitizeCharsetName = (charset) => {
  charset = charset.trim();
  if (charset.startsWith("-")) {
    charset = charset.slice(1);
  }
  const dotIndex = charset.indexOf(".");
  if (dotIndex !== -1) {
    charset = charset.slice(0, dotIndex);
  }
  return charset.replace(/-|\s|(?<!^)_/g, "").toLowerCase();
};
var sanitizeCharset = (registry, encoding) => {
  const reg = registry === null || registry === void 0 ? "" : cleanName(registry);
  const enc = encoding === null || encoding === void 0 ? "" : String(encoding).replace(RE_STRIP, "").toLowerCase();
  if (reg === "") {
    return "iso10646";
  }
  if (reg === "iso8859") {
    const n = RE_DIGITS.test(enc) ? intStr(enc) : "0";
    return "iso8859" + (n !== "0" ? n : "1");
  }
  if (reg === "koi8") {
    if (enc === "" || enc === "r") {
      return "koi8r";
    }
    return enc === "u" ? "koi8u" : "koi8" + enc;
  }
  if (CP_REGISTRIES.includes(reg)) {
    return cpKey(enc) ?? reg;
  }
  if (!RE_DIGITS.test(reg)) {
    const key = cpKey(reg);
    if (key !== null) {
      return key;
    }
  }
  return resolveAlias(reg);
};
var isUnicodeKey = (key) => key === "" || UNICODE_KEYS.includes(key) || UNICODE_PREFIXES.some((p) => key.startsWith(p));
var isKnownKey = (key) => isUnicodeKey(key) || hasOwn(CHARSETS, key);
var isUnicodeCharset = (key) => isUnicodeKey(key);
var canonicalCharset = (name) => {
  const key = sanitizeCharset(name);
  if (isKnownKey(key)) {
    return key;
  }
  const s = stripWs(String(name));
  if (s.slice(1).includes("-")) {
    const dash = s.lastIndexOf("-");
    const key2 = sanitizeCharset(s.slice(0, dash), s.slice(dash + 1));
    if (isKnownKey(key2)) {
      return key2;
    }
  }
  return key;
};
var charsetProps = (key) => {
  key = resolveAlias(key);
  if (isUnicodeKey(key)) {
    return ["ISO10646", "1"];
  }
  const iso = RE_ISO8859.exec(key);
  if (iso) {
    return ["ISO8859", intStr(iso[1])];
  }
  if (hasOwn(CHARSETS, key)) {
    return [CHARSETS[key][3], CHARSETS[key][4]];
  }
  if (RE_CPKEY.test(key)) {
    return ["MICROSOFT", key.toUpperCase()];
  }
  return [key.toUpperCase(), "0"];
};
var charsetKeys = () => [
  ...UNICODE_KEYS,
  ...Object.keys(CHARSETS)
];
var isOneChar = (s) => {
  if (typeof s !== "string") {
    return false;
  }
  if (s.length === 1) {
    return true;
  }
  if (s.length === 2) {
    const c = s.charCodeAt(0);
    const d = s.charCodeAt(1);
    return c >= 55296 && c <= 56319 && d >= 56320 && d <= 57343;
  }
  return false;
};
var assertOneChar = (char) => {
  if (!isOneChar(char)) {
    throw new TypeError(
      `char2cp() expected a single character, got ${JSON.stringify(char)}`
    );
  }
};
var isValidCp = (cp) => typeof cp === "number" && Number.isInteger(cp) && cp >= 0;
var cpToBytes = (cp) => cp < 256 ? Uint8Array.of(cp) : cp < 65536 ? Uint8Array.of(cp >> 8, cp & 255) : Uint8Array.of(
  Math.floor(cp / 16777216) & 255,
  cp >> 16 & 255,
  cp >> 8 & 255,
  cp & 255
);
var bytesToCp = (bytes) => {
  let r = 0;
  for (let i = 0; i < bytes.length; i++) {
    r = r * 256 + bytes[i];
  }
  return r;
};
var inRanges = (v, ranges) => {
  for (let i = 0; i < ranges.length; i += 2) {
    if (v >= ranges[i] && v <= ranges[i + 1]) {
      return true;
    }
  }
  return false;
};
var decoderCache = /* @__PURE__ */ new Map();
var getDecoder = (label) => {
  let d = decoderCache.get(label);
  if (d === void 0) {
    try {
      d = label === "" ? null : new TextDecoder(label, { fatal: true });
    } catch {
      d = null;
    }
    decoderCache.set(label, d);
  }
  return d;
};
var tableCodec = (codec, kind) => {
  const fwd = forwardTable(codec);
  if (fwd === null || kind === "gb18030" && gb18030Decode4(0) === null) {
    return null;
  }
  return {
    exact: true,
    decode: (code) => code < fwd.length ? fwd[code] : kind === "gb18030" && code >= 16777216 && code <= 4294967295 ? gb18030Decode4(code) : -1,
    encode: (u) => {
      const code = reverseTable(codec).get(u);
      if (code !== void 0) {
        return code;
      }
      return kind === "gb18030" ? gb18030Encode4(u) : -1;
    }
  };
};
var fallbackWarned = /* @__PURE__ */ new Set();
var fallbackCodec = (key, codec, kind, iconv) => {
  const [label, single, leads, trails] = MBCS_RANGES[codec];
  let decodeBytes2;
  const useIconv = iconv !== void 0 && iconvKnows(iconv, codec);
  if (useIconv) {
    decodeBytes2 = (b) => {
      try {
        const s = iconv.decode(b, codec);
        return s.includes("\uFFFD") ? null : s;
      } catch {
        return null;
      }
    };
  } else {
    if (!fallbackWarned.has(key)) {
      fallbackWarned.add(key);
      warn(
        `The exact tables of the charset '${key}' are not loaded: using the runtime's TextDecoder, results may differ from the Python bdfparser and between runtimes (import 'bdfparser/cjk' or load bdfparser-cjk.global.js for exact conversions)`
      );
    }
    const decoder = getDecoder(label);
    decodeBytes2 = (b) => {
      if (decoder === null) {
        return null;
      }
      try {
        return decoder.decode(b);
      } catch {
        return null;
      }
    };
  }
  const decode = (code) => {
    let ok;
    if (code < 256) {
      if (code < 128) {
        return inRanges(code, single) ? code : -1;
      }
      ok = inRanges(code, single);
    } else if (code < 65536) {
      ok = inRanges(code >> 8, leads) && inRanges(code & 255, trails);
    } else {
      ok = kind === "gb18030" && code <= 4294967295 && /^[\x81-\xfe][0-9][\x81-\xfe][0-9]$/.test(
        String.fromCharCode(...cpToBytes(code))
      );
    }
    if (!ok) {
      return -1;
    }
    const s = decodeBytes2(cpToBytes(code));
    return s !== null && isOneChar(s) ? s.codePointAt(0) : -1;
  };
  let rev = null;
  const encode = (u) => {
    if (u < 128) {
      return inRanges(u, single) ? u : -1;
    }
    if (useIconv) {
      try {
        const b = iconv.encode(String.fromCodePoint(u), codec);
        const n = bytesToCp(b);
        return (b.length === 1 || b.length === 2 || b.length === 4) && n !== 63 ? n : -1;
      } catch {
        return -1;
      }
    }
    if (rev === null) {
      rev = /* @__PURE__ */ new Map();
      for (let code = 0; code < 65536; code++) {
        const v = decode(code);
        if (v >= 0 && !rev.has(v)) {
          rev.set(v, code);
        }
      }
    }
    return rev.get(u) ?? -1;
  };
  return { exact: false, decode, encode };
};
var iconvKnows = (iconv, name) => {
  if (iconv.encodingExists === void 0) {
    return true;
  }
  try {
    return iconv.encodingExists(name);
  } catch {
    return false;
  }
};
var JISX0201 = {
  exact: true,
  decode: (code) => code < 128 ? code : code >= 161 && code <= 223 ? 65377 + code - 161 : -1,
  encode: (u) => u < 128 ? u : u >= 65377 && u <= 65439 ? u - 65377 + 161 : -1
};
var getCodec = (charset, options = {}) => {
  const key = resolveAlias(canonicalCharset(charset));
  const entry = hasOwn(CHARSETS, key) ? CHARSETS[key] : void 0;
  if (isUnicodeKey(key) || entry === void 0) {
    const known = isUnicodeKey(key);
    return {
      charset: key,
      unicode: true,
      gl94: false,
      gl: false,
      known,
      kind: "unicode",
      exact: true,
      cp2char: (cp) => isValidCp(cp) && cp <= 1114111 ? String.fromCodePoint(cp) : null,
      char2cp: (char) => {
        assertOneChar(char);
        return char.codePointAt(0);
      }
    };
  }
  const [codec, kind, glType] = entry;
  const gl = (options.gl === null || options.gl === void 0 ? glType === 2 : options.gl) && glType !== 0;
  const raw = key === "jisx0201" ? JISX0201 : tableCodec(codec, kind) ?? fallbackCodec(key, codec, kind, options.iconv);
  const cp2char2 = (cp) => {
    if (!isValidCp(cp)) {
      return null;
    }
    if (cp >= 256) {
      if (cp < 65536) {
        if (kind === "sbcs") {
          return null;
        }
        if (gl) {
          const hi = cp >> 8;
          const lo = cp & 255;
          if (hi < 33 || hi > 126 || lo < 33 || lo > 126) {
            return null;
          }
          cp += 32896;
        }
      } else if (kind !== "gb18030" || cp > 4294967295) {
        return null;
      }
    }
    const u = raw.decode(cp);
    return u < 0 ? null : String.fromCodePoint(u);
  };
  return {
    charset: key,
    unicode: false,
    gl94: glType !== 0,
    gl,
    known: true,
    kind,
    exact: raw.exact,
    cp2char: cp2char2,
    char2cp(char) {
      assertOneChar(char);
      let code = raw.encode(char.codePointAt(0));
      if (code < 0) {
        return null;
      }
      if (gl && code >= 256 && code < 65536) {
        code -= 32896;
      }
      return cp2char2(code) === char ? code : null;
    }
  };
};
var detectGL = (charsetEncoding, cps) => {
  if (charsetEncoding !== null && charsetEncoding !== void 0 && stripWs(String(charsetEncoding)) === "0") {
    return true;
  }
  let first = Infinity;
  for (const cp of cps) {
    if (cp >= 256 && cp <= 65535 && cp < first) {
      first = cp;
    }
  }
  if (first === Infinity) {
    return false;
  }
  const hi = first >> 8;
  const lo = first & 255;
  return hi >= 33 && hi <= 126 && lo >= 33 && lo <= 126;
};
var unknownWarned = /* @__PURE__ */ new Set();
var moduleCodec = (charset, iconv) => {
  const codec = getCodec(charset, { iconv });
  if (!codec.known && !unknownWarned.has(codec.charset)) {
    unknownWarned.add(codec.charset);
    warn(
      `Unknown charset '${codec.charset}', characters are mapped to codepoints as Unicode`
    );
  }
  return codec;
};
var char2cp = (char, charset = "iso10646", iconv) => moduleCodec(charset, iconv).char2cp(char);
var cp2char = (cp, charset = "iso10646", iconv) => moduleCodec(charset, iconv).cp2char(cp);
var _isOneChar = isOneChar;

// fontpixel-recovery-baseline-20261004T1837/fontpixel-rs-phase6-handoff/local-work/phase6-performance/reference/bdfparser-js/src/errors.ts
var BDFParseError = class extends Error {
  /** 1-based line number where the error was detected, or `null` */
  lineno;
  /** The message without the line number prefix */
  msg;
  /**
   * @param message - Error description (without line number)
   * @param lineno - 1-based line number, if known
   */
  constructor(message, lineno = null) {
    super(lineno === null ? message : `line ${lineno}: ${message}`);
    this.name = "BDFParseError";
    this.lineno = lineno;
    this.msg = message;
  }
};

// fontpixel-recovery-baseline-20261004T1837/fontpixel-rs-phase6-handoff/local-work/phase6-performance/reference/bdfparser-js/src/props.ts
var newProps = () => /* @__PURE__ */ Object.create(null);
var copyProps = (props) => {
  const out = newProps();
  for (const k of Object.keys(props)) {
    const v = props[k];
    out[k] = Array.isArray(v) ? [...v] : v;
  }
  return out;
};
var hasOwn2 = (o, k) => Object.prototype.hasOwnProperty.call(o, k);
var propKeys = (props, propnames) => {
  const keys = [];
  for (const k of propnames.keys()) {
    if (k !== "comment" && hasOwn2(props, k)) {
      keys.push(k);
    }
  }
  for (const k of Object.keys(props)) {
    if (k !== "comment" && !propnames.has(k)) {
      keys.push(k);
    }
  }
  return keys;
};
var propEntries = (props, propnames) => propKeys(props, propnames).map((k) => [
  k,
  props[k]
]);

// fontpixel-recovery-baseline-20261004T1837/fontpixel-rs-phase6-handoff/local-work/phase6-performance/reference/bdfparser-js/src/pcf.ts
var PCF_PROPERTIES = 1 << 0;
var PCF_ACCELERATORS = 1 << 1;
var PCF_METRICS = 1 << 2;
var PCF_BITMAPS = 1 << 3;
var PCF_INK_METRICS = 1 << 4;
var PCF_BDF_ENCODINGS = 1 << 5;
var PCF_SWIDTHS = 1 << 6;
var PCF_GLYPH_NAMES = 1 << 7;
var PCF_BDF_ACCELERATORS = 1 << 8;
var PCF_FORMAT_MASK = 4294967040;
var PCF_DEFAULT_FORMAT = 0;
var PCF_ACCEL_W_INKBOUNDS = 256;
var PCF_COMPRESSED_METRICS = 256;
var PCF_MAGIC = [1, 102, 99, 112];
var MAXSHORT = 32767;
var MINSHORT = -32768;
var toI32 = (v) => v | 0;
var checkProp = (name, v) => {
  if (v < -2147483648 || v > 4294967295) {
    throw new RangeError(
      `PCF: property ${name} value ${v} does not fit in 32 bits`
    );
  }
};
var roundUp4 = (n) => n + 3 & ~3;
var bytesPerRow = (bits, pad) => bits + pad * 8 - 1 >> 3 & ~(pad - 1);
var padIndex = (pad) => pad === 1 ? 0 : pad === 2 ? 1 : pad === 4 ? 2 : 3;
var REVERSE_BYTE = (() => {
  const t = new Uint8Array(256);
  for (let i = 0; i < 256; i++) {
    let r = 0;
    for (let b = 0; b < 8; b++) {
      if (i & 1 << b) {
        r |= 128 >> b;
      }
    }
    t[i] = r;
  }
  return t;
})();
var bitOrderInvert = (buf) => {
  for (let i = 0; i < buf.length; i++) {
    buf[i] = REVERSE_BYTE[buf[i]];
  }
};
var byteSwap = (buf, unit) => {
  if (unit < 2) {
    return;
  }
  const n = buf.length;
  for (let i = 0; i < n; i += unit) {
    const grp = [];
    for (let k = 0; k < unit; k++) {
      grp.push(i + k < n ? buf[i + k] : 0);
    }
    for (let k = 0; k < unit && i + k < n; k++) {
      buf[i + k] = grp[unit - 1 - k];
    }
  }
};
var isZeroMetric = (m) => !(m.ascent || m.descent || m.lsb || m.rsb || m.width);
var isGzip = (u8) => u8.length >= 2 && u8[0] === 31 && u8[1] === 139;
var toU8 = (data) => {
  if (data instanceof Uint8Array) {
    return data;
  }
  if (ArrayBuffer.isView(data)) {
    const v = data;
    return new Uint8Array(v.buffer, v.byteOffset, v.byteLength);
  }
  if (Object.prototype.toString.call(data) === "[object ArrayBuffer]") {
    return new Uint8Array(data);
  }
  throw new TypeError("PCF data must be a Uint8Array or an ArrayBuffer");
};
var initMin = () => ({
  lsb: MAXSHORT,
  rsb: MAXSHORT,
  width: MAXSHORT,
  ascent: MAXSHORT,
  descent: MAXSHORT,
  attributes: 65535
});
var initMax = () => ({
  lsb: MINSHORT,
  rsb: MINSHORT,
  width: MINSHORT,
  ascent: MINSHORT,
  descent: MINSHORT,
  attributes: 0
});
var minmax = (min, max, m) => {
  if (isZeroMetric(m)) {
    return;
  }
  min.ascent = Math.min(min.ascent, m.ascent);
  max.ascent = Math.max(max.ascent, m.ascent);
  min.descent = Math.min(min.descent, m.descent);
  max.descent = Math.max(max.descent, m.descent);
  min.lsb = Math.min(min.lsb, m.lsb);
  max.lsb = Math.max(max.lsb, m.lsb);
  min.rsb = Math.min(min.rsb, m.rsb);
  max.rsb = Math.max(max.rsb, m.rsb);
  min.width = Math.min(min.width, m.width);
  max.width = Math.max(max.width, m.width);
};
var newInfo = (fontAscent, fontDescent) => ({
  minbounds: initMin(),
  maxbounds: initMax(),
  inkMin: initMin(),
  inkMax: initMax(),
  maxOverlap: MINSHORT,
  drawDirection: 0,
  fontAscent,
  fontDescent,
  noOverlap: false,
  constantMetrics: false,
  terminalFont: false,
  constantWidth: false,
  inkInside: false,
  inkMetrics: false
});
var computeFontBounds = (glyphs, encoded, extra, info) => {
  let numneg = 0;
  let numpos = 0;
  const pass = (target, list) => {
    const minb = initMin();
    const maxb = initMax();
    let maxOverlap = MINSHORT;
    for (const g of list) {
      const m = g.m;
      minmax(minb, maxb, m);
      if (m.width < 0) {
        numneg++;
      } else {
        numpos++;
      }
      minb.attributes &= m.attributes;
      maxb.attributes |= m.attributes;
      const overlap = m.rsb - m.width;
      if (maxOverlap < overlap) {
        maxOverlap = overlap;
      }
    }
    target.minbounds = minb;
    target.maxbounds = maxb;
    target.maxOverlap = maxOverlap;
    target.drawDirection = numneg > numpos ? 1 : 0;
  };
  pass(extra, glyphs);
  pass(
    info,
    encoded.map((i) => glyphs[i])
  );
};
var computeAccelerators = (fi) => {
  const min = fi.minbounds;
  const max = fi.maxbounds;
  fi.noOverlap = fi.maxOverlap <= min.lsb;
  if (min.ascent === max.ascent && min.descent === max.descent && min.lsb === max.lsb && min.rsb === max.rsb && min.width === max.width && min.attributes === max.attributes) {
    fi.constantMetrics = true;
    fi.terminalFont = max.lsb === 0 && max.rsb === max.width && max.ascent === fi.fontAscent && max.descent === fi.fontDescent;
  } else {
    fi.constantMetrics = false;
    fi.terminalFont = false;
  }
  fi.constantWidth = min.width === max.width;
  fi.inkInside = min.lsb >= 0 && fi.maxOverlap <= 0 && min.ascent >= -fi.fontDescent && max.ascent <= fi.fontAscent && -min.descent <= fi.fontAscent && max.descent <= fi.fontDescent;
};
var couldBeTerminal = (fi) => {
  const min = fi.minbounds;
  const max = fi.maxbounds;
  if (min.lsb >= 0 && max.rsb <= max.width && min.width === max.width && max.ascent <= fi.fontAscent && max.descent <= fi.fontDescent && (max.lsb !== 0 || min.rsb !== min.width || min.ascent !== fi.fontAscent || min.descent !== fi.fontDescent)) {
    return !(max.ascent === 0 && max.descent === 0);
  }
  return false;
};
var reshape = (src, srcBits, dst, pad) => {
  const outwidth = dst.rsb - dst.lsb;
  const outheight = dst.descent + dst.ascent;
  const outBytes = bytesPerRow(outwidth, pad);
  const inBytes = bytesPerRow(src.rsb - src.lsb, pad);
  const out = new Uint8Array(Math.max(0, outBytes * outheight));
  const yMin = Math.max(-src.ascent, -dst.ascent);
  const yMax = Math.min(src.descent, dst.descent);
  const xMin = Math.max(src.lsb, dst.lsb);
  const xMax = Math.min(src.rsb, dst.rsb);
  let inLine = (yMin + src.ascent) * inBytes;
  let outLine = (yMin + dst.ascent) * outBytes;
  for (let y = yMin; y < yMax; y++) {
    for (let x = xMin; x < xMax; x++) {
      const sx = x - src.lsb;
      const dx = x - dst.lsb;
      if (srcBits[inLine + (sx >> 3)] & 128 >> (sx & 7)) {
        out[outLine + (dx >> 3)] |= 128 >> (dx & 7);
      }
    }
    inLine += inBytes;
    outLine += outBytes;
  }
  return out;
};
var inkMetrics = (m, bits, pad) => {
  const bitWidth = m.rsb - m.lsb;
  const height = m.ascent + m.descent;
  const byteWidth = bitWidth + 7 >> 3;
  const padded = bytesPerRow(bitWidth, pad);
  const rowHasInk = (r) => bits.subarray(r * padded, r * padded + byteWidth).some((b) => b !== 0);
  let top = 0;
  while (top < height && !rowHasInk(top)) {
    top++;
  }
  if (top === height) {
    return { ...m, rsb: m.lsb, ascent: 0, descent: 0 };
  }
  let bottom = height - 1;
  while (!rowHasInk(bottom)) {
    bottom--;
  }
  const column = new Uint8Array(byteWidth);
  for (let r = top; r <= bottom; r++) {
    for (let c = 0; c < byteWidth; c++) {
      column[c] |= bits[r * padded + c];
    }
  }
  let left = 0;
  while (!(column[left >> 3] & 128 >> (left & 7))) {
    left++;
  }
  let right = bitWidth - 1;
  while (!(column[right >> 3] & 128 >> (right & 7))) {
    right--;
  }
  return {
    lsb: m.lsb + left,
    rsb: m.lsb + right + 1,
    width: m.width,
    ascent: m.ascent - top,
    descent: bottom - m.ascent + 1,
    attributes: m.attributes
  };
};
var hexByte = (s, i) => {
  let b = 0;
  for (let k = 0; k < 2; k++) {
    const c = s[i + k];
    if (c >= 48 && c <= 57) {
      b = (b << 4) + (c - 48);
    } else if (c >= 65 && c <= 70) {
      b = (b << 4) + 10 + (c - 65);
    } else if (c >= 97 && c <= 102) {
      b = (b << 4) + 10 + (c - 97);
    }
  }
  return b & 255;
};
var utf8 = (s) => new TextEncoder().encode(s);
var glyphBits = (hexdata, w, h, pad) => {
  const widthBytes = bytesPerRow(w, pad);
  const pic = new Uint8Array(widthBytes * h);
  if (w === 0) {
    return pic;
  }
  const widthHexChars = bytesPerRow(w, 1);
  const lastMask = 255 << 8 - (w & 7) & 255;
  for (let row = 0; row < h; row++) {
    let line = utf8(pyStrip(String(hexdata[row] ?? "")));
    if (line.length & 1) {
      const l2 = new Uint8Array(line.length + 1);
      l2.set(line);
      l2[line.length] = 48;
      line = l2;
    }
    const inLen = line.length >> 1;
    const n = Math.min(inLen, widthHexChars);
    const base = row * widthBytes;
    for (let i = 0; i < n; i++) {
      pic[base + i] = hexByte(line, i * 2);
    }
    if (inLen >= widthHexChars && lastMask) {
      pic[base + widthHexChars - 1] &= lastMask;
    }
  }
  return pic;
};
var scanToken = (s, max) => {
  const tok = s.replace(/^[ \t\n\v\f\r]+/, "").split(/[ \t\n\v\f\r]/)[0];
  const b = utf8(tok);
  return b.length > max ? b.slice(0, max) : b;
};
var ByteWriter = class {
  constructor(size, msb) {
    this.msb = msb;
    this.buf = new Uint8Array(size);
  }
  msb;
  buf;
  pos = 0;
  u8(v) {
    this.buf[this.pos++] = v & 255;
  }
  lsb32(v) {
    this.buf[this.pos++] = v & 255;
    this.buf[this.pos++] = v >>> 8 & 255;
    this.buf[this.pos++] = v >>> 16 & 255;
    this.buf[this.pos++] = v >>> 24 & 255;
  }
  i32(v) {
    if (this.msb) {
      this.buf[this.pos++] = v >>> 24 & 255;
      this.buf[this.pos++] = v >>> 16 & 255;
      this.buf[this.pos++] = v >>> 8 & 255;
      this.buf[this.pos++] = v & 255;
    } else {
      this.lsb32(v);
    }
  }
  i16(v) {
    if (this.msb) {
      this.buf[this.pos++] = v >>> 8 & 255;
      this.buf[this.pos++] = v & 255;
    } else {
      this.buf[this.pos++] = v & 255;
      this.buf[this.pos++] = v >>> 8 & 255;
    }
  }
  bytes(b) {
    this.buf.set(b, this.pos);
    this.pos += b.length;
  }
  /** zero bytes up to the next table offset */
  padTo(offset) {
    this.pos = offset;
  }
  /** the file ends after the last byte written (bdftopcf behaviour) */
  result() {
    return this.buf.slice(0, this.pos);
  }
};
var isInt = (v) => typeof v === "number" && Number.isInteger(v);
var swidthOf = (h, dwx) => {
  const pointsize = h.pointsize;
  const xres = h.xres;
  if (pointsize && xres) {
    return Math.floor(dwx * 72e3 / (pointsize * xres) + 0.5);
  }
  return Math.floor(dwx * 1e3 / Math.max(h.fbbx || 1, 1) + 0.5);
};
function writePcf(font, options = {}) {
  const byteorder = options.byteorder ?? "msb";
  const bitorder = options.bitorder ?? "msb";
  const pad = options.glyphpad ?? 4;
  const scan = options.scanunit ?? 1;
  if (byteorder !== "msb" && byteorder !== "lsb") {
    throw new RangeError(`Invalid PCF byteorder: ${String(byteorder)}`);
  }
  if (bitorder !== "msb" && bitorder !== "lsb") {
    throw new RangeError(`Invalid PCF bitorder: ${String(bitorder)}`);
  }
  if (![1, 2, 4, 8].includes(pad)) {
    throw new RangeError(`Invalid PCF glyphpad: ${String(pad)}`);
  }
  if (![1, 2, 4].includes(scan)) {
    throw new RangeError(`Invalid PCF scanunit: ${String(scan)}`);
  }
  const byteMSB = byteorder === "msb";
  const bitMSB = bitorder === "msb";
  if (bitMSB !== byteMSB && scan > pad) {
    throw new RangeError(
      "PCF scanunit must not exceed glyphpad when bitorder differs from byteorder"
    );
  }
  const h = font.headers ?? {};
  const format = padIndex(scan) << 4 | (bitMSB ? 1 : 0) << 3 | (byteMSB ? 1 : 0) << 2 | padIndex(pad);
  const props = [];
  let fontAscent = null;
  let fontDescent = null;
  let defaultCh = 0;
  const seen = /* @__PURE__ */ new Map();
  for (const [key, value] of propEntries(font.props, font._propnames)) {
    if (value === null || value === void 0) {
      continue;
    }
    if (typeof value !== "string" && typeof value !== "number") {
      continue;
    }
    const name = font._propnames.get(key) ?? key.toUpperCase();
    if (name.startsWith("COMMENT")) {
      continue;
    }
    const isString = !isInt(value);
    if (!isString) {
      checkProp(name, value);
    }
    if (name === "FONT_ASCENT" || name === "FONT_DESCENT") {
      if (!isString) {
        if (name === "FONT_ASCENT") {
          fontAscent = value;
        } else {
          fontDescent = value;
        }
      }
      continue;
    }
    if (name === "DEFAULT_CHAR") {
      if (!isString) {
        defaultCh = value & 65535;
      }
      continue;
    }
    const p = {
      name,
      isString,
      value: isString ? String(value) : value
    };
    props.push(p);
    seen.set(name, p);
  }
  const hint = (v, dflt) => isInt(v) ? v : dflt;
  if (fontAscent === null) {
    fontAscent = hint(h.fbby, 0) + hint(h.fbbyoff, 0);
  }
  if (fontDescent === null) {
    fontDescent = -hint(h.fbbyoff, 0);
  }
  let xres = hint(h.xres, 75);
  let yres = hint(h.yres, 75);
  if (xres < 1) {
    xres = 75;
  }
  if (yres < 1) {
    yres = 75;
  }
  const gen = (name, isString, value) => {
    if (!seen.has(name)) {
      const p = { name, isString, value };
      props.push(p);
      seen.set(name, p);
    }
  };
  gen(
    "POINT_SIZE",
    false,
    Math.trunc(Math.fround(Number(h.pointsize) || 0) * 10)
  );
  gen("FONT", true, String(h.fontname ?? ""));
  gen("WEIGHT", false, -1);
  if (xres === yres) {
    gen("RESOLUTION", false, Math.trunc(xres * 100 / 72.27));
  }
  gen("RESOLUTION_X", false, xres);
  gen("RESOLUTION_Y", false, yres);
  gen("X_HEIGHT", false, -1);
  gen("QUAD_WIDTH", false, -1);
  for (const p of props) {
    if (!p.isString) {
      checkProp(p.name, p.value);
    }
  }
  for (const v of [fontAscent, fontDescent, fontAscent + fontDescent]) {
    if (v < MINSHORT || v > MAXSHORT) {
      throw new RangeError(
        `PCF: FONT_ASCENT ${fontAscent} / FONT_DESCENT ${fontDescent} do not fit in 16 bits`
      );
    }
  }
  const hdwx0 = isInt(h.dwx0) ? h.dwx0 : void 0;
  const hswx0 = isInt(h.swx0) ? h.swx0 : void 0;
  const glyphs = [];
  const bitmapSizes = [0, 0, 0, 0];
  let exHeight = 0;
  let digitWidths = 0;
  let digitCount = 0;
  let firstRow = 256;
  let lastRow = 0;
  let firstCol = 256;
  let lastCol = 0;
  const cells = /* @__PURE__ */ new Map();
  const addGlyph = (meta, enc) => {
    const nameBytes = scanToken(String(meta[0] ?? ""), 99);
    const label = new TextDecoder("utf-8", { ignoreBOM: true }).decode(
      nameBytes
    );
    const bw = meta[2] || 0;
    const bh = meta[3] || 0;
    const bl = meta[4] || 0;
    const bb = meta[5] || 0;
    if (bw < 0 || bh < 0) {
      throw new RangeError(
        `Glyph "${label}" has a negative sized bitmap, ${bw}x${bh}`
      );
    }
    const dwx = meta[8] ?? hdwx0 ?? Math.max(0, bl + bw);
    const swx = meta[6] ?? hswx0 ?? swidthOf(h, dwx);
    for (const v of [dwx, bl, bb, bl + bw, bh + bb, -bb]) {
      if (v < MINSHORT || v > MAXSHORT) {
        throw new RangeError(
          `Glyph "${label}": metric value ${v} does not fit in 16 bits`
        );
      }
    }
    if (nameBytes.length === 1) {
      const c = nameBytes[0];
      if (c >= 48 && c <= 57) {
        digitWidths += dwx;
        digitCount++;
      } else if (c === 120) {
        exHeight = bh + bb <= 0 ? bh : bh + bb;
      }
    }
    const m = {
      lsb: bl,
      rsb: bl + bw,
      ascent: bh + bb,
      descent: -bb,
      width: dwx,
      attributes: 0
    };
    const w2 = m.rsb - m.lsb;
    const ht = m.ascent + m.descent;
    const bits = glyphBits(meta[16] ?? [], w2, ht, pad);
    for (let i = 0; i < 4; i++) {
      bitmapSizes[i] += bytesPerRow(w2, 1 << i) * ht;
    }
    const idx = glyphs.length;
    if (enc >= 0 && enc <= 65535) {
      const row = enc >> 8 & 255;
      const col = enc & 255;
      firstRow = Math.min(firstRow, row);
      lastRow = Math.max(lastRow, row);
      firstCol = Math.min(firstCol, col);
      lastCol = Math.max(lastCol, col);
      cells.set(enc, idx);
    }
    glyphs.push({ m, bits, name: nameBytes, swidth: toI32(swx), enc });
  };
  for (const [cp, meta] of font.glyphs) {
    addGlyph(meta, cp);
  }
  for (const { altcode, meta } of font.unencoded) {
    addGlyph(meta, altcode !== null && altcode >= 0 ? altcode : -1);
  }
  const ncols = lastCol - firstCol + 1;
  const nrows = lastRow - firstRow + 1;
  const nencodings = ncols * nrows;
  const encodingTable = new Int32Array(nencodings).fill(-1);
  const encodedOrder = [];
  if (ncols > 0 && nrows > 0) {
    for (const [enc, idx] of cells) {
      const r = (enc >> 8 & 255) - firstRow;
      const c = (enc & 255) - firstCol;
      encodingTable[r * ncols + c] = idx;
    }
    for (const idx of encodingTable) {
      if (idx >= 0) {
        encodedOrder.push(idx);
      }
    }
  }
  const extra = newInfo(fontAscent, fontDescent);
  const info = newInfo(fontAscent, fontDescent);
  computeFontBounds(glyphs, encodedOrder, extra, info);
  if (couldBeTerminal(info)) {
    const width = info.minbounds.width;
    for (const g of glyphs) {
      const nm = {
        lsb: 0,
        rsb: width,
        width,
        ascent: fontAscent,
        descent: fontDescent,
        attributes: g.m.attributes
      };
      g.bits = reshape(g.m, g.bits, nm, pad);
      g.m = nm;
    }
    for (let i = 0; i < 4; i++) {
      bitmapSizes[i] = glyphs.length * bytesPerRow(width, 1 << i) * (fontAscent + fontDescent);
    }
    computeFontBounds(glyphs, encodedOrder, extra, info);
  }
  computeAccelerators(info);
  computeAccelerators(extra);
  let inks = null;
  if (info.constantMetrics) {
    inks = glyphs.map((g) => inkMetrics(g.m, g.bits, pad));
    info.inkMetrics = true;
  }
  extra.inkMetrics = info.inkMetrics;
  if (inks === null) {
    extra.inkMin = { ...extra.minbounds };
    extra.inkMax = { ...extra.maxbounds };
    info.inkMin = { ...info.minbounds };
    info.inkMax = { ...info.maxbounds };
  } else {
    for (const ci of inks) {
      minmax(extra.inkMin, extra.inkMax, ci);
      extra.inkMin.attributes &= ci.attributes;
      extra.inkMax.attributes |= ci.attributes;
    }
    for (const idx of encodedOrder) {
      const ci = inks[idx];
      minmax(info.inkMin, info.inkMax, ci);
      info.inkMin.attributes &= ci.attributes;
      info.inkMax.attributes |= ci.attributes;
    }
  }
  for (const g of glyphs) {
    if (!bitMSB) {
      bitOrderInvert(g.bits);
    }
    if (bitMSB !== byteMSB) {
      byteSwap(g.bits, scan);
    }
  }
  const xh = seen.get("X_HEIGHT");
  if (xh && xh.value === -1) {
    xh.value = exHeight ? exHeight : info.inkMin.ascent;
  }
  const qw = seen.get("QUAD_WIDTH");
  if (qw && qw.value === -1) {
    qw.value = digitCount ? Math.trunc(digitWidths / digitCount) | 0 : Math.trunc((info.inkMin.width + info.inkMax.width) / 2) | 0;
  }
  const wt = seen.get("WEIGHT");
  if (wt && wt.value === -1) {
    wt.value = 10;
  }
  const nchars = glyphs.length;
  const propStrings = [];
  const propRecs = [];
  let propStringSize = 0;
  for (const p of props) {
    const nb = utf8(p.name);
    propStrings.push(nb);
    const nameOff = propStringSize;
    propStringSize += nb.length + 1;
    if (p.isString) {
      const vb = utf8(String(p.value));
      propStrings.push(vb);
      propRecs.push([nameOff, 1, propStringSize]);
      propStringSize += vb.length + 1;
    } else {
      propRecs.push([nameOff, 0, p.value]);
    }
  }
  const canCompress = (m) => [m.lsb, m.rsb, m.width, m.ascent, m.descent].every(
    (v) => v >= -128 && v <= 127
  ) && m.attributes === 0;
  const metricsCompressed = canCompress(extra.minbounds) && canCompress(extra.maxbounds);
  const inkCompressed = inks !== null && canCompress(extra.inkMin) && canCompress(extra.inkMax);
  let glyphStringSize = 0;
  for (const g of glyphs) {
    glyphStringSize += g.name.length + 1;
  }
  const propSize = 8 + 9 * props.length;
  const propPad = roundUp4(propSize) - propSize;
  const tables = [];
  const add = (type, fmt, size) => {
    tables.push({ type, format: fmt | format, size, offset: 0 });
  };
  add(
    PCF_PROPERTIES,
    PCF_DEFAULT_FORMAT,
    roundUp4(propSize) + 4 + roundUp4(propStringSize)
  );
  add(
    PCF_ACCELERATORS,
    extra.inkMetrics ? PCF_ACCEL_W_INKBOUNDS : PCF_DEFAULT_FORMAT,
    100
  );
  if (metricsCompressed) {
    add(PCF_METRICS, PCF_COMPRESSED_METRICS, roundUp4(6 + nchars * 5));
  } else {
    add(PCF_METRICS, PCF_DEFAULT_FORMAT, 8 + nchars * 12);
  }
  add(
    PCF_BITMAPS,
    PCF_DEFAULT_FORMAT,
    roundUp4(8 + nchars * 4 + 16 + bitmapSizes[padIndex(pad)])
  );
  if (inks !== null) {
    if (inkCompressed) {
      add(PCF_INK_METRICS, PCF_COMPRESSED_METRICS, roundUp4(6 + nchars * 5));
    } else {
      add(PCF_INK_METRICS, PCF_DEFAULT_FORMAT, 8 + nchars * 12);
    }
  }
  add(PCF_BDF_ENCODINGS, PCF_DEFAULT_FORMAT, roundUp4(14 + nencodings * 2));
  add(PCF_SWIDTHS, PCF_DEFAULT_FORMAT, 8 + nchars * 4);
  add(
    PCF_GLYPH_NAMES,
    PCF_DEFAULT_FORMAT,
    8 + nchars * 4 + 4 + roundUp4(glyphStringSize)
  );
  add(
    PCF_BDF_ACCELERATORS,
    info.inkMetrics ? PCF_ACCEL_W_INKBOUNDS : PCF_DEFAULT_FORMAT,
    100
  );
  let offset = 8 + tables.length * 16;
  for (const t of tables) {
    t.offset = offset;
    offset += t.size;
  }
  const w = new ByteWriter(offset, byteMSB);
  w.lsb32(1885562369);
  w.lsb32(tables.length);
  for (const t of tables) {
    w.lsb32(t.type);
    w.lsb32(t.format);
    w.lsb32(t.size);
    w.lsb32(t.offset);
  }
  const putMetric = (m, compressed) => {
    if (compressed) {
      w.u8(m.lsb + 128);
      w.u8(m.rsb + 128);
      w.u8(m.width + 128);
      w.u8(m.ascent + 128);
      w.u8(m.descent + 128);
    } else {
      w.i16(m.lsb);
      w.i16(m.rsb);
      w.i16(m.width);
      w.i16(m.ascent);
      w.i16(m.descent);
      w.i16(m.attributes);
    }
  };
  const putAccel = (fi, withInk) => {
    w.u8(fi.noOverlap ? 1 : 0);
    w.u8(fi.constantMetrics ? 1 : 0);
    w.u8(fi.terminalFont ? 1 : 0);
    w.u8(fi.constantWidth ? 1 : 0);
    w.u8(fi.inkInside ? 1 : 0);
    w.u8(fi.inkMetrics ? 1 : 0);
    w.u8(fi.drawDirection);
    w.u8(0);
    w.i32(fi.fontAscent);
    w.i32(fi.fontDescent);
    w.i32(fi.maxOverlap);
    putMetric(fi.minbounds, false);
    putMetric(fi.maxbounds, false);
    if (withInk) {
      putMetric(fi.inkMin, false);
      putMetric(fi.inkMax, false);
    }
  };
  const putMetrics = (list, compressed) => {
    if (compressed) {
      w.i16(list.length);
    } else {
      w.i32(list.length);
    }
    for (const m of list) {
      putMetric(m, compressed);
    }
  };
  for (const t of tables) {
    w.padTo(t.offset);
    w.lsb32(t.format);
    switch (t.type) {
      case PCF_PROPERTIES: {
        w.i32(props.length);
        for (const [n, s, v] of propRecs) {
          w.i32(n);
          w.u8(s);
          w.i32(v);
        }
        for (let i = 0; i < propPad; i++) {
          w.u8(0);
        }
        w.i32(propStringSize);
        for (const s of propStrings) {
          w.bytes(s);
          w.u8(0);
        }
        break;
      }
      case PCF_ACCELERATORS:
        putAccel(extra, extra.inkMetrics);
        break;
      case PCF_METRICS:
        putMetrics(
          glyphs.map((g) => g.m),
          metricsCompressed
        );
        break;
      case PCF_BITMAPS: {
        w.i32(nchars);
        let off = 0;
        for (const g of glyphs) {
          w.i32(off);
          off += g.bits.length;
        }
        for (let i = 0; i < 4; i++) {
          w.i32(bitmapSizes[i]);
        }
        for (const g of glyphs) {
          w.bytes(g.bits);
        }
        break;
      }
      case PCF_INK_METRICS:
        putMetrics(inks, inkCompressed);
        break;
      case PCF_BDF_ENCODINGS:
        w.i16(firstCol);
        w.i16(lastCol);
        w.i16(firstRow);
        w.i16(lastRow);
        w.i16(defaultCh);
        for (const idx of encodingTable) {
          w.i16(idx >= 0 ? idx : 65535);
        }
        break;
      case PCF_SWIDTHS:
        w.i32(nchars);
        for (const g of glyphs) {
          w.i32(g.swidth);
        }
        break;
      case PCF_GLYPH_NAMES: {
        w.i32(nchars);
        let off = 0;
        for (const g of glyphs) {
          w.i32(off);
          off += g.name.length + 1;
        }
        w.i32(off);
        for (const g of glyphs) {
          w.bytes(g.name);
          w.u8(0);
        }
        break;
      }
      case PCF_BDF_ACCELERATORS:
        putAccel(info, info.inkMetrics);
        break;
    }
  }
  return w.result();
}
var TableReader = class {
  constructor(dv, offset, format, what) {
    this.dv = dv;
    this.format = format;
    this.what = what;
    this.pos = offset;
    this.msb = (format & 4) !== 0;
  }
  dv;
  format;
  what;
  pos;
  msb;
  need(n) {
    if (n < 0 || this.pos < 0 || this.pos + n > this.dv.byteLength) {
      throw new Error(`PCF data truncated while reading ${this.what}`);
    }
  }
  u8() {
    this.need(1);
    return this.dv.getUint8(this.pos++);
  }
  i16() {
    this.need(2);
    const v = this.dv.getInt16(this.pos, !this.msb);
    this.pos += 2;
    return v;
  }
  u16() {
    this.need(2);
    const v = this.dv.getUint16(this.pos, !this.msb);
    this.pos += 2;
    return v;
  }
  i32() {
    this.need(4);
    const v = this.dv.getInt32(this.pos, !this.msb);
    this.pos += 4;
    return v;
  }
  u32() {
    this.need(4);
    const v = this.dv.getUint32(this.pos, !this.msb);
    this.pos += 4;
    return v;
  }
  /** read a count of records of `recordSize` bytes that must fit in the file */
  count(n, recordSize) {
    if (n * recordSize > this.dv.byteLength - this.pos) {
      throw new Error(`PCF data truncated while reading ${this.what}`);
    }
    return n;
  }
};
var decodeBytes = (b) => {
  try {
    return new TextDecoder("utf-8", { fatal: true, ignoreBOM: true }).decode(b);
  } catch {
    let s = "";
    for (const c of b) {
      s += String.fromCharCode(c);
    }
    return s;
  }
};
var cString = (u8, start, end, what) => {
  if (start < 0 || start >= end) {
    throw new Error(`PCF string offset out of range in ${what}`);
  }
  let e = start;
  while (e < end && u8[e] !== 0) {
    e++;
  }
  return decodeBytes(u8.subarray(start, e));
};
function readPcf(data) {
  const u8 = toU8(data);
  if (isGzip(u8)) {
    throw new Error(
      "PCF data is gzip-compressed (.pcf.gz): use the async readPcfAsync() or decompress it first"
    );
  }
  if (u8.length < 4 || PCF_MAGIC.some((b, i) => u8[i] !== b)) {
    throw new Error('Not a PCF file (bad magic, expected "\\x01fcp")');
  }
  const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
  const head = new TableReader(dv, 4, 0, "table count");
  const ntables = head.u32();
  if (ntables > 1024) {
    throw new Error(`Implausible PCF table count ${ntables}`);
  }
  const toc = /* @__PURE__ */ new Map();
  const tocReader = new TableReader(dv, 8, 0, "table of contents");
  for (let i = 0; i < ntables; i++) {
    const type = tocReader.u32();
    tocReader.u32();
    tocReader.u32();
    const offset = tocReader.u32();
    if (!toc.has(type)) {
      toc.set(type, offset);
    }
  }
  const open = (type, what) => {
    const offset = toc.get(type);
    if (offset === void 0) {
      return null;
    }
    const fmt = new TableReader(dv, offset, 0, `${what} format`).u32();
    return new TableReader(dv, offset + 4, fmt, what);
  };
  const readMetrics = (type, what) => {
    const r = open(type, what);
    if (!r) {
      return null;
    }
    const fclass = (r.format & PCF_FORMAT_MASK) >>> 0;
    const out = [];
    if (fclass === PCF_COMPRESSED_METRICS) {
      const n2 = r.count(r.u16(), 5);
      for (let i = 0; i < n2; i++) {
        out.push({
          lsb: r.u8() - 128,
          rsb: r.u8() - 128,
          width: r.u8() - 128,
          ascent: r.u8() - 128,
          descent: r.u8() - 128,
          attributes: 0
        });
      }
    } else if (fclass === PCF_DEFAULT_FORMAT) {
      const n2 = r.count(r.u32(), 12);
      for (let i = 0; i < n2; i++) {
        out.push({
          lsb: r.i16(),
          rsb: r.i16(),
          width: r.i16(),
          ascent: r.i16(),
          descent: r.i16(),
          attributes: r.i16()
        });
      }
    } else {
      throw new Error(
        `Unsupported PCF ${what} format 0x${(r.format >>> 0).toString(16)}`
      );
    }
    return out;
  };
  const metrics = readMetrics(PCF_METRICS, "metrics");
  if (!metrics) {
    throw new Error("PCF file has no METRICS table");
  }
  const n = metrics.length;
  for (const m of metrics) {
    if (m.rsb < m.lsb || m.ascent + m.descent < 0) {
      throw new Error("PCF glyph metrics describe a negative sized bitmap");
    }
  }
  const br = open(PCF_BITMAPS, "bitmaps");
  if (!br) {
    throw new Error("PCF file has no BITMAPS table");
  }
  const bformat = br.format;
  const nbitmaps = br.u32();
  if (nbitmaps !== n) {
    throw new Error(`PCF bitmap count ${nbitmaps} != metrics count ${n}`);
  }
  br.count(n, 4);
  const offsets = [];
  for (let i = 0; i < n; i++) {
    offsets.push(br.u32());
  }
  const sizes = [br.u32(), br.u32(), br.u32(), br.u32()];
  const gpad = 1 << (bformat & 3);
  const scanIdx = bformat >> 4 & 3;
  if (scanIdx > 2) {
    throw new Error(
      `Invalid PCF scan unit in format 0x${(bformat >>> 0).toString(16)}`
    );
  }
  const bitsSize = sizes[bformat & 3];
  br.need(bitsSize);
  const block = u8.slice(br.pos, br.pos + bitsSize);
  const fbitMSB = (bformat & 8) !== 0;
  const fbyteMSB = (bformat & 4) !== 0;
  if (fbitMSB !== fbyteMSB) {
    byteSwap(block, 1 << scanIdx);
  }
  if (!fbitMSB) {
    bitOrderInvert(block);
  }
  const HEX = Array.from(
    { length: 256 },
    (_, i) => i.toString(16).toUpperCase().padStart(2, "0")
  );
  const hexrows = metrics.map((m, i) => {
    const w = m.rsb - m.lsb;
    const h = m.ascent + m.descent;
    if (w === 0 || h === 0) {
      return [];
    }
    const bpr = bytesPerRow(w, gpad);
    const start = offsets[i];
    if (start + bpr * h > bitsSize) {
      throw new Error(`PCF bitmap of glyph ${i} exceeds the bitmap data`);
    }
    const nb = w + 7 >> 3;
    const mask = w & 7 ? 255 << 8 - (w & 7) & 255 : 255;
    const rows = [];
    for (let r = 0; r < h; r++) {
      const o = start + r * bpr;
      let row = "";
      for (let c = 0; c < nb - 1; c++) {
        row += HEX[block[o + c]];
      }
      rows.push(row + HEX[block[o + nb - 1] & mask]);
    }
    return rows;
  });
  const plist = [];
  const pr = open(PCF_PROPERTIES, "properties");
  if (pr) {
    const nprops = pr.count(pr.u32(), 9);
    const entries = [];
    for (let i = 0; i < nprops; i++) {
      entries.push([pr.u32(), pr.u8(), pr.i32()]);
    }
    pr.pos += 4 - (nprops & 3) & 3;
    const ssize = pr.count(pr.u32(), 1);
    const sstart = pr.pos;
    const send = sstart + ssize;
    for (const [nameOff, isString, value] of entries) {
      const name = cString(u8, sstart + nameOff, send, "properties");
      plist.push([
        name,
        isString ? cString(u8, sstart + value, send, "properties") : value
      ]);
    }
  }
  const readAccel = (type) => {
    const r = open(type, "accelerators");
    if (!r) {
      return null;
    }
    r.pos += 8;
    const fontAscent = r.i32();
    const fontDescent = r.i32();
    r.i32();
    const met = () => ({
      lsb: r.i16(),
      rsb: r.i16(),
      width: r.i16(),
      ascent: r.i16(),
      descent: r.i16(),
      attributes: r.i16()
    });
    const minbounds = met();
    const maxbounds = met();
    return { fontAscent, fontDescent, minbounds, maxbounds };
  };
  const accel = readAccel(PCF_ACCELERATORS) ?? readAccel(PCF_BDF_ACCELERATORS);
  const codes = Array.from({ length: n }, () => []);
  let defaultCh = 65535;
  const er = open(PCF_BDF_ENCODINGS, "encodings");
  if (er) {
    const firstCol = er.u16();
    const lastCol = er.u16();
    const firstRow = er.u16();
    const lastRow = er.u16();
    defaultCh = er.u16();
    if (firstCol <= lastCol && firstRow <= lastRow) {
      const ncols = lastCol - firstCol + 1;
      er.count(ncols * (lastRow - firstRow + 1), 2);
      for (let row = firstRow; row <= lastRow; row++) {
        for (let col = firstCol; col <= lastCol; col++) {
          const gi = er.u16();
          if (gi !== 65535) {
            if (gi >= n) {
              throw new Error(`PCF encoding refers to missing glyph ${gi}`);
            }
            codes[gi].push(row << 8 | col);
          }
        }
      }
    }
  }
  let swidths = null;
  const sr = open(PCF_SWIDTHS, "swidths");
  if (sr) {
    const cnt = sr.u32();
    if (cnt !== n) {
      throw new Error(`PCF swidth count ${cnt} != metrics count ${n}`);
    }
    sr.count(n, 4);
    swidths = [];
    for (let i = 0; i < n; i++) {
      swidths.push(sr.i32());
    }
  }
  let names = null;
  const nr = open(PCF_GLYPH_NAMES, "glyph names");
  if (nr) {
    const cnt = nr.u32();
    if (cnt !== n) {
      throw new Error(`PCF glyph name count ${cnt} != metrics count ${n}`);
    }
    nr.count(n, 4);
    const noffs = [];
    for (let i = 0; i < n; i++) {
      noffs.push(nr.u32());
    }
    const ssize = nr.count(nr.u32(), 1);
    const sstart = nr.pos;
    names = noffs.map(
      (o) => cString(u8, sstart + o, sstart + ssize, "glyph names")
    );
  }
  const font = new Font();
  const plower = /* @__PURE__ */ new Map();
  for (const [name, value] of plist) {
    plower.set(name.toLowerCase(), value);
  }
  const fontEntry = plist.find(
    ([name, value]) => name === "FONT" && typeof value === "string"
  );
  let minb;
  let maxb;
  if (accel) {
    minb = accel.minbounds;
    maxb = accel.maxbounds;
  } else {
    minb = initMin();
    maxb = initMax();
    for (const m of metrics) {
      minmax(minb, maxb, m);
    }
  }
  const fbb = maxb.rsb >= minb.lsb && maxb.ascent + maxb.descent >= 0 && minb.lsb !== MAXSHORT ? [
    maxb.rsb - minb.lsb,
    maxb.ascent + maxb.descent,
    minb.lsb,
    0 - maxb.descent
  ] : [0, 0, 0, 0];
  const ps = plower.get("point_size");
  const pxs = plower.get("pixel_size");
  const rx = plower.get("resolution_x");
  const ry = plower.get("resolution_y");
  const headers = {
    bdfversion: 2.1,
    fontname: fontEntry ? fontEntry[1] : "",
    pointsize: typeof ps === "number" ? Math.floor(ps / 10 + 0.5) : typeof pxs === "number" ? pxs : fbb[1],
    xres: typeof rx === "number" ? rx : 75,
    yres: typeof ry === "number" ? ry : 75,
    fbbx: fbb[0],
    fbby: fbb[1],
    fbbxoff: fbb[2],
    fbbyoff: fbb[3],
    metricsset: 0
  };
  font.headers = headers;
  const setprop2 = (name, value) => {
    const k = name.toLowerCase();
    font.props[k] = value;
    if (!font._propnames.has(k)) {
      font._propnames.set(k, name);
    }
  };
  for (const [name, value] of plist) {
    setprop2(name, value);
  }
  if (accel) {
    if (!("font_ascent" in font.props)) {
      setprop2("FONT_ASCENT", accel.fontAscent);
    }
    if (!("font_descent" in font.props)) {
      setprop2("FONT_DESCENT", accel.fontDescent);
    }
  }
  if (!("default_char" in font.props) && defaultCh !== 0 && defaultCh !== 65535) {
    setprop2("DEFAULT_CHAR", defaultCh);
  }
  const unicode = isUnicodeCharset(
    sanitizeCharset(
      font.props["charset_registry"],
      font.props["charset_encoding"]
    )
  );
  for (let i = 0; i < n; i++) {
    const m = metrics[i];
    const sw = swidths ? swidths[i] : swidthOf(headers, m.width);
    const meta = (cp, name) => [
      name,
      cp,
      m.rsb - m.lsb,
      m.ascent + m.descent,
      m.lsb,
      0 - m.descent,
      sw,
      0,
      m.width,
      0,
      null,
      null,
      null,
      null,
      null,
      null,
      hexrows[i].slice()
    ];
    if (codes[i].length === 0) {
      font.unencoded.push({
        altcode: null,
        meta: meta(-1, names ? names[i] : `glyph${i}`)
      });
    } else {
      for (const cp of codes[i]) {
        font.glyphs.set(
          cp,
          meta(cp, names ? names[i] : defaultglyphname(cp, unicode))
        );
      }
    }
  }
  return font;
}
async function readPcfAsync(data) {
  const u8 = toU8(data);
  if (!isGzip(u8)) {
    return readPcf(u8);
  }
  if (typeof DecompressionStream === "undefined") {
    throw new Error(
      "Cannot decompress gzip-compressed PCF: DecompressionStream is not available"
    );
  }
  const stream = new Blob([u8]).stream().pipeThrough(new DecompressionStream("gzip"));
  let buf;
  try {
    buf = await new Response(stream).arrayBuffer();
  } catch (e) {
    throw new Error(
      `Cannot decompress gzip-compressed PCF: ${e.message}`,
      { cause: e }
    );
  }
  return readPcf(new Uint8Array(buf));
}

// fontpixel-recovery-baseline-20261004T1837/fontpixel-rs-phase6-handoff/local-work/phase6-performance/reference/bdfparser-js/src/ttf.ts
var rnd2 = (v) => Math.floor(v + 0.5);
var fmtver = (n) => Number.isInteger(n) ? `${n}.0` : String(n);
var getProp = (props, key) => props[key];
var intProp = (props, key) => {
  const v = getProp(props, key);
  return typeof v === "number" && Number.isInteger(v) ? v : void 0;
};
var strProp = (props, key) => {
  const v = getProp(props, key);
  return typeof v === "string" ? v : void 0;
};
var cpToUnicode = (font, cp) => {
  let s;
  try {
    const f = font.cp2char;
    if (typeof f !== "function") {
      throw new Error("no cp2char");
    }
    s = f.call(font, cp);
  } catch {
    try {
      s = String.fromCodePoint(cp);
    } catch {
      return null;
    }
  }
  if (typeof s !== "string") {
    return null;
  }
  const chars = [...s];
  if (chars.length !== 1) {
    return null;
  }
  const u = chars[0].codePointAt(0);
  return u >= 55296 && u <= 57343 ? null : u;
};
var drawBb = (meta) => {
  const bbw = meta[2];
  const bbh = meta[3];
  const hexdata = meta[16] ?? [];
  if (!(bbw > 0) || !(bbh > 0)) {
    return [];
  }
  const rows = [];
  for (let i = 0; i < bbh; i++) {
    const hex = hexdata[i] ?? "";
    if (!/^[0-9A-Fa-f]*$/.test(hex)) {
      throw hexRowError(meta[0], meta[1], i, hex);
    }
    let bits = "";
    for (let j = 0; j < hex.length && bits.length < bbw; j++) {
      bits += parseInt(hex[j], 16).toString(2).padStart(4, "0");
    }
    rows.push(bits.slice(0, bbw).padEnd(bbw, "0"));
  }
  return rows;
};
var encodeBitmap = (bindata, bbw) => {
  const nbytes = Math.ceil(bbw / 8);
  return bindata.map((row) => {
    const bits = [...row.slice(0, bbw)].map((ch) => ch === "0" ? "0" : "1").join("").padEnd(nbytes * 8, "0");
    let hex = "";
    for (let k = 0; k < bits.length; k += 4) {
      hex += parseInt(bits.slice(k, k + 4), 2).toString(16).toUpperCase();
    }
    return hex;
  });
};
var trimToHex = (bindata, xoff, yoff) => {
  const h = bindata.length;
  const w = h > 0 ? bindata[0].length : 0;
  let top = -1;
  let bottom = -1;
  let left = w;
  let right = -1;
  for (let r = 0; r < h; r++) {
    const row = bindata[r];
    for (let c = 0; c < w; c++) {
      if (row[c] !== "0") {
        if (top < 0) {
          top = r;
        }
        bottom = r;
        if (c < left) {
          left = c;
        }
        if (c > right) {
          right = c;
        }
      }
    }
  }
  if (top < 0) {
    return [0, 0, 0, 0, []];
  }
  const bbw = right - left + 1;
  const bbh = bottom - top + 1;
  const hexdata = encodeBitmap(
    bindata.slice(top, bottom + 1).map((row) => row.slice(left, right + 1)),
    bbw
  );
  return [bbw, bbh, left + xoff, h - 1 - bottom + yoff, hexdata];
};
var Writer = class {
  buf;
  dv;
  length = 0;
  constructor(size = 256) {
    this.buf = new Uint8Array(size);
    this.dv = new DataView(this.buf.buffer);
  }
  ensure(n) {
    if (this.length + n <= this.buf.length) {
      return;
    }
    let size = this.buf.length * 2;
    while (size < this.length + n) {
      size *= 2;
    }
    const nb = new Uint8Array(size);
    nb.set(this.buf.subarray(0, this.length));
    this.buf = nb;
    this.dv = new DataView(nb.buffer);
  }
  check(v, min, max, what) {
    if (!Number.isInteger(v) || v < min || v > max) {
      throw new RangeError(`TTF writer: ${what} value ${v} out of range`);
    }
  }
  u8(v) {
    this.check(v, 0, 255, "uint8");
    this.ensure(1);
    this.dv.setUint8(this.length, v);
    this.length += 1;
    return this;
  }
  u16(v) {
    this.check(v, 0, 65535, "uint16");
    this.ensure(2);
    this.dv.setUint16(this.length, v);
    this.length += 2;
    return this;
  }
  i16(v) {
    this.check(v, -32768, 32767, "int16");
    this.ensure(2);
    this.dv.setInt16(this.length, v);
    this.length += 2;
    return this;
  }
  u32(v) {
    this.check(v, 0, 4294967295, "uint32");
    this.ensure(4);
    this.dv.setUint32(this.length, v);
    this.length += 4;
    return this;
  }
  i64(v) {
    this.check(v, -(2 ** 53), 2 ** 53, "int64");
    this.ensure(8);
    this.dv.setBigInt64(this.length, BigInt(v));
    this.length += 8;
    return this;
  }
  bytes(b) {
    this.ensure(b.length);
    this.buf.set(b, this.length);
    this.length += b.length;
    return this;
  }
  pad4() {
    while (this.length % 4 !== 0) {
      this.u8(0);
    }
    return this;
  }
  result() {
    return this.buf.slice(0, this.length);
  }
};
var utf16be = (s) => {
  const out = new Uint8Array(s.length * 2);
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    out[2 * i] = c >> 8;
    out[2 * i + 1] = c & 255;
  }
  return out;
};
var isWellFormed = (s) => {
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    if (c >= 55296 && c <= 56319) {
      const d = s.charCodeAt(i + 1);
      if (!(d >= 56320 && d <= 57343)) return false;
      i++;
    } else if (c >= 56320 && c <= 57343) {
      return false;
    }
  }
  return true;
};
var decodeUtf16be = (b) => {
  let s = "";
  for (let i = 0; i + 1 < b.length; i += 2) {
    s += String.fromCharCode(b[i] << 8 | b[i + 1]);
  }
  return s;
};
var checksum = (b) => {
  let sum = 0;
  const n = b.length;
  for (let i = 0; i < n; i += 4) {
    const v = (b[i] ?? 0) * 16777216 + ((b[i + 1] ?? 0) << 16) + ((b[i + 2] ?? 0) << 8) + (b[i + 3] ?? 0) >>> 0;
    sum = (sum + v) % 4294967296;
  }
  return sum;
};
var log2floor = (n) => {
  let e = 0;
  while (2 ** (e + 1) <= n) {
    e++;
  }
  return e;
};
var GLYPH_NAME_RE = /^[A-Za-z_.][A-Za-z0-9_.]{0,62}$/;
var contourBounds = (contours) => {
  let xMin = Infinity;
  let yMin = Infinity;
  let xMax = -Infinity;
  let yMax = -Infinity;
  for (const c of contours) {
    for (const [x, y] of c) {
      if (x < xMin) xMin = x;
      if (y < yMin) yMin = y;
      if (x > xMax) xMax = x;
      if (y > yMax) yMax = y;
    }
  }
  return xMin === Infinity ? null : [xMin, yMin, xMax, yMax];
};
var int16Check = (v, what) => {
  if (!Number.isInteger(v) || v < -32768 || v > 32767) {
    throw new RangeError(`TTF writer: ${what} value ${v} out of range (int16)`);
  }
  return v;
};
var encodeGlyf = (g) => {
  if (g.bounds === null) {
    return new Uint8Array(0);
  }
  const nc = g.contours.length;
  let n = 0;
  for (const c of g.contours) n += c.length;
  const flags = new Uint8Array(n);
  const dxs = new Int32Array(n);
  const dys = new Int32Array(n);
  let xlen = 0;
  let ylen = 0;
  let px = 0;
  let py = 0;
  let k = 0;
  for (const c of g.contours) {
    for (const [x, y, on] of c) {
      let f = on ? 1 : 0;
      const dx = x - px;
      const dy = y - py;
      px = x;
      py = y;
      if (dx === 0) {
        f |= 16;
      } else if (dx >= -255 && dx <= 255) {
        f |= dx > 0 ? 18 : 2;
        xlen += 1;
      } else {
        int16Check(dx, "x delta");
        xlen += 2;
      }
      if (dy === 0) {
        f |= 32;
      } else if (dy >= -255 && dy <= 255) {
        f |= dy > 0 ? 36 : 4;
        ylen += 1;
      } else {
        int16Check(dy, "y delta");
        ylen += 2;
      }
      flags[k] = f;
      dxs[k] = dx;
      dys[k] = dy;
      k++;
    }
  }
  if (n > 65535) {
    throw new RangeError(`TTF writer: too many points (${n}) in a glyph`);
  }
  const size = 10 + 2 * nc + 2 + n + xlen + ylen;
  const out = new Uint8Array(Math.ceil(size / 4) * 4);
  const dv = new DataView(out.buffer);
  dv.setInt16(0, int16Check(nc, "numberOfContours"));
  for (let b = 0; b < 4; b++) {
    dv.setInt16(2 + 2 * b, int16Check(g.bounds[b], "glyph bounds"));
  }
  let p = 10;
  let end = -1;
  for (const c of g.contours) {
    end += c.length;
    dv.setUint16(p, end);
    p += 2;
  }
  p += 2;
  out.set(flags, p);
  p += n;
  for (let i = 0; i < n; i++) {
    const d = dxs[i];
    if (d === 0) continue;
    if (d >= -255 && d <= 255) {
      out[p++] = d < 0 ? -d : d;
    } else {
      dv.setInt16(p, d);
      p += 2;
    }
  }
  for (let i = 0; i < n; i++) {
    const d = dys[i];
    if (d === 0) continue;
    if (d >= -255 && d <= 255) {
      out[p++] = d < 0 ? -d : d;
    } else {
      dv.setInt16(p, d);
      p += 2;
    }
  }
  return out;
};
var mappingRuns = (pairs) => {
  const runs = [];
  for (const [code, gid] of pairs) {
    const last = runs[runs.length - 1];
    if (last !== void 0 && code === last[1] + 1 && gid === last[2] + (code - last[0])) {
      last[1] = code;
    } else {
      runs.push([code, code, gid]);
    }
  }
  return runs;
};
var buildCmap = (mapping) => {
  const pairs = [...mapping.entries()].sort((a, b) => a[0] - b[0]);
  const bmpRuns = mappingRuns(pairs.filter(([c]) => c <= 65534)).slice(
    0,
    Math.floor((65535 - 16) / 8) - 1
  );
  const segs = bmpRuns.map(([s, e, g]) => [
    s,
    e,
    ((g - s) % 65536 + 65536) % 65536
  ]);
  segs.push([65535, 65535, 1]);
  const segCount = segs.length;
  const es = log2floor(segCount);
  const searchRange = 2 * 2 ** es;
  const f4 = new Writer();
  f4.u16(4);
  f4.u16(16 + 8 * segCount);
  f4.u16(0);
  f4.u16(2 * segCount);
  f4.u16(searchRange);
  f4.u16(es);
  f4.u16(2 * segCount - searchRange);
  for (const s of segs) f4.u16(s[1]);
  f4.u16(0);
  for (const s of segs) f4.u16(s[0]);
  for (const s of segs) f4.u16(s[2]);
  for (let i = 0; i < segCount; i++) f4.u16(0);
  const allRuns = mappingRuns(pairs);
  const f12 = new Writer();
  f12.u16(12).u16(0).u32(16 + 12 * allRuns.length).u32(0).u32(allRuns.length);
  for (const [s, e, g] of allRuns) {
    f12.u32(s).u32(e).u32(g);
  }
  const b4 = f4.result();
  const b12 = f12.result();
  const w = new Writer();
  w.u16(0).u16(2);
  w.u16(3).u16(1).u32(20);
  w.u16(3).u16(10).u32(20 + b4.length);
  w.bytes(b4).bytes(b12);
  return w.result();
};
var jsonHeaders = (headers) => {
  const o = {};
  for (const [k, v] of Object.entries(headers)) {
    if (v === void 0) {
      continue;
    }
    o[k] = k === "bdfversion" && typeof v === "number" ? fmtver(v) : v;
  }
  return o;
};
var writeTtf = (font, options = {}) => {
  const shape = options.shape ?? "square";
  const dotsize = options.dotsize ?? 1;
  const ppu = options.ppu ?? 64;
  const metadata = options.metadata ?? true;
  const timestamp = options.timestamp ?? 0;
  if (shape !== "square" && shape !== "circle") {
    throw new Error(
      `Invalid shape "${String(shape)}": must be "square" or "circle"`
    );
  }
  if (!(typeof dotsize === "number" && dotsize > 0 && dotsize <= 1.5)) {
    throw new RangeError(
      `Invalid dotsize ${String(dotsize)}: must be in (0, 1.5]`
    );
  }
  if (!Number.isInteger(ppu) || ppu < 2 || ppu % 2 !== 0) {
    throw new RangeError(
      `Invalid ppu ${String(ppu)}: must be an even integer >= 2`
    );
  }
  if (!Number.isInteger(timestamp)) {
    throw new RangeError(`Invalid timestamp ${String(timestamp)}`);
  }
  const H = font.headers;
  if (H === void 0 || H === null) {
    throw new Error("Font is not loaded");
  }
  const props = font.props ?? {};
  const fbby = H.fbby ?? 0;
  const fbbyoff = H.fbbyoff ?? 0;
  const fbbx = H.fbbx ?? 0;
  const ascent = intProp(props, "font_ascent") ?? fbby + fbbyoff;
  const descent = intProp(props, "font_descent") ?? -fbbyoff;
  const pixelSize = intProp(props, "pixel_size");
  const em = pixelSize !== void 0 && pixelSize > 0 ? pixelSize : ascent + descent > 0 ? ascent + descent : fbby;
  const upem = em * ppu;
  if (!(upem >= 16 && upem <= 16384)) {
    throw new RangeError(
      `unitsPerEm ${upem} (em ${em} \xD7 ppu ${ppu}) out of range 16\u202616384`
    );
  }
  const weightName = strProp(props, "weight_name");
  const bold = weightName !== void 0 && weightName.toLowerCase().includes("bold");
  const slant = strProp(props, "slant");
  const italic = slant !== void 0 && ["i", "o"].includes(slant.toLowerCase());
  const contoursOf = (meta) => bitmapContours(drawBb(meta), {
    shape,
    dotsize,
    ppu,
    xoff: meta[4],
    yoff: meta[5]
  });
  const advanceOf = (meta) => {
    const dw = meta[8] ?? H.dwx0 ?? Math.max(0, meta[4] + meta[2]);
    return dw * ppu;
  };
  const glyphs = [];
  const defChar = intProp(props, "default_char");
  const defMeta = defChar !== void 0 ? font.glyphs.get(defChar) : void 0;
  if (defMeta !== void 0) {
    const contours = contoursOf(defMeta);
    glyphs.push({
      name: ".notdef",
      unicode: null,
      contours,
      advance: advanceOf(defMeta),
      bounds: contourBounds(contours)
    });
  } else {
    glyphs.push({
      name: ".notdef",
      unicode: null,
      contours: [],
      advance: fbbx * ppu,
      bounds: null
    });
  }
  const used = /* @__PURE__ */ new Set();
  const pushGlyph = (meta, cp) => {
    const gid = glyphs.length;
    const unicode = cp >= 0 ? cpToUnicode(font, cp) : null;
    const bdfname = meta[0];
    let name2;
    if (typeof bdfname === "string" && GLYPH_NAME_RE.test(bdfname) && bdfname !== ".notdef" && !used.has(bdfname)) {
      name2 = bdfname;
    } else if (unicode !== null && !used.has(defaultglyphname(unicode))) {
      name2 = defaultglyphname(unicode);
    } else {
      name2 = `glyph${gid}`;
    }
    used.add(name2);
    const contours = contoursOf(meta);
    glyphs.push({
      name: name2,
      unicode,
      contours,
      advance: advanceOf(meta),
      bounds: contourBounds(contours)
    });
  };
  const cps = [...font.glyphs.keys()].sort((a, b) => a - b);
  const gidOfCp = /* @__PURE__ */ new Map();
  for (const cp of cps) {
    gidOfCp.set(cp, glyphs.length);
    pushGlyph(font.glyphs.get(cp), cp);
  }
  const unencoded = font.unencoded ?? [];
  const firstUnencodedGid = glyphs.length;
  for (const u of unencoded) {
    pushGlyph(u.meta, -1);
  }
  const numGlyphs = glyphs.length;
  if (numGlyphs > 65535) {
    throw new RangeError(`Too many glyphs (${numGlyphs}) for TrueType`);
  }
  let xMin = 0;
  let yMin = 0;
  let xMax = 0;
  let yMax = 0;
  let anyBounds = false;
  let minLsb = 0;
  let minRsb = 0;
  let maxExtent = 0;
  let maxPoints = 0;
  let maxContours = 0;
  let advMax = 0;
  let advSum = 0;
  let advCount = 0;
  for (const g of glyphs) {
    if (g.advance > advMax) advMax = g.advance;
    if (g.advance > 0) {
      advSum += g.advance;
      advCount++;
    }
    if (g.bounds === null) {
      continue;
    }
    const [gx0, gy0, gx1, gy1] = g.bounds;
    const rsb = g.advance - gx1;
    if (!anyBounds) {
      anyBounds = true;
      [xMin, yMin, xMax, yMax] = g.bounds;
      minLsb = gx0;
      minRsb = rsb;
      maxExtent = gx1;
    } else {
      xMin = Math.min(xMin, gx0);
      yMin = Math.min(yMin, gy0);
      xMax = Math.max(xMax, gx1);
      yMax = Math.max(yMax, gy1);
      minLsb = Math.min(minLsb, gx0);
      minRsb = Math.min(minRsb, rsb);
      maxExtent = Math.max(maxExtent, gx1);
    }
    let pts = 0;
    for (const c of g.contours) pts += c.length;
    maxPoints = Math.max(maxPoints, pts);
    maxContours = Math.max(maxContours, g.contours.length);
  }
  const hheaAscender = ascent * ppu;
  const hheaDescender = -descent * ppu;
  const mapping = /* @__PURE__ */ new Map();
  glyphs.forEach((g, gid) => {
    if (g.unicode !== null && !mapping.has(g.unicode)) {
      mapping.set(g.unicode, gid);
    }
  });
  let minUni = Infinity;
  let maxUni = -Infinity;
  for (const u of mapping.keys()) {
    if (u < minUni) minUni = u;
    if (u > maxUni) maxUni = u;
  }
  const tables = /* @__PURE__ */ new Map();
  const glyf = new Writer(1024);
  const loca = new Writer();
  for (const g of glyphs) {
    loca.u32(glyf.length);
    glyf.bytes(encodeGlyf(g));
  }
  loca.u32(glyf.length);
  tables.set("glyf", glyf.result());
  tables.set("loca", loca.result());
  const ts = timestamp + 2082844800;
  const head = new Writer(54);
  head.u32(65536).u32(65536).u32(0).u32(1594834165);
  head.u16(11).u16(upem).i64(ts).i64(ts);
  head.i16(xMin).i16(yMin).i16(xMax).i16(yMax);
  head.u16((bold ? 1 : 0) | (italic ? 2 : 0));
  head.u16(em).i16(2).i16(1).i16(0);
  tables.set("head", head.result());
  const hhea = new Writer(36);
  hhea.u32(65536).i16(hheaAscender).i16(hheaDescender).i16(0);
  hhea.u16(advMax).i16(minLsb).i16(minRsb).i16(maxExtent);
  hhea.i16(1).i16(0).i16(0);
  hhea.i16(0).i16(0).i16(0).i16(0);
  hhea.i16(0).u16(numGlyphs);
  tables.set("hhea", hhea.result());
  const hmtx = new Writer();
  for (const g of glyphs) {
    hmtx.u16(g.advance).i16(g.bounds === null ? 0 : g.bounds[0]);
  }
  tables.set("hmtx", hmtx.result());
  const maxp = new Writer(32);
  maxp.u32(65536).u16(numGlyphs).u16(maxPoints).u16(maxContours);
  for (const v of [0, 0, 2, 0, 0, 0, 0, 1, 0, 0, 0]) maxp.u16(v);
  tables.set("maxp", maxp.result());
  const xh = intProp(props, "x_height");
  const hasXh = xh !== void 0 && xh > 0;
  const capHeight = intProp(props, "cap_height");
  const os2 = new Writer(96);
  os2.u16(4);
  os2.i16(
    advCount > 0 ? Math.floor((2 * advSum + advCount) / (2 * advCount)) : 0
  );
  os2.u16(bold ? 700 : 400).u16(5).u16(0);
  const sub = Math.floor(upem * 65 / 100);
  os2.i16(sub).i16(sub).i16(0).i16(Math.floor(upem * 14 / 100));
  os2.i16(sub).i16(sub).i16(0).i16(Math.floor(upem * 48 / 100));
  os2.i16(ppu);
  os2.i16(hasXh ? Math.floor(xh * ppu / 2) : Math.floor(ascent * ppu / 3));
  os2.i16(0);
  for (let i = 0; i < 10; i++) os2.u8(0);
  os2.u32(0).u32(0).u32(0).u32(0);
  os2.bytes(new Uint8Array([66, 68, 70, 80]));
  os2.u16(
    (italic ? 1 : 0) | (bold ? 32 : 0) | (!italic && !bold ? 64 : 0) | 128
  );
  os2.u16(mapping.size > 0 ? Math.min(minUni, 65535) : 0);
  os2.u16(mapping.size > 0 ? Math.min(maxUni, 65535) : 0);
  os2.i16(hheaAscender).i16(hheaDescender).i16(0);
  os2.u16(Math.max(hheaAscender, yMax));
  os2.u16(Math.max(-hheaDescender, -yMin, 0));
  os2.u32(1).u32(0);
  os2.i16(hasXh ? xh * ppu : 0);
  os2.i16(capHeight !== void 0 ? capHeight * ppu : ascent * ppu);
  os2.u16(0).u16(32).u16(0);
  tables.set("OS/2", os2.result());
  tables.set("cmap", buildCmap(mapping));
  const present2 = (v) => {
    if (v === void 0 || v === null) {
      return void 0;
    }
    const t = String(v);
    return t === "" ? void 0 : t;
  };
  const nameStr = (key) => present2(getProp(props, key));
  const family = nameStr("family_name") ?? present2(H.fontname) ?? "Untitled";
  const subfamily = bold && italic ? "Bold Italic" : bold ? "Bold" : italic ? "Italic" : "Regular";
  const fullName = subfamily === "Regular" ? family : `${family} ${subfamily}`;
  const psName = fullName.replace(/[^A-Za-z0-9-]/g, "").slice(0, 63) || "Untitled";
  const fontVersion = strProp(props, "font_version");
  const nameRecords = [];
  const copyright = nameStr("copyright");
  if (copyright !== void 0) nameRecords.push([0, copyright]);
  nameRecords.push([1, family]);
  nameRecords.push([2, subfamily]);
  nameRecords.push([3, psName]);
  nameRecords.push([4, fullName]);
  nameRecords.push([
    5,
    fontVersion ? `Version ${fontVersion}` : "Version 1.000"
  ]);
  nameRecords.push([6, psName]);
  const notice = nameStr("notice");
  if (notice !== void 0) nameRecords.push([10, notice]);
  const name = new Writer();
  name.u16(0).u16(nameRecords.length).u16(6 + 12 * nameRecords.length);
  const strData = new Writer();
  for (const [id, s] of nameRecords) {
    const b = utf16be(s);
    name.u16(3).u16(1).u16(1033).u16(id).u16(b.length).u16(strData.length);
    strData.bytes(b);
  }
  name.bytes(strData.result());
  tables.set("name", name.result());
  const spacing = strProp(props, "spacing");
  const fixed = spacing !== void 0 && ["m", "c"].includes(spacing.toLowerCase());
  const ulPos = intProp(props, "underline_position");
  const ulThick = intProp(props, "underline_thickness");
  const post = new Writer();
  post.u32(131072).u32(0);
  post.i16(ulPos !== void 0 ? -ulPos * ppu : -ppu);
  post.i16(ulThick !== void 0 ? ulThick * ppu : ppu);
  post.u32(fixed ? 1 : 0).u32(0).u32(0).u32(0).u32(0);
  post.u16(numGlyphs);
  post.u16(0);
  for (let gid = 1; gid < numGlyphs; gid++) {
    post.u16(258 + gid - 1);
  }
  for (let gid = 1; gid < numGlyphs; gid++) {
    const n = glyphs[gid].name;
    post.u8(n.length);
    for (let i = 0; i < n.length; i++) post.u8(n.charCodeAt(i));
  }
  tables.set("post", post.result());
  tables.set("prep", new Uint8Array([184, 1, 255, 133, 176, 4, 141]));
  if (metadata) {
    const jsonObj = (entries) => "{" + entries.map(([k, v]) => JSON.stringify(k) + ":" + JSON.stringify(v)).join(",") + "}";
    const propsJson = jsonObj(
      propEntries(props, font._propnames).filter(([, v]) => v !== void 0)
    );
    const propnamesJson = jsonObj([...font._propnames]);
    const glyphList = [];
    for (const [cp, meta] of font.glyphs) {
      glyphList.push([gidOfCp.get(cp), cp, meta[0], ...meta.slice(2, 16), null]);
    }
    unencoded.forEach((u, i) => {
      glyphList.push([
        firstUnencodedGid + i,
        -1,
        u.meta[0],
        ...u.meta.slice(2, 16),
        u.altcode ?? null
      ]);
    });
    const json = `{"version":1,"ppu":${ppu},"shape":${JSON.stringify(shape)},"dotsize":${fmtnum(dotsize)},"headers":${JSON.stringify(jsonHeaders(H))},"props":${propsJson},"propnames":${propnamesJson},"glyphs":${JSON.stringify(glyphList)}}`;
    tables.set("BDFP", new TextEncoder().encode(json));
  }
  return assembleSfnt(tables);
};
var assembleSfnt = (tables) => {
  const tags = [...tables.keys()].sort((a, b) => {
    for (let i = 0; i < 4; i++) {
      const d = a.charCodeAt(i) - b.charCodeAt(i);
      if (d !== 0) return d;
    }
    return 0;
  });
  const n = tags.length;
  const es = log2floor(n);
  const searchRange = 16 * 2 ** es;
  const w = new Writer(1024);
  w.u32(65536).u16(n).u16(searchRange).u16(es).u16(16 * n - searchRange);
  let offset = 12 + 16 * n;
  const offsets = [];
  for (const tag of tags) {
    const data = tables.get(tag);
    for (let i = 0; i < 4; i++) w.u8(tag.charCodeAt(i));
    const padded = new Uint8Array(Math.ceil(data.length / 4) * 4);
    padded.set(data);
    w.u32(checksum(padded)).u32(offset).u32(data.length);
    offsets.push(offset);
    offset += padded.length;
  }
  let headOffset = -1;
  tags.forEach((tag, i) => {
    if (tag === "head") headOffset = offsets[i];
    w.bytes(tables.get(tag));
    w.pad4();
  });
  const out = w.result();
  if (headOffset >= 0) {
    const adj = (2981146554 - checksum(out) + 4294967296) % 4294967296;
    new DataView(out.buffer).setUint32(headOffset + 8, adj);
  }
  return out;
};
var STANDARD_MAC_NAMES = ".notdef .null nonmarkingreturn space exclam quotedbl numbersign dollar percent ampersand quotesingle parenleft parenright asterisk plus comma hyphen period slash zero one two three four five six seven eight nine colon semicolon less equal greater question at A B C D E F G H I J K L M N O P Q R S T U V W X Y Z bracketleft backslash bracketright asciicircum underscore grave a b c d e f g h i j k l m n o p q r s t u v w x y z braceleft bar braceright asciitilde Adieresis Aring Ccedilla Eacute Ntilde Odieresis Udieresis aacute agrave acircumflex adieresis atilde aring ccedilla eacute egrave ecircumflex edieresis iacute igrave icircumflex idieresis ntilde oacute ograve ocircumflex odieresis otilde uacute ugrave ucircumflex udieresis dagger degree cent sterling section bullet paragraph germandbls registered copyright trademark acute dieresis notequal AE Oslash infinity plusminus lessequal greaterequal yen mu partialdiff summation product pi integral ordfeminine ordmasculine Omega ae oslash questiondown exclamdown logicalnot radical florin approxequal Delta guillemotleft guillemotright ellipsis nonbreakingspace Agrave Atilde Otilde OE oe endash emdash quotedblleft quotedblright quoteleft quoteright divide lozenge ydieresis Ydieresis fraction currency guilsinglleft guilsinglright fi fl daggerdbl periodcentered quotesinglbase quotedblbase perthousand Acircumflex Ecircumflex Aacute Edieresis Egrave Iacute Icircumflex Idieresis Igrave Oacute Ocircumflex apple Ograve Uacute Ucircumflex Ugrave dotlessi circumflex tilde macron breve dotaccent ring cedilla hungarumlaut ogonek caron Lslash lslash Scaron scaron Zcaron zcaron brokenbar Eth eth Yacute yacute Thorn thorn minus multiply onesuperior twosuperior threesuperior onehalf onequarter threequarters franc Gbreve gbreve Idotaccent Scedilla scedilla Cacute cacute Ccaron ccaron dcroat".split(
  " "
);
var malformed = (msg) => new Error(`Malformed TrueType font: ${msg}`);
var Reader = class {
  constructor(data, base = 0, size = data.length - base) {
    this.data = data;
    this.base = base;
    this.size = size;
    this.dv = new DataView(data.buffer, data.byteOffset, data.byteLength);
  }
  data;
  base;
  size;
  dv;
  at(off, n) {
    if (off < 0 || off + n > this.size || this.base + off + n > this.data.length) {
      throw malformed("read out of bounds");
    }
    return this.base + off;
  }
  u8(off) {
    return this.dv.getUint8(this.at(off, 1));
  }
  i8(off) {
    return this.dv.getInt8(this.at(off, 1));
  }
  u16(off) {
    return this.dv.getUint16(this.at(off, 2));
  }
  i16(off) {
    return this.dv.getInt16(this.at(off, 2));
  }
  u32(off) {
    return this.dv.getUint32(this.at(off, 4));
  }
  bytes(off, n) {
    const s = this.at(off, n);
    return this.data.subarray(s, s + n);
  }
  tag(off) {
    return String.fromCharCode(...this.bytes(off, 4));
  }
};
var GlyfReader = class {
  constructor(glyf, loca) {
    this.glyf = glyf;
    this.loca = loca;
  }
  glyf;
  loca;
  contours(gid, depth = 0) {
    if (depth > 32) {
      throw malformed("composite glyph nesting too deep");
    }
    if (gid < 0 || gid + 1 >= this.loca.length) {
      throw malformed(`glyph index ${gid} out of range`);
    }
    const start = this.loca[gid];
    const end = this.loca[gid + 1];
    if (end <= start) {
      return [];
    }
    if (end > this.glyf.size) {
      throw malformed("loca points beyond glyf");
    }
    const nc = this.glyf.i16(start);
    return nc >= 0 ? this.simple(start, nc) : this.composite(start, depth);
  }
  simple(off, nc) {
    const r = this.glyf;
    let p = off + 10;
    const ends = [];
    for (let i = 0; i < nc; i++) {
      ends.push(r.u16(p));
      p += 2;
    }
    const npts = nc > 0 ? ends[nc - 1] + 1 : 0;
    const ilen = r.u16(p);
    p += 2 + ilen;
    const flags = [];
    while (flags.length < npts) {
      const f = r.u8(p++);
      flags.push(f);
      if (f & 8) {
        const rep = r.u8(p++);
        for (let k = 0; k < rep; k++) flags.push(f);
      }
    }
    flags.length = npts;
    const xs = [];
    let v = 0;
    for (const f of flags) {
      if (f & 2) {
        const d = r.u8(p++);
        v += f & 16 ? d : -d;
      } else if (!(f & 16)) {
        v += r.i16(p);
        p += 2;
      }
      xs.push(v);
    }
    const ys = [];
    v = 0;
    for (const f of flags) {
      if (f & 4) {
        const d = r.u8(p++);
        v += f & 32 ? d : -d;
      } else if (!(f & 32)) {
        v += r.i16(p);
        p += 2;
      }
      ys.push(v);
    }
    const out = [];
    let s = 0;
    for (const e of ends) {
      if (e < s - 1 || e >= npts) {
        throw malformed("bad endPtsOfContours");
      }
      const c = [];
      for (let i = s; i <= e; i++) c.push([xs[i], ys[i], (flags[i] & 1) === 1]);
      out.push(c);
      s = e + 1;
    }
    return out;
  }
  composite(off, depth) {
    const r = this.glyf;
    let p = off + 10;
    const result = [];
    for (; ; ) {
      const flags = r.u16(p);
      const gi = r.u16(p + 2);
      p += 4;
      const xy = (flags & 2) !== 0;
      let a1;
      let a2;
      if (flags & 1) {
        a1 = xy ? r.i16(p) : r.u16(p);
        a2 = xy ? r.i16(p + 2) : r.u16(p + 2);
        p += 4;
      } else {
        a1 = xy ? r.i8(p) : r.u8(p);
        a2 = xy ? r.i8(p + 1) : r.u8(p + 1);
        p += 2;
      }
      let xx = 1;
      let xy2 = 0;
      let yx = 0;
      let yy = 1;
      if (flags & 8) {
        xx = yy = r.i16(p) / 16384;
        p += 2;
      } else if (flags & 64) {
        xx = r.i16(p) / 16384;
        yy = r.i16(p + 2) / 16384;
        p += 4;
      } else if (flags & 128) {
        xx = r.i16(p) / 16384;
        xy2 = r.i16(p + 2) / 16384;
        yx = r.i16(p + 4) / 16384;
        yy = r.i16(p + 6) / 16384;
        p += 8;
      }
      const comp = this.contours(gi, depth + 1);
      const tr = comp.map(
        (c) => c.map(([x, y, on]) => [x * xx + y * yx, x * xy2 + y * yy, on])
      );
      let dx;
      let dy;
      if (xy) {
        dx = a1;
        dy = a2;
      } else {
        const parent = result.flat();
        const child = tr.flat();
        if (a1 >= parent.length || a2 >= child.length) {
          throw malformed("bad composite point index");
        }
        dx = parent[a1][0] - child[a2][0];
        dy = parent[a1][1] - child[a2][1];
      }
      for (const c of tr) {
        result.push(c.map(([x, y, on]) => [x + dx, y + dy, on]));
      }
      if (!(flags & 32)) {
        break;
      }
    }
    return result;
  }
};
var parseCmapSubtable = (r, off, format) => {
  const m = /* @__PURE__ */ new Map();
  if (format === 0) {
    for (let c = 0; c < 256; c++) {
      const g = r.u8(off + 6 + c);
      if (g) m.set(c, g);
    }
  } else if (format === 6) {
    const first = r.u16(off + 6);
    const count = r.u16(off + 8);
    for (let i = 0; i < count; i++) {
      const g = r.u16(off + 10 + 2 * i);
      if (g) m.set(first + i, g);
    }
  } else if (format === 4) {
    const segX2 = r.u16(off + 6);
    const n = Math.floor(segX2 / 2);
    const endsO = off + 14;
    const startsO = off + 16 + segX2;
    const deltasO = off + 16 + 2 * segX2;
    const roffBase = off + 16 + 3 * segX2;
    for (let i = 0; i < n; i++) {
      const s = r.u16(startsO + 2 * i);
      const e = r.u16(endsO + 2 * i);
      const d = r.u16(deltasO + 2 * i);
      const ro = r.u16(roffBase + 2 * i);
      for (let c = s; c <= e; c++) {
        if (c === 65535) continue;
        let g;
        if (ro === 0) {
          g = c + d & 65535;
        } else {
          g = r.u16(roffBase + 2 * i + ro + 2 * (c - s));
          if (g) g = g + d & 65535;
        }
        if (g) m.set(c, g);
      }
    }
  } else {
    const ngroups = r.u32(off + 12);
    r.bytes(off + 16, 12 * ngroups);
    for (let i = 0; i < ngroups; i++) {
      const s = r.u32(off + 16 + 12 * i);
      const e = r.u32(off + 20 + 12 * i);
      const sg = r.u32(off + 24 + 12 * i);
      if (e < s || e > 1114111) {
        throw malformed("bad cmap format 12 group");
      }
      for (let c = s; c <= e; c++) {
        const g = sg + c - s;
        if (g) m.set(c, g);
      }
    }
  }
  return m;
};
var CMAP_PREFS = [
  [3, 10],
  [0, 4],
  [0, 6],
  [3, 1],
  [0, 3]
];
var parseCmap = (r) => {
  const n = r.u16(2);
  const recs = [];
  for (let i = 0; i < n; i++) {
    recs.push([r.u16(4 + 8 * i), r.u16(6 + 8 * i), r.u32(8 + 8 * i)]);
  }
  const order = [];
  for (const [pid, eid] of CMAP_PREFS) {
    order.push(...recs.filter((x) => x[0] === pid && x[1] === eid));
  }
  order.push(...recs.filter((x) => !order.includes(x)));
  for (const [, , off] of order) {
    const fmt = r.u16(off);
    if (fmt === 0 || fmt === 4 || fmt === 6 || fmt === 12) {
      return parseCmapSubtable(r, off, fmt);
    }
  }
  return /* @__PURE__ */ new Map();
};
var decodeUtf16beStrict = (b) => {
  if (b.length % 2 !== 0) {
    return null;
  }
  const s = decodeUtf16be(b);
  return isWellFormed(s) ? s : null;
};
var parseName = (r) => {
  const count = r.u16(2);
  const soff = r.u16(4);
  const found = /* @__PURE__ */ new Map();
  let macDecoder = null;
  for (let i = 0; i < count; i++) {
    const o = 6 + 12 * i;
    const pid = r.u16(o);
    const eid = r.u16(o + 2);
    const lid = r.u16(o + 4);
    const nid = r.u16(o + 6);
    const ln = r.u16(o + 8);
    const off = r.u16(o + 10);
    let prio;
    let mac = false;
    if (pid === 3 && (eid === 0 || eid === 1 || eid === 10)) {
      prio = lid === 1033 ? 0 : 1;
    } else if (pid === 0) {
      prio = 2;
    } else if (pid === 1 && eid === 0) {
      prio = 3;
      mac = true;
    } else {
      continue;
    }
    const raw = r.bytes(soff + off, ln);
    let s;
    if (mac) {
      macDecoder ??= new TextDecoder("macintosh");
      s = macDecoder.decode(raw);
    } else {
      s = decodeUtf16beStrict(raw);
    }
    if (s === null) {
      continue;
    }
    const cur = found.get(nid);
    if (cur === void 0 || prio < cur[0]) {
      found.set(nid, [prio, s]);
    }
  }
  const m = /* @__PURE__ */ new Map();
  for (const [k, [, s]] of found) m.set(k, s);
  return m;
};
var latin1 = (b) => {
  let s = "";
  for (const c of b) s += String.fromCharCode(c);
  return s;
};
var parsePost = (r, numGlyphs) => {
  const ver = r.u32(0);
  if (ver === 65536) {
    const names2 = STANDARD_MAC_NAMES.slice(0, numGlyphs);
    while (names2.length < numGlyphs) names2.push("");
    return names2;
  }
  if (ver !== 131072) {
    return null;
  }
  const n = r.u16(32);
  const idx = [];
  for (let i = 0; i < n; i++) idx.push(r.u16(34 + 2 * i));
  let pos = 34 + 2 * n;
  const custom = [];
  while (pos < r.size) {
    const ln = r.u8(pos);
    custom.push(latin1(r.bytes(pos + 1, Math.min(ln, r.size - pos - 1))));
    pos += 1 + ln;
  }
  const names = [];
  for (let i = 0; i < Math.min(n, numGlyphs); i++) {
    const k = idx[i];
    names.push(k < 258 ? STANDARD_MAC_NAMES[k] : custom[k - 258] ?? "");
  }
  while (names.length < numGlyphs) names.push("");
  return names;
};
var present = (v) => {
  if (v === void 0 || v === null) {
    return void 0;
  }
  const t = String(v);
  return t === "" ? void 0 : t;
};
var MAX_GLYPH_PIXELS = 1 << 24;
var checkBox = (gid, w, h) => {
  if (Math.max(w, 1) * Math.max(h, 1) > MAX_GLYPH_PIXELS) {
    throw new Error(
      `Malformed TrueType font: glyph ${gid} bounding box too large (${w}x${h} pixels)`
    );
  }
};
var rasterMeta = (gid, contours, ppu, box) => {
  const meta = new Array(17).fill(null);
  if (box !== null) {
    const [w2, h2, xo, yo] = box;
    meta[2] = w2;
    meta[3] = h2;
    meta[4] = xo;
    meta[5] = yo;
    checkBox(gid, w2, h2);
    if (w2 > 0 && h2 > 0) {
      meta[16] = encodeBitmap(rasterize(contours, ppu, xo, yo, w2, h2), w2);
    } else if (w2 > 0) {
      meta[16] = [];
    } else {
      meta[16] = new Array(Math.max(h2, 0)).fill("");
    }
    return meta;
  }
  let xmin = Infinity;
  let ymin = Infinity;
  let xmax = -Infinity;
  let ymax = -Infinity;
  for (const c of contours) {
    for (const [x, y] of c) {
      if (x < xmin) xmin = x;
      if (y < ymin) ymin = y;
      if (x > xmax) xmax = x;
      if (y > ymax) ymax = y;
    }
  }
  if (xmin === Infinity) {
    meta[2] = meta[3] = meta[4] = meta[5] = 0;
    meta[16] = [];
    return meta;
  }
  const x0 = Math.floor(xmin / ppu);
  const y0 = Math.floor(ymin / ppu);
  const w = Math.ceil(xmax / ppu) - x0;
  const h = Math.ceil(ymax / ppu) - y0;
  checkBox(gid, w, h);
  const bm = w > 0 && h > 0 ? rasterize(contours, ppu, x0, y0, w, h) : [];
  const [tw, th, txo, tyo, hex] = trimToHex(bm, x0, y0);
  meta[2] = tw;
  meta[3] = th;
  meta[4] = txo;
  meta[5] = tyo;
  meta[16] = hex;
  return meta;
};
var setprop = (font, key, value) => {
  const k = key.toLowerCase();
  font.props[k] = value;
  font._propnames.set(k, key);
};
var isInt2 = (v) => typeof v === "number" && Number.isInteger(v);
var readTtf = (data, options = {}) => {
  let bytes;
  if (ArrayBuffer.isView(data)) {
    bytes = new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
  } else if (Object.prototype.toString.call(data) === "[object ArrayBuffer]") {
    bytes = new Uint8Array(data);
  } else {
    throw new TypeError("TrueType data must be a Uint8Array or an ArrayBuffer");
  }
  if (bytes.length < 12) {
    throw malformed("file too short");
  }
  const r = new Reader(bytes);
  const tag = r.tag(0);
  if (tag === "OTTO") {
    throw new Error("CFF-based OpenType is not supported");
  }
  if (tag !== "\0\0\0" && tag !== "true") {
    throw new Error(`Not a TrueType font (sfnt version ${JSON.stringify(tag)})`);
  }
  const num = r.u16(4);
  if (12 + 16 * num > bytes.length) {
    throw malformed("table directory is truncated");
  }
  const tables = /* @__PURE__ */ new Map();
  for (let i = 0; i < num; i++) {
    const o = 12 + 16 * i;
    const t = r.tag(o);
    const off = r.u32(o + 8);
    const len = r.u32(o + 12);
    if (off + len > bytes.length) {
      throw malformed(`table '${t}' exceeds the file`);
    }
    tables.set(t, new Reader(bytes, off, len));
  }
  for (const req of ["head", "maxp", "hhea", "hmtx", "loca", "glyf"]) {
    if (!tables.has(req)) {
      throw malformed(`missing required table '${req}'`);
    }
  }
  const tbl = (t) => tables.get(t);
  const head = tbl("head");
  const upem = head.u16(18);
  const locfmt = head.i16(50);
  const numGlyphs = tbl("maxp").u16(4);
  const hhea = tbl("hhea");
  const asc = hhea.i16(4);
  const desc = hhea.i16(6);
  const nhm = hhea.u16(34);
  if (nhm === 0 || nhm > numGlyphs) {
    throw malformed("bad hhea.numberOfHMetrics");
  }
  const hmtx = tbl("hmtx");
  const advances = [];
  for (let i = 0; i < nhm; i++) advances.push(hmtx.u16(4 * i));
  while (advances.length < numGlyphs) advances.push(advances[nhm - 1]);
  const lr = tbl("loca");
  const loca = [];
  if (locfmt === 0) {
    for (let i = 0; i <= numGlyphs; i++) loca.push(lr.u16(2 * i) * 2);
  } else if (locfmt === 1) {
    for (let i = 0; i <= numGlyphs; i++) loca.push(lr.u32(4 * i));
  } else {
    throw malformed("bad head.indexToLocFormat");
  }
  const gr = new GlyfReader(tbl("glyf"), loca);
  const font = new Font();
  font.headers = {};
  font.props = newProps();
  font.glyphs = /* @__PURE__ */ new Map();
  font.unencoded = [];
  font._propnames = /* @__PURE__ */ new Map();
  const invalidate = () => font._invalidate();
  const bdfpT = tables.get("BDFP");
  if (bdfpT !== void 0) {
    readWithBdfp(font, bdfpT.bytes(0, bdfpT.size), gr, advances, numGlyphs);
    invalidate();
    return font;
  }
  const pixelsize = options.pixelsize;
  if (pixelsize === void 0 || pixelsize === null) {
    throw new Error(
      "pixelsize is required to read a TrueType font without BDFP metadata"
    );
  }
  if (!isInt2(pixelsize) || pixelsize <= 0) {
    throw new RangeError(
      `pixelsize must be a positive integer, not ${String(pixelsize)}`
    );
  }
  const ppu = upem / pixelsize;
  const names = tables.has("name") ? parseName(tbl("name")) : /* @__PURE__ */ new Map();
  const cmap = tables.has("cmap") ? parseCmap(tbl("cmap")) : /* @__PURE__ */ new Map();
  const post = tables.has("post") ? parsePost(tbl("post"), numGlyphs) : null;
  const cps = /* @__PURE__ */ new Map();
  for (const c of [...cmap.keys()].sort((a, b) => a - b)) {
    const g = cmap.get(c);
    if (g > 0 && g < numGlyphs && !cps.has(g)) {
      cps.set(g, c);
    }
  }
  const fontname = present(names.get(6)) ?? present(names.get(4)) ?? "Untitled";
  const ascent = rnd2(asc / ppu);
  const descent = rnd2(-desc / ppu);
  font.headers = {
    bdfversion: 2.1,
    fontname,
    pointsize: pixelsize,
    xres: 75,
    yres: 75,
    fbbx: pixelsize,
    fbby: ascent + descent,
    fbbxoff: 0,
    fbbyoff: -descent,
    metricsset: 0
  };
  setprop(font, "FAMILY_NAME", present(names.get(1)) ?? fontname);
  const copyright = present(names.get(0));
  if (copyright !== void 0) {
    setprop(font, "COPYRIGHT", copyright);
  }
  setprop(font, "PIXEL_SIZE", pixelsize);
  setprop(font, "FONT_ASCENT", ascent);
  setprop(font, "FONT_DESCENT", descent);
  setprop(font, "CHARSET_REGISTRY", "ISO10646");
  setprop(font, "CHARSET_ENCODING", "1");
  for (let gid = 1; gid < numGlyphs; gid++) {
    const cp = cps.get(gid);
    const pname = post !== null ? post[gid] : "";
    const name = pname ? pname : cp !== void 0 ? defaultglyphname(cp) : `glyph${gid}`;
    const meta = rasterMeta(gid, gr.contours(gid), ppu, null);
    const dwx = rnd2(advances[gid] / ppu);
    meta[0] = name;
    meta[1] = cp ?? -1;
    meta[8] = dwx;
    meta[9] = 0;
    meta[6] = font.swidth(dwx);
    meta[7] = 0;
    if (cp !== void 0) {
      font.glyphs.set(cp, meta);
    } else {
      font.unencoded.push({ altcode: null, meta });
    }
  }
  updateBbox(font, pixelsize, ascent, descent);
  invalidate();
  return font;
};
var updateBbox = (font, em, ascent, descent) => {
  let x0 = Infinity;
  let y0 = Infinity;
  let x1 = -Infinity;
  let y1 = -Infinity;
  const metas = [...font.glyphs.values(), ...font.unencoded.map((u) => u.meta)];
  for (const m of metas) {
    if (m[2] > 0 && m[3] > 0) {
      x0 = Math.min(x0, m[4]);
      y0 = Math.min(y0, m[5]);
      x1 = Math.max(x1, m[4] + m[2]);
      y1 = Math.max(y1, m[5] + m[3]);
    }
  }
  const h = font.headers;
  if (x0 !== Infinity) {
    h.fbbx = x1 - x0;
    h.fbby = y1 - y0;
    h.fbbxoff = x0;
    h.fbbyoff = y0;
  } else {
    h.fbbx = em;
    h.fbby = ascent + descent;
    h.fbbxoff = 0;
    h.fbbyoff = -descent;
  }
};
var parseJsonOrdered = (text) => {
  let i = 0;
  const lit = /true|false|null|-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?/y;
  const ws = () => {
    while (i < text.length && " 	\n\r".includes(text[i])) i++;
  };
  const str = () => {
    const start = i++;
    while (text[i] !== '"') i += text[i] === "\\" ? 2 : 1;
    i++;
    return JSON.parse(text.slice(start, i));
  };
  const val = () => {
    ws();
    const c = text[i];
    if (c === "{" || c === "[") {
      i++;
      const map = /* @__PURE__ */ new Map();
      const arr = [];
      ws();
      if (text[i] === (c === "{" ? "}" : "]")) {
        i++;
        return c === "{" ? map : arr;
      }
      for (; ; ) {
        if (c === "{") {
          ws();
          const k = str();
          ws();
          i++;
          map.set(k, val());
        } else {
          arr.push(val());
        }
        ws();
        if (text[i++] !== ",") return c === "{" ? map : arr;
      }
    }
    if (c === '"') return str();
    lit.lastIndex = i;
    const m = lit.exec(text);
    i += m[0].length;
    return JSON.parse(m[0]);
  };
  return val();
};
var badBdfp = (msg) => new Error(`Malformed BDFP table: ${msg}`);
var readWithBdfp = (font, raw, gr, advances, numGlyphs) => {
  let obj;
  try {
    const text = new TextDecoder("utf-8", {
      fatal: true,
      ignoreBOM: true
    }).decode(raw);
    JSON.parse(text);
    obj = parseJsonOrdered(text);
  } catch (e) {
    throw badBdfp(String(e));
  }
  const isObj = (v) => v instanceof Map;
  if (!isObj(obj)) {
    throw badBdfp("bad structure");
  }
  const ppu = obj.get("ppu");
  const headers = obj.get("headers");
  const props = obj.get("props");
  const propnames = obj.get("propnames");
  const entries = obj.get("glyphs");
  if (ppu === void 0 || headers === void 0 || props === void 0 || propnames === void 0 || entries === void 0) {
    throw badBdfp("missing key");
  }
  if (typeof ppu !== "number" || !(ppu > 0)) {
    throw badBdfp("bad ppu");
  }
  if (!isObj(headers) || !isObj(props) || !Array.isArray(entries)) {
    throw badBdfp("bad structure");
  }
  const H = font.headers;
  for (const [k, v] of headers) {
    H[k] = k === "bdfversion" ? parseFloat(String(v)) : v;
  }
  const names = isObj(propnames) ? propnames : /* @__PURE__ */ new Map();
  for (const [k, v] of props) {
    ;
    font.props[k] = v;
    if (names.has(k)) {
      font._propnames.set(k, String(names.get(k)));
    }
  }
  for (const [k, v] of names) {
    font._propnames.set(k, String(v));
  }
  for (const e of entries) {
    if (!Array.isArray(e) || e.length !== 3 && e.length !== 18) {
      throw badBdfp("bad glyph entry");
    }
    const [gid, cp, name] = e;
    if (!isInt2(gid) || !(gid > 0 && gid < numGlyphs) || !isInt2(cp)) {
      throw badBdfp("bad glyph entry");
    }
    const contours = gr.contours(gid);
    let meta;
    let altcode = null;
    if (e.length === 18) {
      meta = rasterMeta(gid, contours, ppu, [e[3], e[4], e[5], e[6]]);
      for (let k = 6; k < 16; k++) {
        meta[k] = e[k + 1];
      }
      altcode = e[17];
    } else {
      meta = rasterMeta(gid, contours, ppu, null);
      const dwx = rnd2(advances[gid] / ppu);
      meta[8] = dwx;
      meta[9] = 0;
      meta[6] = font.swidth(dwx);
      meta[7] = 0;
    }
    meta[0] = name;
    meta[1] = cp;
    if (cp === -1) {
      font.unencoded.push({ altcode, meta });
    } else {
      font.glyphs.set(cp, meta);
    }
  }
};

// fontpixel-recovery-baseline-20261004T1837/fontpixel-rs-phase6-handoff/local-work/phase6-performance/reference/bdfparser-js/src/Font.ts
var RE_INT = /^[+-]?[0-9]+$/;
var RE_VERSION = /^[0-9]+(?:\.[0-9]+)?$/;
var INT32_MIN = -2147483648;
var INT32_MAX = 2147483647;
var UINT32_MAX = 4294967295;
var RE_WS = /[ \t\n\v\f\r]/;
var RE_WS_RUN = /[ \t\n\v\f\r]+/;
var RE_TRIM = /^[ \t\n\v\f\r]+|[ \t\n\v\f\r]+$/g;
var RE_VVECTOR_DELIMITER = /[ \t\n\v\f\r,]+/;
var wsTrim = (s) => s.replace(RE_TRIM, "");
var REQUIRED_HEADERS = [
  "pointsize",
  "xres",
  "yres",
  "fbbx",
  "fbby",
  "fbbxoff",
  "fbbyoff"
];
var rnd3 = (v) => Math.floor(v + 0.5);
var fmtver2 = (v) => Number.isInteger(v) ? `${v}.0` : String(v);
var stripQuotePair = (s) => s.length >= 2 && s.startsWith('"') && s.endsWith('"') ? s.slice(1, -1) : s;
var cloneList = (list) => {
  const l = [...list];
  l[16] = [...list[16]];
  return l;
};
var cpInRange = (cp, r) => {
  if (r === null) {
    return true;
  }
  if (typeof r === "number") {
    return cp < r;
  }
  if (r.length === 2 && typeof r[0] === "number" && typeof r[1] === "number") {
    return cp >= r[0] && cp <= r[1];
  }
  for (const t of r) {
    if (Array.isArray(t) && cp >= t[0] && cp <= t[1]) {
      return true;
    }
  }
  return false;
};
var toBytes = (data) => {
  if (ArrayBuffer.isView(data)) {
    return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
  }
  if (Object.prototype.toString.call(data) === "[object ArrayBuffer]") {
    return new Uint8Array(data);
  }
  throw new TypeError("Expected a Uint8Array, an ArrayBuffer or a typed array");
};
var isGzip2 = (b) => b.length >= 2 && b[0] === 31 && b[1] === 139;
var gunzip = async (data) => {
  if (typeof DecompressionStream === "undefined") {
    throw new Error(
      "Cannot decompress gzip data: DecompressionStream is not available"
    );
  }
  const ds = new DecompressionStream("gzip");
  const writer = ds.writable.getWriter();
  const written = writer.write(data).then(() => writer.close());
  written.catch(() => void 0);
  const reader = ds.readable.getReader();
  const chunks = [];
  let total = 0;
  for (; ; ) {
    const { done, value } = await reader.read();
    if (done) {
      break;
    }
    chunks.push(value);
    total += value.length;
  }
  await written;
  const out = new Uint8Array(total);
  let o = 0;
  for (const c of chunks) {
    out.set(c, o);
    o += c.length;
  }
  return out;
};
var GLYPH_METRICS = {
  SWIDTH: 6,
  DWIDTH: 8,
  SWIDTH1: 10,
  DWIDTH1: 12,
  VVECTOR: 14
};
var GLOBAL_METRICS = {
  SWIDTH: ["swx0", "swy0"],
  DWIDTH: ["dwx0", "dwy0"],
  SWIDTH1: ["swx1", "swy1"],
  DWIDTH1: ["dwx1", "dwy1"],
  VVECTOR: ["vvectorx", "vvectory"]
};
var NO_PROPS_WARNING = "It looks like the font does not have property block beginning with 'STARTPROPERTIES' keyword";
var BdfParser = class {
  constructor(font) {
    this.font = font;
    this.headers = font.headers;
  }
  font;
  lineno = 0;
  state = 0;
  chars = null;
  propcount = null;
  propseen = 0;
  nglyphs = 0;
  meta = [];
  used = /* @__PURE__ */ new Set();
  startline = 0;
  altcode = null;
  headers;
  /** feed a whole text (a final line break does not start a new line) */
  feedText(text) {
    const lines = text.split(/\r\n|\r|\n/);
    if (lines[lines.length - 1] === "") {
      lines.pop();
    }
    for (const l of lines) {
      this.line(l);
    }
  }
  /** feed one line (a chunk containing line breaks is split into lines) */
  feed(chunk) {
    if (chunk.indexOf("\n") === -1 && chunk.indexOf("\r") === -1) {
      this.line(chunk);
    } else {
      this.feedText(chunk);
    }
  }
  /** parse `n` integers (at least `n` tokens required) */
  ints(value, n, key, sep = RE_WS_RUN) {
    const v = wsTrim(value);
    const parts = v === "" ? [] : v.split(sep);
    if (parts.length < n) {
      throw new BDFParseError(
        `${key} needs ${n} numbers, got ${JSON.stringify(value)}`,
        this.lineno
      );
    }
    return parts.slice(0, n).map((t) => this.int32(t, key, value));
  }
  /** one integer token of a required numeric field (signed 32-bit) */
  int32(t, key, value) {
    if (!RE_INT.test(t)) {
      throw new BDFParseError(
        `malformed number in ${key} ${JSON.stringify(value)}`,
        this.lineno
      );
    }
    const n = parseInt(t, 10);
    if (n < INT32_MIN || n > INT32_MAX) {
      throw new BDFParseError(
        `number ${t} in ${key} is out of the 32-bit range`,
        this.lineno
      );
    }
    return n;
  }
  endHeaders() {
    if (!("metricsset" in this.headers)) {
      this.headers.metricsset = 0;
    }
  }
  startGlyph(value) {
    this.meta = [value, ...Array(15).fill(null), []];
    this.used = /* @__PURE__ */ new Set();
    this.startline = this.lineno;
    this.altcode = null;
    this.nglyphs++;
  }
  finishGlyph() {
    const meta = this.meta;
    const name = meta[0];
    const font = this.font;
    if (!this.used.has("BBX")) {
      throw new BDFParseError(
        `glyph '${name}' (starting at line ${this.startline}) has no BBX`,
        this.lineno
      );
    }
    if (!this.used.has("ENCODING")) {
      warn(
        `line ${this.startline}: glyph '${name}' has no ENCODING, treated as unencoded`
      );
      meta[1] = -1;
    }
    if (meta[1] < 0) {
      if (meta[1] !== -1) {
        warn(
          `line ${this.startline}: glyph '${name}' has negative ENCODING ${meta[1]}, treated as unencoded`
        );
        meta[1] = -1;
      }
      font.unencoded.push({ altcode: this.altcode, meta });
      return;
    }
    const cp = meta[1];
    if (font.glyphs.has(cp)) {
      warn(
        `line ${this.startline}: duplicate codepoint ${cp} (glyph '${name}'), the later one wins`
      );
      font.glyphs.delete(cp);
    }
    font.glyphs.set(cp, meta);
  }
  missingEndchar() {
    warn(
      `line ${this.lineno}: missing ENDCHAR for glyph '${String(this.meta[0])}'`
    );
  }
  line(raw) {
    this.lineno++;
    if (this.state === 6) {
      return;
    }
    if (this.lineno === 1 && raw.charCodeAt(0) === 65279) {
      raw = raw.slice(1);
    }
    const line = wsTrim(raw);
    if (line === "") {
      return;
    }
    const sp = line.search(RE_WS);
    const key = sp === -1 ? line : line.slice(0, sp);
    const value = sp === -1 ? "" : wsTrim(line.slice(sp));
    const meta = this.meta;
    const font = this.font;
    const headers = this.headers;
    switch (this.state) {
      case 5:
        if (key === "ENDCHAR") {
          this.finishGlyph();
          this.state = 3;
        } else if (key === "STARTCHAR") {
          this.missingEndchar();
          this.finishGlyph();
          this.startGlyph(value);
          this.state = 4;
        } else if (key === "ENDFONT") {
          this.missingEndchar();
          this.finishGlyph();
          this.state = 6;
        } else if (key !== "COMMENT") {
          ;
          meta[16].push(line);
        }
        return;
      case 4:
        if (key === "ENCODING") {
          if (!this.used.has(key)) {
            const parts = value === "" ? [] : value.split(RE_WS_RUN);
            if (parts.length === 0) {
              throw new BDFParseError("ENCODING needs a number", this.lineno);
            }
            const nums = parts.slice(0, 2).map((t) => this.int32(t, key, value));
            meta[1] = nums[0];
            if (nums[0] < 0 && nums.length > 1) {
              this.altcode = nums[1];
            }
            this.used.add(key);
          }
        } else if (key === "BBX") {
          if (!this.used.has(key)) {
            const bbx = this.ints(value, 4, key);
            if (bbx[0] < 0 || bbx[1] < 0) {
              throw new BDFParseError(
                `glyph '${String(meta[0])}' has a negative BBX size ${bbx[0]} ${bbx[1]}`,
                this.lineno
              );
            }
            meta.splice(2, 4, ...bbx);
            this.used.add(key);
          }
        } else if (key in GLYPH_METRICS) {
          if (!this.used.has(key)) {
            const i = GLYPH_METRICS[key];
            meta.splice(
              i,
              2,
              ...this.ints(
                value,
                2,
                key,
                key === "VVECTOR" ? RE_VVECTOR_DELIMITER : void 0
              )
            );
            this.used.add(key);
          }
        } else if (key === "BITMAP") {
          this.state = 5;
        } else if (key === "ENDCHAR") {
          this.finishGlyph();
          this.state = 3;
        } else if (key === "STARTCHAR") {
          this.missingEndchar();
          this.finishGlyph();
          this.startGlyph(value);
        } else if (key === "ENDFONT") {
          this.missingEndchar();
          this.finishGlyph();
          this.state = 6;
        } else {
          warn(
            `line ${this.lineno}: unknown keyword '${key}' in glyph '${String(meta[0])}' ignored`
          );
        }
        return;
      case 3:
        if (key === "STARTCHAR") {
          this.startGlyph(value);
          this.state = 4;
        } else if (key === "ENDFONT") {
          this.state = 6;
        } else if (key === "CHARS" && this.chars === null) {
          this.chars = this.ints(value, 1, key)[0];
        } else {
          warn(`line ${this.lineno}: unexpected line '${line}' ignored`);
        }
        return;
      case 1:
        if (key === "ENDPROPERTIES") {
          if (this.propcount !== null && this.propcount !== this.propseen) {
            warn(
              `The property count next to 'STARTPROPERTIES' keyword is ${this.propcount}, which does not match the actual property count ${this.propseen}`
            );
          }
          this.state = 2;
        } else if (key === "COMMENT" || /^comment$/i.test(key)) {
          if (key !== "COMMENT") {
            warn(
              `line ${this.lineno}: property '${key}' treated as a COMMENT line`
            );
          }
          if (!Array.isArray(font.props.comment)) {
            font.props.comment = [];
          }
          font.props.comment.push(stripQuotePair(value));
        } else if (key === "CHARS" || key === "STARTCHAR" || key === "ENDFONT") {
          warn(`line ${this.lineno}: missing 'ENDPROPERTIES'`);
          if (key === "CHARS") {
            this.chars = this.ints(value, 1, key)[0];
            this.state = 3;
          } else if (key === "STARTCHAR") {
            warn("Cannot find 'CHARS' line");
            this.startGlyph(value);
            this.state = 4;
          } else {
            warn("This font does not have any glyphs");
            this.state = 6;
          }
        } else {
          const k = key.toLowerCase();
          this.propseen++;
          font.props[k] = value === "" ? null : this.propvalue(value);
          font._propnames.set(k, key);
        }
        return;
      case 2:
        if (key === "CHARS") {
          this.chars = this.ints(value, 1, key)[0];
          this.state = 3;
        } else if (key === "STARTCHAR") {
          warn("Cannot find 'CHARS' line next to 'ENDPROPERTIES' line");
          this.startGlyph(value);
          this.state = 4;
        } else if (key === "ENDFONT") {
          warn("This font does not have any glyphs");
          this.state = 6;
        } else {
          warn(`line ${this.lineno}: unexpected line '${line}' ignored`);
        }
        return;
    }
    if (key === "STARTFONT") {
      if (!RE_VERSION.test(value)) {
        throw new BDFParseError(
          `malformed version number in STARTFONT ${JSON.stringify(value)}`,
          this.lineno
        );
      }
      headers.bdfversion = Number(value);
    } else if (key === "FONT") {
      headers.fontname = value;
    } else if (key === "SIZE") {
      ;
      [headers.pointsize, headers.xres, headers.yres] = this.ints(
        value,
        3,
        key
      );
    } else if (key === "FONTBOUNDINGBOX") {
      const fbb = this.ints(value, 4, key);
      if (fbb[0] < 0 || fbb[1] < 0) {
        throw new BDFParseError(
          `negative FONTBOUNDINGBOX size ${fbb[0]} ${fbb[1]}`,
          this.lineno
        );
      }
      ;
      [headers.fbbx, headers.fbby, headers.fbbxoff, headers.fbbyoff] = fbb;
    } else if (key === "COMMENT") {
      if (!Array.isArray(headers.comment)) {
        headers.comment = [];
      }
      ;
      headers.comment.push(stripQuotePair(value));
    } else if (key === "METRICSSET" || key === "CONTENTVERSION") {
      headers[key.toLowerCase()] = this.ints(value, 1, key)[0];
    } else if (key in GLOBAL_METRICS) {
      const [k0, k1] = GLOBAL_METRICS[key];
      [headers[k0], headers[k1]] = this.ints(
        value,
        2,
        key,
        key === "VVECTOR" ? RE_VVECTOR_DELIMITER : void 0
      );
    } else if (key === "STARTPROPERTIES") {
      this.endHeaders();
      const first = value.split(RE_WS_RUN)[0];
      if (value === "") {
        this.propcount = null;
      } else if (RE_INT.test(first)) {
        this.propcount = parseInt(first, 10);
      } else {
        warn(
          `line ${this.lineno}: malformed property count ${JSON.stringify(value)}`
        );
      }
      this.state = 1;
    } else if (key === "CHARS") {
      warn(NO_PROPS_WARNING);
      this.endHeaders();
      this.chars = this.ints(value, 1, key)[0];
      this.state = 3;
    } else if (key === "STARTCHAR") {
      warn(NO_PROPS_WARNING);
      warn("Cannot find 'CHARS' line");
      this.endHeaders();
      this.startGlyph(value);
      this.state = 4;
    } else if (key === "ENDFONT") {
      warn(NO_PROPS_WARNING);
      warn("This font does not have any glyphs");
      this.endHeaders();
      this.state = 6;
    } else {
      warn(`line ${this.lineno}: unknown header keyword '${key}' ignored`);
    }
  }
  propvalue(value) {
    if (value[0] === '"') {
      let out = "";
      let i = 1;
      const n = value.length;
      while (i < n) {
        const c = value[i];
        if (c === '"') {
          if (i + 1 < n && value[i + 1] === '"') {
            out += '"';
            i += 2;
            continue;
          }
          return out;
        }
        out += c;
        i++;
      }
      warn(`line ${this.lineno}: property value has no closing quote`);
      return out;
    }
    if (RE_INT.test(value)) {
      const n = parseInt(value, 10);
      if (n >= INT32_MIN && n <= UINT32_MAX) {
        return n;
      }
    }
    return value;
  }
  finish() {
    if (this.state <= 1) {
      throw new BDFParseError(
        "Unexpected end of file before the end of the headers",
        this.lineno + 1
      );
    }
    if (this.state === 4 || this.state === 5) {
      warn(
        `Unexpected end of file: missing ENDCHAR for glyph '${String(this.meta[0])}'`
      );
      this.finishGlyph();
    }
    if (this.state !== 6) {
      warn("This font does not have 'ENDFONT' keyword");
    }
    if (this.state >= 3 && (this.chars !== null || this.nglyphs > 0)) {
      if (this.chars === null) {
        warn("The glyph count next to 'CHARS' keyword does not exist");
      } else if (this.chars !== this.nglyphs) {
        warn(
          `The glyph count next to 'CHARS' keyword is ${this.chars}, which does not match the actual glyph count ${this.nglyphs}`
        );
      }
    }
  }
};
var Font = class {
  /** Global headers (`bdfversion`, `fontname`, `pointsize`, ...), `{}` before loading */
  headers = {};
  /** Properties, keys in lower case; values `number`, `string` or `null`; `comment` → `string[]` */
  props = newProps();
  /** codepoint → 17-slot glyph list, file order */
  glyphs = /* @__PURE__ */ new Map();
  /** Glyphs with `ENCODING -1`, file order */
  unencoded = [];
  /** @internal lower-case property name → original spelling */
  _propnames = /* @__PURE__ */ new Map();
  __iconv;
  __charset = null;
  __char2cp = null;
  __cp2char = null;
  __codec = null;
  __warnedCharsets = /* @__PURE__ */ new Set();
  // -------------------------------------------------------------------------
  // Loading
  __reset() {
    this.headers = {};
    this.props = newProps();
    this.glyphs = /* @__PURE__ */ new Map();
    this.unencoded = [];
    this._propnames = /* @__PURE__ */ new Map();
    this.__codec = null;
  }
  /**
   * Load a BDF font from lines (async or sync iterable of strings, e.g. from
   * `readlineiter` / `fetchline` or an array of lines).
   *
   * @param filelines - Iterable of lines (line endings are tolerated)
   *
   * @returns The current `Font` object
   *
   * @throws BDFParseError on fatal parse errors
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/font#load_filelines}
   */
  async load_filelines(filelines) {
    this.__reset();
    const parser = new BdfParser(this);
    for await (const line of filelines) {
      parser.feed(line);
    }
    parser.finish();
    return this;
  }
  /**
   * Load a BDF font from its text.
   *
   * @param text - BDF file content (LF, CRLF or CR line endings)
   *
   * @returns The current `Font` object
   *
   * @throws BDFParseError on fatal parse errors
   */
  load_string(text) {
    this.__reset();
    const parser = new BdfParser(this);
    parser.feedText(text);
    parser.finish();
    return this;
  }
  /**
   * Load a font from bytes, auto-detecting the format: PCF (`\x01fcp`),
   * TrueType (`00 01 00 00` / `true`), else BDF text (UTF-8). Gzip-compressed
   * data must be decompressed first (or loaded with `load_url()` / `$Font()`
   * which do it asynchronously).
   *
   * @param data - File content
   * @param options.pixelsize - pixel size for TrueType fonts without a `BDFP` table
   *
   * @returns The current `Font` object
   */
  load_bytes(data, options = {}) {
    const b = toBytes(data);
    const magic = String.fromCharCode(...b.subarray(0, 4));
    if (magic === "fcp") {
      return this.__adopt(readPcf(b));
    }
    if (isGzip2(b)) {
      throw new Error(
        "gzip-compressed data cannot be loaded synchronously: decompress it first, or use load_url() / $Font()"
      );
    }
    if (magic === "\0\0\0" || magic === "true") {
      return this.__adopt(readTtf(b, { pixelsize: options.pixelsize }));
    }
    if (magic === "OTTO") {
      throw new Error("CFF-based OpenType is not supported");
    }
    return this.load_string(
      new TextDecoder("utf-8", { ignoreBOM: true }).decode(b)
    );
  }
  /**
   * Fetch and load a font (BDF, PCF, gzip-compressed PCF/BDF or TrueType)
   * with the global `fetch` (browsers, Node ≥ 18, Deno, Bun).
   *
   * @param url - URL of the font file
   * @param init - `fetch` options
   * @param options.pixelsize - pixel size for TrueType fonts without a `BDFP` table
   *
   * @returns Promise of the current `Font` object
   */
  async load_url(url, init, options = {}) {
    const href = typeof url === "string" ? url : url.href;
    const res = await fetch(href, init);
    if (!res.ok) {
      throw new Error(
        `Failed to fetch ${href}: ${res.status} ${res.statusText}`
      );
    }
    return this.load_bytes_async(
      new Uint8Array(await res.arrayBuffer()),
      options
    );
  }
  /**
   * Same as {@link Font.load_bytes} but also accepts gzip-compressed data
   * (decompressed with `DecompressionStream`).
   *
   * @param data - File content
   * @param options.pixelsize - pixel size for TrueType fonts without a `BDFP` table
   *
   * @returns Promise of the current `Font` object
   */
  async load_bytes_async(data, options = {}) {
    let b = toBytes(data);
    if (isGzip2(b)) {
      b = await gunzip(b);
    }
    return this.load_bytes(b, options);
  }
  __adopt(other) {
    this.headers = other.headers;
    this.props = other.props;
    this._propnames = other._propnames;
    this.glyphs = other.glyphs;
    this.unencoded = other.unencoded;
    this.__codec = null;
    return this;
  }
  /**
   * Create a new, empty font (SPEC-v3 §2.6).
   *
   * @param options - see {@link FontCreateOptions}
   *
   * @returns New `Font` object
   *
   * @example
   * const font = Font.create({ pixelsize: 8, familyname: 'Tiny' })
   * font.newglyph(0x41, Bitmap.fromstring('.##.\n#..#\n####\n#..#'))
   */
  static create(options = {}) {
    const pixelsize = options.pixelsize ?? 16;
    const descent = options.descent ?? Math.floor(pixelsize / 8);
    const ascent = options.ascent ?? pixelsize - descent;
    const familyname = options.familyname ?? "Untitled";
    const fontname = options.fontname ?? familyname;
    const font = newFont();
    font.headers = {
      bdfversion: 2.1,
      fontname,
      pointsize: pixelsize,
      xres: options.xres ?? 75,
      yres: options.yres ?? 75,
      fbbx: pixelsize,
      fbby: ascent + descent,
      fbbxoff: 0,
      fbbyoff: -descent,
      metricsset: 0
    };
    font.setprop("FAMILY_NAME", familyname).setprop("PIXEL_SIZE", pixelsize).setprop("FONT_ASCENT", ascent).setprop("FONT_DESCENT", descent).setprop("CHARSET_REGISTRY", "ISO10646").setprop("CHARSET_ENCODING", "1");
    return font;
  }
  // -------------------------------------------------------------------------
  // Encoding
  /**
   * Set encoding options: force a charset, pass an `iconv-lite` instance, or
   * define customized character ⇄ codepoint conversion functions.
   *
   * @param options - see {@link EncodingOptions}
   *
   * @returns The current `Font` object
   */
  encoding(options = {}) {
    if (options.iconv !== void 0) {
      this.__iconv = options.iconv;
    }
    if (options.charset !== void 0) {
      this.__charset = options.charset ? canonicalCharset(options.charset) : null;
    }
    if (options.char2cp !== void 0) {
      this.__char2cp = options.char2cp;
    }
    if (options.cp2char !== void 0) {
      this.__cp2char = options.cp2char;
    }
    this.__codec = null;
    return this;
  }
  /**
   * Resolved charset (canonical key, SPEC-v3 §4): the one forced by
   * `encoding({ charset })` if any, else derived from the `CHARSET_REGISTRY` /
   * `CHARSET_ENCODING` properties (`'iso10646'` if missing).
   */
  get charset() {
    return this.__charset ?? sanitizeCharset(
      this.props.charset_registry,
      this.props.charset_encoding
    );
  }
  /** Same as `encoding({ charset })` */
  set charset(value) {
    this.encoding({ charset: value });
  }
  __getcodec() {
    if (this.__codec === null) {
      const cs = this.charset;
      let codec = getCodec(cs, { iconv: this.__iconv });
      if (codec.gl94 && !codec.gl && detectGL(
        this.props.charset_encoding,
        this.glyphs.keys()
      )) {
        codec = getCodec(cs, { iconv: this.__iconv, gl: true });
      }
      if (!codec.known && !this.__warnedCharsets.has(cs)) {
        this.__warnedCharsets.add(cs);
        warn(
          `Unknown charset '${cs}', characters are mapped to codepoints as Unicode`
        );
      }
      this.__codec = codec;
    }
    return this.__codec;
  }
  /** @internal invalidate the cached charset converter */
  _invalidate() {
    this.__codec = null;
  }
  /**
   * Convert a character to a codepoint of this font's charset.
   *
   * @param char - Character (one code point)
   *
   * @returns Codepoint, or `null` if the character is not representable
   */
  char2cp(char) {
    if (this.__char2cp) {
      return this.__char2cp(char) ?? null;
    }
    return this.__getcodec().char2cp(char);
  }
  /**
   * Convert a codepoint of this font's charset to a character.
   *
   * @param cp - Codepoint
   *
   * @returns Character, or `null` if the codepoint is not representable
   */
  cp2char(cp) {
    if (this.__cp2char) {
      return this.__cp2char(cp) ?? null;
    }
    return this.__getcodec().cp2char(cp);
  }
  // -------------------------------------------------------------------------
  // Properties
  /**
   * Get a property (case-insensitive key).
   *
   * @param key - Property name
   *
   * @returns Value, or `null` if missing
   */
  getprop(key) {
    const k = key.toLowerCase();
    const v = Object.prototype.hasOwnProperty.call(this.props, k) ? this.props[k] : void 0;
    return v === void 0 ? null : v;
  }
  /**
   * Set a property (case-insensitive key). Remembers the given spelling of a
   * new key (used when writing).
   *
   * @param key - Property name
   * @param value - `number`, `string` or `null`
   *
   * @returns The current `Font` object
   */
  setprop(key, value) {
    const k = key.toLowerCase();
    if (!this._propnames.has(k) && k !== "comment") {
      this._propnames.set(k, key);
    }
    this.props[k] = value;
    this.__codec = null;
    return this;
  }
  /**
   * Delete a property (case-insensitive key), if present.
   *
   * @param key - Property name
   *
   * @returns The current `Font` object
   */
  delprop(key) {
    const k = key.toLowerCase();
    delete this.props[k];
    this._propnames.delete(k);
    this.__codec = null;
    return this;
  }
  /**
   * Compute SWIDTH (scalable width, 1/1000 em) from DWIDTH (pixels):
   * `round(dwx * 72000 / (pointsize * xres))`, or `round(dwx * 1000 / fbbx)`
   * if `pointsize` or `xres` is missing.
   *
   * @param dwx - DWIDTH x in pixels
   *
   * @returns SWIDTH x
   */
  swidth(dwx) {
    const pointsize = this.headers?.pointsize;
    const xres = this.headers?.xres;
    if (pointsize && xres) {
      return rnd3(dwx * 72e3 / (pointsize * xres));
    }
    return rnd3(dwx * 1e3 / Math.max(this.headers?.fbbx || 1, 1));
  }
  // -------------------------------------------------------------------------
  // Querying
  /**
   * How many (encoded) glyphs actually exist in the font.
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/font#length}
   */
  get length() {
    return this.glyphs.size;
  }
  /**
   * Similar to `.iterglyphs()`, except it returns an `array` of glyph codepoints instead of an `iterator` of `Glyph` objects.
   *
   * @param order - Order: 1 ascending codepoints (default), 0 file order, 2 descending, -1 reverse file order
   * @param r - Codepoint range: `n` (cp < n), `[a, b]` or `[[a, b], ...]`
   *
   * @returns An array of the codepoints of glyphs
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/font#itercps}
   */
  itercps(order, r) {
    const _order = order ?? 1;
    const _r = r ?? null;
    let ret;
    const ks = [...this.glyphs.keys()];
    switch (_order) {
      case 1:
        ret = ks.sort((a, b) => a - b);
        break;
      case 0:
        ret = ks;
        break;
      case 2:
        ret = ks.sort((a, b) => b - a);
        break;
      case -1:
        ret = ks.reverse();
        break;
      default:
        throw new Error(`Unknown order ${String(_order)}`);
    }
    return _r === null ? ret : ret.filter((cp) => cpInRange(cp, _r));
  }
  /**
   * Returns an iterator of all the glyphs (as attached `Glyph` objects) in the font (default) or in the specified codepoint range in the font, sorted by the specified order (or by the ascending codepoint order by default).
   *
   * @param order - Order
   * @param r - Codepoint range
   *
   * @returns An iterator of glyphs as `Glyph` objects
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/font#iterglyphs}
   */
  *iterglyphs(order, r) {
    for (const cp of this.itercps(order, r)) {
      yield this.glyphbycp(cp);
    }
  }
  __glyphfromlist(list) {
    const g = new Glyph(listToMeta(list), this);
    g._attach(list);
    return g;
  }
  /**
   * Get a glyph (as attached `Glyph` object) by its codepoint.
   *
   * @param codepoint - Codepoint
   *
   * @returns `Glyph` object, or `null` if the glyph does not exist in the font
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/font#glyphbycp}
   */
  glyphbycp(codepoint) {
    const list = this.glyphs.get(codepoint);
    return list === void 0 ? null : this.__glyphfromlist(list);
  }
  /**
   * Get a glyph (as attached `Glyph` object) by its character (converted
   * with the font's charset, see `char2cp`).
   *
   * @param character - Character
   *
   * @returns `Glyph` object, or `null` if the glyph does not exist in the font
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/font#glyph}
   */
  glyph(character) {
    const cp = this.char2cp(character);
    return cp === null ? null : this.glyphbycp(cp);
  }
  /**
   * Check if there is any missing glyph and gets these glyphs' character.
   *
   * @param str - string to check
   *
   * @returns List of missing glyph(s)' characters, or `null` if all the glyphs in your string exist in the font
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/font#lacksglyphs}
   */
  lacksglyphs(str) {
    const l = [];
    for (const c of str) {
      const cp = this.char2cp(c);
      if (cp === null || !this.glyphs.has(cp)) {
        l.push(c);
      }
    }
    return l.length !== 0 ? l : null;
  }
  /**
   * Draw the glyphs of the specified codepoints, to a `Bitmap` object.
   *
   * @param cps - Array of codepoints to draw
   * @param options.linelimit - Maximum pixels per line
   * @param options.mode - Mode
   * @param options.direction - Writing direction
   * @param options.usecurrentglyphspacing - Use current glyph spacing
   * @param options.missing - Missing glyph replacement
   *
   * @returns `Bitmap` object
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/font#drawcps}
   */
  drawcps(cps, options = {}) {
    const _linelimit = options.linelimit ?? 512;
    const _mode = options.mode ?? 1;
    const _direction = options.direction ?? "lrtb";
    const _usecurrentglyphspacing = options.usecurrentglyphspacing ?? false;
    const _missing = options.missing ?? null;
    if (this.headers.fbbx === void 0) {
      throw new Error("Font is not loaded");
    }
    let interglyph_global = null;
    let interglyph_str = "dwx0";
    let interglyph_str2 = "dwy0";
    let fbbsize = 0;
    const dire = DIRE_SHORTCUT_MAP[_direction] ?? _direction;
    const dire_glyph_str = dire.slice(0, 2);
    const dire_line_str = dire.slice(2, 4);
    let dire_glyph;
    let dire_line;
    if (dire_glyph_str in DIRE_MAP && dire_line_str in DIRE_MAP) {
      dire_glyph = DIRE_MAP[dire_glyph_str];
      dire_line = DIRE_MAP[dire_line_str];
    } else {
      dire_glyph = 1;
      dire_line = 0;
    }
    const align_glyph = dire_line === 0 || dire_line === 2 ? 1 : 0;
    const align_line = dire_glyph === 1 || dire_glyph === -1 ? 1 : 0;
    if (_mode === 1) {
      fbbsize = dire_glyph > 0 ? this.headers["fbbx"] : this.headers["fbby"];
      if (dire_glyph > 0) {
        interglyph_str = "dwx0";
        interglyph_str2 = "dwy0";
      } else {
        interglyph_str = "dwx1";
        interglyph_str2 = "dwy1";
      }
      if (interglyph_str in this.headers) {
        interglyph_global = this.headers[interglyph_str] ?? null;
      } else if (interglyph_str2 in this.headers) {
        interglyph_global = this.headers[interglyph_str2] ?? null;
      }
    }
    const list_of_bitmaplist = [];
    let bitmaplist = [];
    const list_of_offsetlist = [];
    let offsetlist = [];
    let size = 0;
    const append_bitmaplist_and_offsetlist = () => {
      list_of_bitmaplist.push(bitmaplist);
      if (_usecurrentglyphspacing) {
        offsetlist.shift();
      } else {
        offsetlist.pop();
      }
      list_of_offsetlist.push(offsetlist);
    };
    for (let i = 0; i < cps.length; ) {
      const cp = cps[i];
      let glyph = this.glyphbycp(cp);
      if (glyph === null) {
        if (_missing) {
          glyph = _missing instanceof Glyph ? _missing : new Glyph(_missing, this);
        } else {
          glyph = new Glyph(EMPTY_GLYPH, this);
        }
      }
      const bitmap = glyph.draw();
      const w = bitmap.width();
      let offset = 0;
      if (_mode === 1) {
        let interglyph = glyph.meta[interglyph_str] || glyph.meta[interglyph_str2];
        if (interglyph === void 0 || interglyph === null) {
          interglyph = interglyph_global;
        }
        if (interglyph !== null) {
          offset = interglyph - fbbsize;
        }
      }
      size += w + offset;
      if (size <= _linelimit) {
        bitmaplist.push(bitmap);
        offsetlist.push(offset);
        i++;
      } else {
        if (bitmaplist.length === 0) {
          throw new Error(
            `\`linelimit\` (${_linelimit}) is too small the line can't even contain one glyph: "${String(glyph.chr())}" (codepoint ${cp}, width: ${w})`
          );
        }
        append_bitmaplist_and_offsetlist();
        size = 0;
        bitmaplist = [];
        offsetlist = [];
      }
    }
    if (bitmaplist.length !== 0) {
      append_bitmaplist_and_offsetlist();
    }
    const list_of_bitmap_line_lists = list_of_bitmaplist.map(
      (bl, i) => Bitmap.concatall(bl, {
        direction: dire_glyph,
        align: align_glyph,
        offsetlist: list_of_offsetlist[i]
      })
    );
    return Bitmap.concatall(list_of_bitmap_line_lists, {
      direction: dire_line,
      align: align_line
    });
  }
  /**
   * Draw (render) the glyphs of the specified words / setences / paragraphs (as a `string`), to a `Bitmap` object.
   *
   * @param str - String to draw
   * @param options.linelimit - Maximum pixels per line
   * @param options.mode - Mode
   * @param options.direction - Writing direction
   * @param options.usecurrentglyphspacing - Use current glyph spacing
   * @param options.missing - Missing glyph replacement
   *
   * @returns `Bitmap` object
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/font#draw}
   */
  draw(str, options = {}) {
    return this.drawcps(
      Array.from(str, (c) => this.char2cp(c) ?? -1),
      options
    );
  }
  /**
   * Draw all the glyphs in the font (default) or in the specified codepoint range in the font, sorted by the specified order (or by the ascending codepoint order by default), to a `Bitmap` object.
   *
   * @param options.order - Order
   * @param options.r - Codepoint range
   * @param options.linelimit - Maximum pixels per line
   * @param options.mode - Mode
   * @param options.direction - Writing direction
   * @param options.usecurrentglyphspacing - Use current glyph spacing
   *
   * @returns `Bitmap` object
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/font#drawall}
   */
  drawall(options = {}) {
    const { order, r, linelimit, mode, direction, usecurrentglyphspacing } = options;
    return this.drawcps(this.itercps(order, r), {
      linelimit,
      mode: mode ?? 0,
      direction,
      usecurrentglyphspacing
    });
  }
  // -------------------------------------------------------------------------
  // Editing
  /**
   * @internal Write an attached glyph's meta back into the font (moving it if
   * its codepoint changed). Detaches the glyph if its slot no longer exists.
   */
  _writeback(glyph) {
    const store = glyph._store;
    if (store === null) {
      return;
    }
    const oldcp = store[1];
    let uidx = -1;
    if (oldcp < 0) {
      uidx = this.unencoded.findIndex((e) => e.meta === store);
      if (uidx === -1) {
        glyph._detach();
        return;
      }
    } else if (this.glyphs.get(oldcp) !== store) {
      glyph._detach();
      return;
    }
    const values = metaToList(glyph.meta);
    const synced = glyph._synced;
    if (synced !== null) {
      for (let i = 0; i < 17; i++) {
        if (slotEquals(values[i], synced[i]) && !slotEquals(store[i], synced[i])) {
          values[i] = store[i];
        }
      }
    }
    values[16] = Array.isArray(values[16]) ? [...values[16]] : [];
    if (values[1] === null || values[1] === void 0) {
      values[1] = -1;
    } else if (!Number.isInteger(values[1])) {
      throw new TypeError(
        `Glyph codepoint must be an integer, not ${String(values[1])}`
      );
    } else if (values[1] < 0) {
      values[1] = -1;
    }
    for (let i = 0; i < 17; i++) {
      ;
      store[i] = values[i];
    }
    const newcp = store[1];
    Object.assign(glyph.meta, listToMeta(store), { hexdata: [...store[16]] });
    glyph._setsynced(store);
    if (oldcp >= 0 ? newcp !== oldcp : newcp >= 0) {
      if (oldcp < 0) {
        this.unencoded.splice(uidx, 1);
      } else {
        this.glyphs.delete(oldcp);
      }
      if (newcp < 0) {
        this.unencoded.push({ altcode: null, meta: store });
      } else {
        this.glyphs.set(newcp, store);
      }
    }
    this.__codec = null;
  }
  __defaultname(cp) {
    return cp >= 0 ? defaultglyphname(cp, isUnicodeCharset(this.charset)) : `char${cp}`;
  }
  /**
   * Add a glyph to the font (and attach it: the `Glyph` object now writes its
   * edits back to this font).
   *
   * If its codepoint already exists, the existing glyph is replaced (in
   * place) when `replace` is `true` (default), else kept (with a warning).
   * Codepoint `-1` appends the glyph to `unencoded`.
   *
   * @param glyph - `Glyph` object or meta object
   * @param replace - Replace an existing glyph with the same codepoint, default `true`
   *
   * @returns The current `Font` object
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/font#addglyph}
   */
  addglyph(glyph, replace = true) {
    const _replace = typeof replace === "object" ? replace.replace ?? true : replace;
    const isGlyph = glyph instanceof Glyph;
    const meta = isGlyph ? glyph.meta : glyph;
    for (const k of Object.keys(meta)) {
      if (!META_TITLES.includes(k)) {
        throw new Error(`Unknown glyph meta key "${k}"`);
      }
    }
    const cp = meta.codepoint;
    if (typeof cp !== "number" || !Number.isInteger(cp)) {
      throw new Error("The glyph has no codepoint");
    }
    const list = metaToList({
      glyphname: meta.glyphname ?? this.__defaultname(cp),
      codepoint: cp < 0 ? -1 : cp,
      bbw: meta.bbw ?? 0,
      bbh: meta.bbh ?? 0,
      bbxoff: meta.bbxoff ?? 0,
      bbyoff: meta.bbyoff ?? 0,
      swx0: meta.swx0 ?? null,
      swy0: meta.swy0 ?? null,
      dwx0: meta.dwx0 ?? null,
      dwy0: meta.dwy0 ?? null,
      swx1: meta.swx1 ?? null,
      swy1: meta.swy1 ?? null,
      dwx1: meta.dwx1 ?? null,
      dwy1: meta.dwy1 ?? null,
      vvectorx: meta.vvectorx ?? null,
      vvectory: meta.vvectory ?? null,
      hexdata: [...meta.hexdata ?? []]
    });
    if (cp < 0) {
      this.unencoded.push({ altcode: null, meta: list });
    } else {
      if (this.glyphs.has(cp) && !_replace) {
        warn(`Glyph with codepoint ${cp} already exists, not replaced`);
        return this;
      }
      this.glyphs.set(cp, list);
    }
    if (isGlyph) {
      glyph.font = this;
      glyph.meta = listToMeta(list);
      glyph._attach(list);
    }
    this.__codec = null;
    return this;
  }
  /**
   * Remove a glyph from the font (no-op if missing). A `Glyph` object attached
   * to this font is removed from its slot (works for unencoded glyphs too)
   * and detached.
   *
   * @param cpOrGlyph - Codepoint or `Glyph` object of the glyph to remove
   *
   * @returns The current `Font` object
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/font#removeglyph}
   */
  removeglyph(cpOrGlyph) {
    if (typeof cpOrGlyph === "number") {
      this.glyphs.delete(cpOrGlyph);
    } else {
      const store = cpOrGlyph._slot;
      if (store !== null && cpOrGlyph.font === this) {
        if (store[1] < 0) {
          const i = this.unencoded.findIndex((e) => e.meta === store);
          if (i !== -1) {
            this.unencoded.splice(i, 1);
          }
        } else if (this.glyphs.get(store[1]) === store) {
          this.glyphs.delete(store[1]);
        }
      } else if (cpOrGlyph.cp() >= 0) {
        this.glyphs.delete(cpOrGlyph.cp());
      }
      cpOrGlyph._detach();
    }
    this.__codec = null;
    return this;
  }
  /**
   * Create a new glyph in the font (replacing any existing glyph with the same
   * codepoint) and return it (attached).
   *
   * Without bitmap: empty glyph (`BBX 0 0 0 0`) with `DWIDTH` = `dwidth` or
   * the font bounding box width. With bitmap: `DWIDTH` = `dwidth` or the
   * bitmap width, then `setbitmap(bitmap, mode)`. `SWIDTH` is computed with
   * `swidth()`.
   *
   * @param cp - Codepoint (`-1` for an unencoded glyph)
   * @param bitmap - Bitmap, or an options object `{bitmap, mode, name, dwidth}`
   * @param options - see {@link NewglyphOptions}
   *
   * @returns The new `Glyph` object
   *
   * @example
   * font.newglyph(0x41, Bitmap.fromstring('.#.\n#.#\n###\n#.#'), { mode: 1, dwidth: 4 })
   */
  newglyph(cp, bitmap, options = {}) {
    let opts;
    if (bitmap instanceof Bitmap || bitmap === null || bitmap === void 0) {
      opts = { ...options, bitmap: bitmap ?? options.bitmap ?? null };
    } else {
      opts = { ...bitmap, ...options };
    }
    const bm = opts.bitmap ?? null;
    const name = opts.name ?? this.__defaultname(cp);
    const dwx0 = opts.dwidth ?? (bm !== null ? bm.width() : this.headers.fbbx ?? 0);
    const meta = {
      glyphname: name,
      codepoint: cp < 0 ? -1 : cp,
      bbw: 0,
      bbh: 0,
      bbxoff: 0,
      bbyoff: 0,
      swx0: this.swidth(dwx0),
      swy0: 0,
      dwx0,
      dwy0: 0,
      swx1: null,
      swy1: null,
      dwx1: null,
      dwy1: null,
      vvectorx: null,
      vvectory: null,
      hexdata: []
    };
    const g = new Glyph(meta, this);
    this.addglyph(g);
    if (bm !== null) {
      g.setbitmap(bm, opts.mode ?? 0);
    }
    return g;
  }
  /**
   * Recompute FONTBOUNDINGBOX as the union of all glyph boxes (encoded and
   * unencoded glyphs with `bbw > 0` and `bbh > 0`). Unchanged if there are
   * none.
   *
   * @returns The current `Font` object
   */
  updatebbox() {
    let x0 = Infinity;
    let y0 = Infinity;
    let x1 = -Infinity;
    let y1 = -Infinity;
    const lists = [
      ...this.glyphs.values(),
      ...this.unencoded.map((u) => u.meta)
    ];
    for (const l of lists) {
      const [bbw, bbh, bbxoff, bbyoff] = [l[2], l[3], l[4], l[5]];
      if (bbw > 0 && bbh > 0) {
        x0 = Math.min(x0, bbxoff);
        y0 = Math.min(y0, bbyoff);
        x1 = Math.max(x1, bbxoff + bbw);
        y1 = Math.max(y1, bbyoff + bbh);
      }
    }
    if (x0 !== Infinity) {
      this.headers.fbbx = x1 - x0;
      this.headers.fbby = y1 - y0;
      this.headers.fbbxoff = x0;
      this.headers.fbbyoff = y0;
    }
    return this;
  }
  __copyinto(font, withGlyphs) {
    const headers = { ...this.headers };
    if (Array.isArray(headers.comment)) {
      headers.comment = [...headers.comment];
    }
    font.headers = headers;
    font.props = copyProps(this.props);
    font._propnames = new Map(this._propnames);
    font.__iconv = this.__iconv;
    font.__charset = this.__charset;
    font.__char2cp = this.__char2cp;
    font.__cp2char = this.__cp2char;
    if (withGlyphs) {
      for (const [cp, list] of this.glyphs) {
        font.glyphs.set(cp, cloneList(list));
      }
      font.unencoded = this.unencoded.map((u) => ({
        altcode: u.altcode,
        meta: cloneList(u.meta)
      }));
    }
    return font;
  }
  /**
   * Deep copy of the font (headers, properties, glyphs, unencoded glyphs,
   * encoding options).
   *
   * @returns New `Font` object
   */
  clone() {
    return this.__copyinto(newFont(), true);
  }
  /**
   * New font (deep copy) keeping only the glyphs whose codepoint passes the
   * range filter `r` (same as `itercps`); unencoded glyphs are dropped.
   *
   * @param r - Codepoint range: `n` (cp < n), `[a, b]` or `[[a, b], ...]`
   *
   * @returns New `Font` object
   *
   * @example
   * const ascii = font.subset([0x20, 0x7e])
   */
  subset(r) {
    const font = this.__copyinto(newFont(), false);
    for (const [cp, list] of this.glyphs) {
      if (cpInRange(cp, r)) {
        font.glyphs.set(cp, cloneList(list));
      }
    }
    return font;
  }
  /**
   * Copy (deep) the (encoded) glyphs of another font into this one; existing
   * codepoints are kept unless `replace`.
   *
   * @param other - Other font
   * @param replace - Replace existing glyphs, default `false`
   *
   * @returns The current `Font` object
   */
  merge(other, replace = false) {
    for (const [cp, list] of other.glyphs) {
      if (replace || !this.glyphs.has(cp)) {
        this.glyphs.set(cp, cloneList(list));
      }
    }
    this.__codec = null;
    return this;
  }
  /**
   * Transform glyph bitmaps: `glyph.transform(fn, mode)` for every glyph
   * passing the range filter `r` (all glyphs, including unencoded ones, if
   * `r` is not given).
   *
   * @param fn - Bitmap transformation, e.g. `(b) => b.bold()`
   * @param r - Codepoint range
   * @param mode - Draw / placement mode, default 0
   *
   * @returns The current `Font` object
   *
   * @example
   * font.transform((b) => b.italic(), [0x41, 0x5a])
   */
  transform(fn, r = null, mode = 0) {
    for (const cp of this.itercps(0, r)) {
      this.__glyphfromlist(this.glyphs.get(cp)).transform(
        fn,
        mode
      );
    }
    if (r === null) {
      for (const u of [...this.unencoded]) {
        this.__glyphfromlist(u.meta).transform(fn, mode);
      }
    }
    return this;
  }
  /**
   * Re-encode every glyph codepoint from the current charset to `newcharset`
   * (glyphs not representable in the new charset are dropped, with one
   * summary warning), set the `CHARSET_REGISTRY` / `CHARSET_ENCODING`
   * properties accordingly (94×94 sets use the X11 GL form, encoding `"0"`)
   * and clear any `encoding()` override (except `iconv`).
   *
   * @param newcharset - New charset name, e.g. `'gb2312'`, `'iso8859-2'`, `'big5'`, `'iso10646'`
   *
   * @returns The current `Font` object
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/font#charsetconvert}
   */
  charsetconvert(newcharset) {
    const key = canonicalCharset(newcharset);
    const [registry, enc] = charsetProps(key);
    const codec = getCodec(key, { iconv: this.__iconv, gl: true });
    if (!codec.known) {
      warn(
        `Unknown charset '${key}', characters are mapped to codepoints as Unicode`
      );
    }
    const newGlyphs = /* @__PURE__ */ new Map();
    let dropped = 0;
    for (const [cp, list] of this.glyphs) {
      const ch = this.cp2char(cp);
      const ncp = _isOneChar(ch) ? codec.char2cp(ch) : null;
      if (ncp === null) {
        dropped++;
        continue;
      }
      if (newGlyphs.has(ncp)) {
        dropped++;
        newGlyphs.delete(ncp);
      }
      list[1] = ncp;
      newGlyphs.set(ncp, list);
    }
    if (dropped > 0) {
      warn(
        `${dropped} glyph(s) could not be converted to the charset '${key}' and were dropped`
      );
    }
    this.glyphs = newGlyphs;
    this.__charset = null;
    this.__char2cp = null;
    this.__cp2char = null;
    this.setprop("CHARSET_REGISTRY", registry);
    this.setprop("CHARSET_ENCODING", enc);
    return this;
  }
  // -------------------------------------------------------------------------
  // Output
  /**
   * Convert the font to BDF text (SPEC-v3 §5). Reproduces FontForge-written
   * files byte for byte.
   *
   * @returns BDF string (ends with `ENDFONT\n`)
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/font#tobdf}
   **/
  tobdf() {
    const h = this.headers;
    const missing = REQUIRED_HEADERS.filter(
      (k) => h[k] === void 0 || h[k] === null
    );
    if (missing.length > 0) {
      throw new Error(
        `Cannot write BDF: missing header(s) ${missing.join(", ")} (font not loaded?)`
      );
    }
    const lines = [];
    const both = (kw, a, b) => {
      if (a !== null && a !== void 0 && b !== null && b !== void 0) {
        lines.push(`${kw} ${String(a)} ${String(b)}`);
      }
    };
    lines.push(`STARTFONT ${fmtver2(h.bdfversion ?? 2.1)}`);
    lines.push(`FONT ${h.fontname ?? ""}`);
    lines.push(`SIZE ${h.pointsize} ${h.xres} ${h.yres}`);
    lines.push(`FONTBOUNDINGBOX ${h.fbbx} ${h.fbby} ${h.fbbxoff} ${h.fbbyoff}`);
    if (h.metricsset !== void 0 && h.metricsset !== null && h.metricsset !== 0) {
      lines.push(`METRICSSET ${h.metricsset}`);
    }
    if (h.contentversion !== void 0 && h.contentversion !== null) {
      lines.push(`CONTENTVERSION ${h.contentversion}`);
    }
    both("SWIDTH", h.swx0, h.swy0);
    both("DWIDTH", h.dwx0, h.dwy0);
    both("SWIDTH1", h.swx1, h.swy1);
    both("DWIDTH1", h.dwx1, h.dwy1);
    both("VVECTOR", h.vvectorx, h.vvectory);
    for (const c of h.comment || []) {
      lines.push(`COMMENT "${c}"`);
    }
    const propkeys = propKeys(this.props, this._propnames);
    const pc = this.props.comment;
    const propcomments = pc ? [...pc] : [];
    if (propkeys.length > 0 || propcomments.length > 0) {
      lines.push(`STARTPROPERTIES ${propkeys.length}`);
      for (const c of propcomments) {
        lines.push(`COMMENT "${c}"`);
      }
      for (const k of propkeys) {
        const name = this._propnames.get(k) ?? k.toUpperCase();
        const v = this.props[k];
        if (v === null || v === void 0) {
          lines.push(name);
        } else if (typeof v === "number") {
          lines.push(`${name} ${fmtnum(v)}`);
        } else {
          lines.push(`${name} "${String(v).replace(/"/g, '""')}"`);
        }
      }
      lines.push("ENDPROPERTIES");
    }
    lines.push(`CHARS ${this.glyphs.size + this.unencoded.length}`);
    const glyph = (g, encoding) => {
      lines.push(`STARTCHAR ${g[0]}`);
      lines.push(`ENCODING ${encoding}`);
      both("SWIDTH", g[6], g[7]);
      both("DWIDTH", g[8], g[9]);
      both("SWIDTH1", g[10], g[11]);
      both("DWIDTH1", g[12], g[13]);
      both("VVECTOR", g[14], g[15]);
      lines.push(`BBX ${g[2]} ${g[3]} ${g[4]} ${g[5]}`);
      lines.push("BITMAP");
      for (const row of g[16]) {
        lines.push(row);
      }
      lines.push("ENDCHAR");
    };
    for (const [cp, g] of this.glyphs) {
      glyph(g, String(cp));
    }
    for (const u of this.unencoded) {
      glyph(u.meta, u.altcode === null ? "-1" : `-1 ${u.altcode}`);
    }
    lines.push("ENDFONT");
    return lines.join("\n") + "\n";
  }
  /**
   * Convert the font to PCF (SPEC-v3 §6), byte-identical to `bdftopcf` with
   * default options.
   *
   * @param options - PCF writer options (`byteorder`, `bitorder`, `glyphpad`, `scanunit`)
   *
   * @returns PCF file content
   */
  topcf(options) {
    return writePcf(this, options);
  }
  /**
   * Convert the font to a pixel TrueType font (SPEC-v3 §8), with square or
   * round dots.
   *
   * @param options - TTF writer options (`shape`, `dotsize`, `ppu`, `metadata`, `timestamp`)
   *
   * @returns TTF file content
   */
  tottf(options) {
    return writeTtf(this, options);
  }
  /**
   * Convert the BDF font to SVG font string
   *
   * @param options - see {@link SvgFontOptions}
   *
   * @returns SVG font string
   *
   * @see online docs: {@link https://font.tomchen.org/bdfparser_js/font#tosvgfont}
   */
  tosvgfont(options = {}) {
    const xPathOffset = options.pathOffsets?.x ?? 0;
    const yPathOffset = options.pathOffsets?.y ?? 0;
    const unicodeAttrControlCharNoSkip = options.unicodeAttr?.controlCharNoSkip ?? false;
    const unicodeAttrFormat = options.unicodeAttr?.format ?? "hexncr";
    const XML_ESC = {
      "<": "&lt;",
      ">": "&gt;",
      "&": "&amp;",
      '"': "&quot;",
      "'": "&apos;"
    };
    const toXmlValue = (value) => (typeof value === "string" ? value : fmtnum(value)).replace(
      /[<>&"']/g,
      (char) => XML_ESC[char]
    );
    const intprop = (v) => {
      if (v === null || v === void 0) {
        return 0;
      }
      if (typeof v === "number" && Number.isInteger(v)) {
        return v;
      }
      const m = pyLeadingInt(String(v));
      if (m === null) {
        return 0;
      }
      const n = BigInt(m);
      return n >= Number.MIN_SAFE_INTEGER && n <= Number.MAX_SAFE_INTEGER ? Number(n) : n;
    };
    const half = (v) => Number(v) * 0.5;
    const props = this.props;
    const headers = this.headers;
    const unitsPerEm = Math.max(headers.fbbx ?? 0, headers.fbby ?? 0) || 100;
    const fontAscent = intprop(props.font_ascent) || unitsPerEm * 0.8;
    const fontDescent = intprop(props.font_descent) || -unitsPerEm * 0.2;
    let svg = '<svg xmlns="http://www.w3.org/2000/svg" version="1.1">\n';
    const metadataLines = [];
    if (props.family_name || props.family) {
      metadataLines.push(`Title: ${String(props.family_name || props.family)}`);
    }
    if (props.weight_name) {
      metadataLines.push(`Weight: ${String(props.weight_name)}`);
    }
    if (props.font_version) {
      metadataLines.push(`Version: ${String(props.font_version)}`);
    }
    if (props.foundry) {
      metadataLines.push(`Foundry: ${String(props.foundry)}`);
    }
    if (props.copyright) {
      metadataLines.push(`Copyright: ${String(props.copyright)}`);
    }
    if (props.notice) {
      metadataLines.push(`Notice: ${String(props.notice)}`);
    }
    if (metadataLines.length > 0) {
      svg += "<metadata>\n  " + toXmlValue(metadataLines.join("\n  ")) + "\n</metadata>\n";
    }
    const unicodeOf = (cp) => {
      const ch = this.cp2char(cp);
      if (typeof ch !== "string") {
        return null;
      }
      const u = ch.codePointAt(0);
      if (u === void 0 || ch.length !== (u > 65535 ? 2 : 1) || u >= 55296 && u <= 57343) {
        return null;
      }
      return u;
    };
    const hex4 = (n) => n.toString(16).toUpperCase().padStart(4, "0");
    const unis = /* @__PURE__ */ new Set();
    for (const cp of this.glyphs.keys()) {
      const u = unicodeOf(cp);
      if (u !== null) {
        unis.add(u);
      }
    }
    const cps = [...unis].sort((a, b) => a - b);
    const ranges = [];
    if (cps.length > 0) {
      let rangeStart = cps[0];
      let prev = rangeStart;
      for (let i = 1; i <= cps.length; i++) {
        const current = cps[i];
        if (current !== prev + 1) {
          ranges.push(
            rangeStart === prev ? `U+${hex4(rangeStart)}` : `U+${hex4(rangeStart)}-${hex4(prev)}`
          );
          rangeStart = current;
        }
        prev = current;
      }
    }
    const defaultAdv = headers.dwx0 || unitsPerEm;
    svg += `<defs>
  <font id="${toXmlValue(
      (headers.fontname || "").replace(/^-/, "").toLowerCase()
    )}" horiz-adv-x="${defaultAdv}">`;
    const fontFaceAttributes = {
      "font-family": String(
        props.family_name || props.family || headers.fontname || ""
      ),
      "font-weight": String(props.weight_name || "normal"),
      "font-style": String(props.slant || "normal"),
      "units-per-em": unitsPerEm,
      "cap-height": intprop(props.cap_height) || fontAscent,
      "x-height": intprop(props.x_height) || half(fontAscent),
      ascent: fontAscent,
      descent: fontDescent,
      bbox: `${headers.fbbxoff || 0} ${headers.fbbyoff || 0} ${headers.fbbx || unitsPerEm} ${headers.fbby || unitsPerEm}`,
      "underline-thickness": intprop(props.underline_thickness) || rnd3(unitsPerEm * 0.05),
      "underline-position": intprop(props.underline_position) || rnd3(-unitsPerEm * 0.075),
      "unicode-range": ranges.join(", ")
    };
    svg += "\n<font-face\n";
    for (const [key, value] of Object.entries(fontFaceAttributes)) {
      svg += `  ${key}="${toXmlValue(value)}"
`;
    }
    svg += "></font-face>\n";
    const notdef = `M0,0h${unitsPerEm}v${unitsPerEm}h-${unitsPerEm}z`;
    svg += `<missing-glyph horiz-adv-x="${defaultAdv}" d="${notdef}" />
<glyph glyph-name=".notdef" horiz-adv-x="${defaultAdv}" d="${notdef}" />
`;
    for (const glyph of this.iterglyphs()) {
      const glyphPath = glyph.draw().tosvg(1, "pathOnly", true, {
        x: xPathOffset,
        y: yPathOffset
      });
      if (!glyphPath) {
        continue;
      }
      const u = unicodeOf(glyph.meta.codepoint);
      const glyphAttributes = {
        "glyph-name": glyph.meta.glyphname
      };
      if (u !== null && (unicodeAttrControlCharNoSkip || u >= 32)) {
        glyphAttributes.unicode = unicodeAttrFormat === "decncr" ? `&#${u};` : unicodeAttrFormat === "char" ? toXmlValue(String.fromCodePoint(u)) : `&#x${u.toString(16)};`;
      }
      glyphAttributes["horiz-adv-x"] = glyph.meta.dwx0 || defaultAdv;
      glyphAttributes.d = glyphPath;
      if (glyph.meta.swy0) {
        glyphAttributes["vert-adv-y"] = glyph.meta.swy0;
      }
      if (glyph.meta.vvectorx) {
        glyphAttributes["vert-origin-x"] = glyph.meta.vvectorx;
      }
      if (glyph.meta.vvectory) {
        glyphAttributes["vert-origin-y"] = glyph.meta.vvectory;
      }
      svg += "<glyph\n";
      for (const [key, value] of Object.entries(glyphAttributes)) {
        svg += `  ${key}="${key === "unicode" ? value : toXmlValue(value)}"
`;
      }
      svg += "></glyph>\n";
    }
    svg += "</font>\n</defs>\n</svg>";
    return svg;
  }
};
var newFont = () => new Font();

// fontpixel-recovery-baseline-20261004T1837/fontpixel-rs-phase6-handoff/local-work/phase6-performance/reference/bdfparser-js/src/shortcuts.ts
var isBinary = (s) => ArrayBuffer.isView(s) || Object.prototype.toString.call(s) === "[object ArrayBuffer]";
var isURL = (s) => typeof URL !== "undefined" && (s instanceof URL || Object.prototype.toString.call(s) === "[object URL]") || typeof s === "object" && s !== null && typeof s.href === "string" && !(Symbol.iterator in s) && !(Symbol.asyncIterator in s);
var $Font = async (source, encodingOptions = {}, loadOptions = {}) => {
  const font = new Font().encoding(encodingOptions);
  if (typeof source === "string") {
    font.load_string(source);
  } else if (isBinary(source)) {
    await font.load_bytes_async(source, loadOptions);
  } else if (isURL(source)) {
    await font.load_url(source, void 0, loadOptions);
  } else {
    await font.load_filelines(source);
  }
  return font;
};
var $Glyph = (meta_obj, font) => {
  return new Glyph(meta_obj, font);
};
var $Bitmap = (bin_bitmap_list) => {
  return new Bitmap(bin_bitmap_list);
};
export {
  $Bitmap,
  $Font,
  $Glyph,
  BDFParseError,
  Bitmap,
  DIRE_MAP,
  DIRE_SHORTCUT_MAP,
  EMPTY_GLYPH,
  Font,
  Glyph,
  META_TITLES,
  PATTERN_VVECTOR_DELIMITER,
  VERSION,
  bitmapContours,
  canonicalCharset,
  char2cp,
  charsetKeys,
  charsetProps,
  cp2char,
  defaultWarningHandler,
  defaultglyphname,
  detectGL,
  fmtnum,
  getCodec,
  isUnicodeCharset,
  rasterize,
  readPcf,
  readPcfAsync,
  readTtf,
  registerCharsetTables,
  sanitizeCharset,
  sanitizeCharsetName,
  setWarningHandler,
  warn,
  writePcf,
  writeTtf
};
