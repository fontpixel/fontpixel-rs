"""Read-only replay of frozen pre-fix detector review artifacts."""
from pathlib import Path
import hashlib, json, re, subprocess, sys
ROOT = Path(__file__).resolve().parent
BEFORE = ROOT.with_name('w5-detector-review')
CLI, PROBE = map(Path, sys.argv[1:3])
def digest(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def result(text):
    if 'Ok(Detected' in text:
        return {'id': re.search(r'id: "([^"]+)"', text)[1], 'confidence': re.search(r'confidence: (\w+)', text)[1]}
    if 'AmbiguousFormat' in text:
        return {'ambiguous': re.findall(r'"([^"]+)"', text)}
    return {'error':text}
def run(cmd):
    p = subprocess.run(list(map(str,cmd)), capture_output=True, text=True, timeout=60)
    return {'argv':list(map(str,cmd)), 'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
source = json.loads((BEFORE/'matrix.json').read_text())
for case in source: assert digest(case['path']) == case['sha256'], case['path']
r=run([PROBE, *[c['path'] for c in source]])
assert r['exit']==0, r
(ROOT/'probe-command.json').write_text(json.dumps({k:v for k,v in r.items() if k!='stdout'},indent=2))
(ROOT/'probe-output.jsonl').write_text(r['stdout'])
assert len(r['stdout'].splitlines())==len(source)
matrix=[];changed=[]
for before,line in zip(source,r['stdout'].splitlines()):
    after=json.loads(line)
    after.update(expected=before['expected'],canonical=before['canonical'],sha256=before['sha256'],before_detection=before['detection'])
    after['before_result']=result(before['detection']);after['after_result']=result(after['detection'])
    matrix.append(after)
    if after['before_result']!=after['after_result']:changed.append(after)
(ROOT/'matrix.json').write_text(json.dumps(matrix,indent=2))
(ROOT/'changes.json').write_text(json.dumps(changed,indent=2))
# Reuse the exact previous native/automatic read commands, with the freshly built CLI.
commands=[]
def replay(old,group):
    new=run([CLI,*old['argv'][1:]])
    new.update(group=group,before_exit=old['exit'])
    if old.get('expected'):new['expected']=old['expected']
    try:
        parsed=json.loads(new['stdout']);new['summary']={'format':parsed['format'],'fonts':parsed['font_count'],'glyphs':[f['glyph_count'] for f in parsed['fonts']]}
    except (ValueError,KeyError):new['summary']={'stderr':new['stderr']}
    commands.append(new)
for old in json.loads((BEFORE/'validation.json').read_text()):replay(old,'native-read')
for old in json.loads((BEFORE/'text-native.json').read_text()):replay(old,'text-magic')
for old in json.loads((BEFORE/'fontx2-riscos.json').read_text()):replay(old,'fontx2-riscos')
for case in json.loads((BEFORE/'comment-validation.json').read_text()):
    for old in case['commands']:replay(old,'hex-comment')
for old in json.loads((BEFORE/'truncation.json').read_text()):replay(old,'truncated-magic')
(ROOT/'validation.json').write_text(json.dumps(commands,indent=2))
# Preserve checks for genuinely ambiguous PNG and Palm/NFNT inputs.
assert any(c['canonical']=='sfont' and c['after_result']=={'ambiguous':['image','sfont']} for c in matrix)
assert any(c['canonical']=='palm' and c['after_result']=={'ambiguous':['nfnt','palm']} for c in matrix)
for c in matrix:
    name=Path(c['path']).name
    if name=='fontx2-original.fnt':assert c['after_result']=={'id':'fontx2','confidence':'Certain'},c
    if name in ['qpf-256','qpf-2048']:assert c['after_result']=={'id':'qpf','confidence':'Possible'},c
    if name=='gpi-ne.bin':assert c['after_result']=={'id':'gpi','confidence':'Possible'},c
for cmd in commands:
    if cmd['before_exit']==0:assert cmd['exit']==0,cmd
    if cmd['group']=='hex-comment' and '--from' not in cmd['argv']:assert cmd['summary']['format']=='hex',cmd
    if cmd['group']=='truncated-magic':assert cmd['exit']==1,cmd
status=run([CLI,'formats','--json']);assert status['exit']==0
(ROOT/'formats.json').write_text(status['stdout'])
summary={'matrix_cases':len(matrix),'canonical_formats':len({c['canonical'] for c in matrix}),'cli_read_commands':len(commands),'changed_registry_results':len(changed),'previous_success_regressions':0,'checks_passed':True,'cli_sha256':digest(CLI),'probe_sha256':digest(PROBE)}
(ROOT/'replay-summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
for c in changed:print(c['canonical'],Path(c['path']).name,c['before_result'],'=>',c['after_result'])
