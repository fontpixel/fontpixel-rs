"""Build the current all-feature CLI, then link a probe to that exact library artifact."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
ROOT=Path(__file__).resolve().parent;REPO=Path.cwd().resolve()
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def sources():
 files=[REPO/'Cargo.toml',REPO/'Cargo.lock']
 for crate in (REPO/'crates').iterdir():
  if crate.is_dir():
   files+=list((crate/'src').rglob('*.rs'))
   for name in ['Cargo.toml','build.rs']:
    if (crate/name).is_file():files.append(crate/name)
 return {str(p.relative_to(REPO)):digest(p) for p in sorted(files)}
before=sources();(ROOT/'source-hashes.json').write_text(json.dumps(before,indent=2))
cmd=['cargo','build','--locked','-p','fontpixel-cli','--all-features','--bin','fontpixel','--message-format=json']
start=time.time()
with (ROOT/'cargo-artifacts.jsonl').open('w') as stdout,(ROOT/'cargo-build.log').open('w') as stderr:
 process=subprocess.run(cmd,stdout=stdout,stderr=stderr)
report={'argv':cmd,'cwd':str(REPO),'exit':process.returncode,'seconds':time.time()-start,'environment':{k:os.environ.get(k) for k in ['CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_INCREMENTAL','CARGO_PROFILE_DEV_DEBUG']}}
(ROOT/'build.json').write_text(json.dumps(report,indent=2))
assert process.returncode==0,report
assert before==sources(),'Production source changed during review build; do not claim this build as the captured freeze.'
artifacts=[]
for line in (ROOT/'cargo-artifacts.jsonl').read_text().splitlines():
 try:j=json.loads(line)
 except ValueError:continue
 if j.get('reason')=='compiler-artifact':artifacts.append(j)
lib=next(j for j in artifacts if j['target']['name']=='fontpixel' and 'lib' in j['target']['kind'])
rlib=Path(next(p for p in lib['filenames'] if p.endswith('.rlib')))
sj=next(j for j in artifacts if j['target']['name']=='serde_json' and 'lib' in j['target']['kind'])
serde=Path(next(p for p in sj['filenames'] if p.endswith('.rlib')))
cli=Path(next(j['executable'] for j in artifacts if j['target']['name']=='fontpixel' and 'bin' in j['target']['kind']))
shutil.copyfile(cli,ROOT/'fontpixel-fresh');(ROOT/'fontpixel-fresh').chmod(0o755)
shutil.copyfile(ROOT.with_name('w5-detector-review')/'probe.rs',ROOT/'probe.rs')
probe=['rustc','--edition=2024',str(ROOT/'probe.rs'),'-L',f'dependency={rlib.parent}','--extern',f'fontpixel={rlib}','--extern',f'serde_json={serde}','-o',str(ROOT/'probe')]
p=subprocess.run(probe,capture_output=True,text=True)
report.update(probe_command=probe,probe_exit=p.returncode,probe_stderr=p.stderr,library_features=lib['features'],artifacts={str(p):{'bytes':p.stat().st_size,'sha256':digest(p)} for p in [rlib,serde,cli,ROOT/'fontpixel-fresh']},source_hashes_sha256=digest(ROOT/'source-hashes.json'))
(ROOT/'build.json').write_text(json.dumps(report,indent=2));assert p.returncode==0,p.stderr
assert before==sources(),'Production source changed during probe linking.'
print(json.dumps({'build_exit':process.returncode,'probe_exit':p.returncode,'cli':str(ROOT/'fontpixel-fresh'),'library':str(rlib),'seconds':time.time()-start},indent=2))
