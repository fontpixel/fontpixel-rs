from pathlib import Path
import json,subprocess,hashlib
root=Path(__file__).resolve().parent
cli=root.parent/'target-fontpixel-rs/debug/fontpixel'
records=[]
def run(args):
 p=subprocess.run([str(cli),*map(str,args)],capture_output=True,text=True,timeout=20)
 d={'argv':[str(cli),*map(str,args)],'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
 records.append(d);return d
cases=[('bdf',root/'original.bdf'),('fontx2',root/'fontx2-original.fnt')]
for fmt in ['pcf','psf','hex','c','yaff','otb','pbf','draw','sfd','kbits','bmfont']:
 p=root/f'original.{fmt}'
 r=run(['convert','--from','bdf','--to',fmt,'-o',p,root/'original.bdf'])
 if r['exit']==0:cases.append((fmt,p))
 else:print('generation failed',fmt,r['stderr'][:160])
for extra,suffix in [(['--psf-version','1'],'psf1'),(['--c-family','gfx'],'gfx.h'),(['--c-family','u8g2'],'u8g2.h'),(['--c-family','netbsd'],'netbsd.h')]:
 fmt='psf' if suffix=='psf1' else 'c';p=root/f'original.{suffix}'
 r=run(['convert','--from','bdf','--to',fmt,*extra,'-o',p,root/'original.bdf'])
 if r['exit']==0:cases.append((fmt,p))
for name in ['prep-final','prep-v2-new-groups','prep-v2-interface2','all-ready-initial']:
 p=root.parent/'phase5-performance'/f'{name}.json'
 if not p.exists():continue
 for j in json.loads(p.read_text()).get('jobs',[]):
  src=Path(j.get('primary') or '')
  if src.is_file() and j.get('format') and src.stat().st_size<2_000_000:cases.append((j['format'],src))
seen=set(); unique=[]
for fmt,p in cases:
 h=hashlib.sha256(p.read_bytes()).hexdigest()
 if (fmt,h) not in seen:seen.add((fmt,h));unique.append((fmt,p,h))
probe=subprocess.run([str(root/'probe'),*[str(p) for _,p,_ in unique]],capture_output=True,text=True,timeout=60)
(root/'probe-output.jsonl').write_text(probe.stdout)
results=[]
for (fmt,p,h),line in zip(unique,probe.stdout.splitlines()):
 j=json.loads(line);j.update(expected=fmt,sha256=h);results.append(j)
(root/'matrix.json').write_text(json.dumps(results,indent=2))
(root/'commands.json').write_text(json.dumps(records,indent=2))
(root/'binary.json').write_text(json.dumps({'path':str(cli),'sha256':hashlib.sha256(cli.read_bytes()).hexdigest(),'bytes':cli.stat().st_size},indent=2))
for j in results:
 d=j['detection'];f=j['expected']
 if f'id: "{f}"' not in d:print(f,j['path'],d,[(m['id'],m['confidence']) for m in j['matches']])
print('CASES',len(results),'FORMATS',len(set(j['expected'] for j in results)),'PROBEEXIT',probe.returncode,probe.stderr)
