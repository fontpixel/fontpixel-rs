from pathlib import Path
import json,subprocess,hashlib,re
root=Path(__file__).resolve().parent;cli=root.parent/'target-fontpixel-rs/debug/fontpixel';matrix=json.loads((root/'matrix.json').read_text());commands=[]
for j in matrix:
 p=Path(j['path']);f=j['expected'];selected=[]
 if p.parent==root:selected=[None,f]
 elif f=='qpf':selected=[None,'qpf','chiwriter']
 elif f=='palm':selected=[None,'palm','nfnt','xerox']
 elif f=='gpi-ne':selected=[None,'gpi','fon']
 elif f=='edwin':selected=[None,'edwin','plan9']
 elif f=='catalyst:data':selected=[None,'catalyst','pbf']
 for fmt in selected:
  cmd=[str(cli),'info','--json',str(p)]+(['--from',fmt] if fmt else [])
  v=subprocess.run(cmd,capture_output=True,text=True,timeout=25);n=len(commands);(root/f'cli-{n}.stdout').write_text(v.stdout);(root/f'cli-{n}.stderr').write_text(v.stderr)
  try:out=json.loads(v.stdout);summary={k:out[k] for k in ['format','font_count']};summary['glyphs']=[t['glyph_count'] for t in out['fonts']]
  except Exception:summary=v.stderr[:600]
  commands.append({'expected':f,'argv':cmd,'exit':v.returncode,'stdout_sha256':hashlib.sha256(v.stdout.encode()).hexdigest(),'stderr':v.stderr,'summary':summary,'stdout_file':str(root/f'cli-{n}.stdout')})
  print(p.name,fmt,v.returncode,summary)
(root/'validation.json').write_text(json.dumps(commands,indent=2))
