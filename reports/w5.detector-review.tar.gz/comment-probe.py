from pathlib import Path
import subprocess,json
root=Path(__file__).resolve().parent; cli=root.parent/'target-fontpixel-rs/debug/fontpixel';rows=[]
for token in ['U8G_FONT_SECTION','u8x8_font_chroma48medium8_r','U8G2_FONT_SECTION']:
 p=root/f'comment-{token}.hex';p.write_text(f'# Source declaration: {token}\n'+(root/'original.hex').read_text())
 row={'token':token,'path':str(p),'commands':[]}
 for fmt in [None,'hex','c']:
  cmd=[str(cli),'info','--json',str(p)]+(['--from',fmt] if fmt else []);r=subprocess.run(cmd,capture_output=True,text=True)
  row['commands'].append({'argv':cmd,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr});print(token,fmt,r.returncode,r.stderr[:200])
 probe=subprocess.run([str(root/'probe'),str(p)],capture_output=True,text=True);row['detection']=json.loads(probe.stdout);rows.append(row)
(root/'comment-validation.json').write_text(json.dumps(rows,indent=2))
